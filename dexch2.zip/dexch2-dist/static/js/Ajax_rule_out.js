$(".Off").click(function () {
  $('#bg').fadeOut();
  $('#bg_two').fadeOut();
});
$(document).ready(function () {
  $.ajax({
    type: 'get',
    url: '/api/rules/out/',
    dataType: 'json',
    success: function (data) {
      for (var i = 0; i < data.info.length; i++) {
        if (data.info[i].enable == true) {
          $('#tb_out').append('<tr class="get_tag">' + '<td>' + data.info[i].rule_name + '</td>'
            + '<td>' + data.info[i].process.transport_detail.allowed_organization + '</td>>'
            + '<td>' + data.info[i].selector.origin_type_id + '</td>>'
            + '<td>' + data.info[i].selector.selected_ip_field + '</td>'
            + '<td>' + '<input checked type="checkbox" name="input" data-size="small" class="switch">' + '</td>'
            + '<td>' + '<a herf="#" data-toggle="modal" data-target="#myModal" class="rule_edit">' + '编辑' + '</a>' + '</td>'
            + '<td>' + '<a class="del text-danger">' + '删除' + '</a>' + '</td>'
            + '<td>' + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + '<input type="checkbox" name="ipt">' + '</td>' + '</tr>');
        } else {
          $('#tb_out').append('<tr class="get_tag">' + '<td>' + data.info[i].rule_name + '</td>'
            + '<td>' + data.info[i].process.transport_detail.allowed_organization + '</td>>'
            + '<td>' + data.info[i].selector.origin_type_id + '</td>>'
            + '<td>' + data.info[i].selector.selected_ip_field + '</td>'
            + '<td>' + '<input type="checkbox" name="input" data-size="small" class="switch">' + '</td>>'
            + '<td>' + '<a herf="#" data-toggle="modal" data-target="#myModal" class="rule_edit">' + '编辑' + '</a>' + '</td>'
            + '<td>' + '<a class="del text-danger">' + '删除' + '</a>' + '</td>'
            + '<td>' + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + '<input type="checkbox" name="ipt">' + '</td>' + '</tr>')
        }
      }
      //启用
      $('input[name="input"]').on('switchChange.bootstrapSwitch', function () {
        m = $(this).parents("tr").index();
        if ($(this).is(':checked')) {
          var action = {
            rule_action: 'update',
            _id: data.info[m]._id,
            enable: true
          };

        } else {
          var action = {
            rule_action: 'update',
            _id: data.info[m]._id,
            enable: false
          };
        }
        $.ajax({
          type: 'post',
          url: '/api/rules/out/',
          data: JSON.stringify(action),
          dataType: 'json',
          success: function (data) {
            if (data['result'] == true) {

            } else {
              alert('提交失败');
            }
          }
        })
      });
      $(".switch").bootstrapSwitch();
      //单一删除
      var del_index;
      $(".del").click(function () {
        $("#bg,#bg_two").fadeIn();
        $(".remove").show();
        $(".delete").hide();
        del_index = $('.del').index(this);
      });
      $(".remove_out").click(function () {
        $("#bg,#bg_two").fadeIn();
        $(".remove").hide();
        $(".delete").show();
      });
      $('.remove').click(function () {
        var s_id = data.info[del_index]._id;
        var ss_id = [];
        ss_id.push(s_id);
        var all = {
          '_idlist': ss_id
        };
        $.ajax({
          type: 'post',
          url: '/api/rules/out/bulkinvalid/',
          data: all,
          dataType: 'json',
          success: function (data) {
            console.log(data);
            if (data['result'] == true) {
              window.location.href = '/rules/out/';
            } else {
              alert('删除失败');
            }
          }
        });
        $("#bg,#bg_two").hide();
      })
    }
  })
})
//新建
$('#new_rule').click(function () {
  $('#t').click(function () {
    var rulename = $('#inputText').val();
    var intype = $('#selects').val();
    var other = $('#other').val();
    if ($('.checKed').html() == 'APCERT') {
      var out_org = $('#mail').val();
      var target_type = $('#target_type').val();
      var data_new = {
        'rule_name': rulename,
        'enable': false,
        'selector': {
          'origin_type_id': intype,
          'selected_ip_field': other
        },
        'process': {
          transport_type: 'apcert_dataexchanger_platform',
          transport_detail: {
            'allowed_organization': out_org,
            'allowed_datatypes': target_type
          }
        }
      }
      $.ajax({
        type: 'post',
        url: '/api/rules/out/',
        dataType: 'json',
        data: JSON.stringify(data_new),
        success: function (data) {
          if (data['result'] == true) {
            window.location.href = '/rules/out/';
          }else{
            alert('新建失败');
          }
        }
      })
    } else {

    }
  })
})
//批量删除
$('.delete').click(function () {
  var list = [];
  $("input[name='ipt']:checked").each(function () {
    n = $(this).parents("tr").index();
    list.push(Data.info[n]._id);
  });
  $.ajax({
    type: 'post',
    url: '/api/rules/out/bulkinvalid/',
    data: {
      '_idlist': list
    },
    dataType: 'json',
    success: function (data) {
      console.log(data);
      if (data['result'] == true) {
        window.location.href = '/rules/out/';
      } else {
        alert('删除失败');
      }
    }
  });
  $("#bg,#bg_two").hide();
});