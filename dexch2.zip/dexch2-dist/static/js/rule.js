/**
 * Created by han on 2016/9/9.
 */
$('.first').click(function () {
    $('.firstWay').hide();
    $('.secondWay').hide();
    $('.thirdWay').hide();
    $('.firstWay').show();
});
$('.second').click(function () {
    $('.firstWay').hide();
    $('.secondWay').hide();
    $('.thirdWay').hide();
    $('.secondWay').show();
});
$('.third').click(function () {
    $('.firstWay').hide();
    $('.secondWay').hide();
    $('.thirdWay').hide();
    $('.thirdWay').show();
});
$('.create').click(function () {
    $('.firstWay').hide();
    $('.secondWay').hide();
    $('.thirdWay').hide();
});
$('.nav-tabs li').click(function () {
    $('.nav-tabs li').removeClass('active');
    $(this).addClass('active');
});