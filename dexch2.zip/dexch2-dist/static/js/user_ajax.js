$('#Pwd').modal('hide');
$(window).load(function () {
  var name = [],active = [],email = [],joined = [],login = [],Super = [],check,sr,admin;
  $.ajax({
    type: 'get',
    url: '/api/manage/users/',
    dataType: 'json',
    success: function (data) {
      for (var i in data.info) {
        name.push(data.info[i]['uanme']);
        active.push(data.info[i]["is_active"]);
        email.push(data.info[i]["email"]);
        joined.push(data.info[i]['date_joined']);
        login.push(data.info[i]['last_login']);
        Super.push(data.info[i]['is_superuser']);
      }
      var one_line = "<tr>";
      for (var n = 0; n < name.length; n++) {
        one_line += "<td>" + name[n] + "</td>";
        if (active[n] == true) {
          check = '<input type="checkbox" name="input" data-size="small" checked class="switch">';
        } else {
          check = '<input type="checkbox" name="input" data-size="small" class="switch">';
        }
        if (Super[n] == true) {
          sr = "是";
        } else {
          sr = "否";
        }
        if (name[n] == $('.admin').html()) {
          admin = '<span>' + '已登录账号不能重置' + '</span>';
          check = '<input type="checkbox" name="input" data-size="small" checked class="switch" disabled >';
        } else {
          admin = '<a class="reset">' + '重置密码' + '</a>';
        }
        one_line += "<td>" + email[n] + "</td>";
        one_line += "<td>" + joined[n] + "</td>";
        one_line += "<td>" + login[n] + "</td>";
        one_line += "<td>" + check + "</td>";
        one_line += "<td>" + admin + "</td>";
        one_line += "<td>" + sr + "</td>";
        one_line += "</tr>";

      }
      $("#tbody").append(one_line);
      $(".switch").bootstrapSwitch();
      $('.reset').click(function () {
        var index = $(this).parents('tr').index();
        var all = {
          user_action: 'resetpass',
          uname: data.info[index].uanme
        };
        var str = JSON.stringify(all);
        $.ajax({
          type: 'post',
          url: '/api/manage/users/',
          data: str,
          dataType: 'json',
          success: function (data) {
            if (data.result == true) {
              $('#Pwd').modal('show');
              $(".new_pwd").html("重置成功，新密码为：" + data.info);
            } else {
              alert(data.info);
            }
          }
        })
      });
      $('input[name="input"]').on('switchChange.bootstrapSwitch', function () {
        var index = $(this).parents('tr').index();
        var enable = [];
        if ($(this).is(':checked')) {
          enable = {
            user_action: 'enableuser',
            uname: data.info[index].uanme,
            enable: true
          };
        } else {
          enable = {
            user_action: 'enableuser',
            uname: data.info[index].uanme,
            enable: false
          };
        }
        var str = JSON.stringify(enable);
        $.ajax({
          type: 'post',
          url: '/api/manage/users/',
          data: str,
          dataType: 'json',
          success: function (data) {

          }
        })
      })
    }
  })
});
$("#submit").click(function () {
  var name = $(".Name").val();
  var pwd = $(".Pwd").val();
  var email = $(".Email").val();
  var all = {
    user_action: 'create',
    uname: name,
    email: email,
    passwd: pwd
  };
  var str = JSON.stringify(all);
  if (name == '' || pwd == '') {
   alert('用户名，密码不能为空！');
    //$('.ymt').html('用户名，密码不能为空！');
  } else {
    //$('.ymt').html('');
    $(".modal").modal("hide");
    $.ajax({
      type: 'post',
      url: '/api/manage/users/',
      data: str,
      dataType: 'json',
      success: function (data) {
        if (data.result == true) {
          alert('创建成功');
        } else {
          alert(data.info);
        }
      }
    })
  }
});
