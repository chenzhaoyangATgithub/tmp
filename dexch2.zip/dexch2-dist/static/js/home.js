﻿var myChart1 = echarts.init(document.getElementById('c_1'));
myChart1.setOption({
    title: {
      text: '24H内汇入数据类型统计排行(TOP5)',
      subtext: '',
      padding: [5, 0, 0, 200]
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      axisLine: {show: false},
      axisTick: {show: false},
      lineStyle: {
        color: '#fff',
        width: 1,
        type: 'solid'
      },
      type: 'value',
      boundaryGap: [0, 0.01]
    },
    yAxis: {
      axisLine: {show: false},
      axisTick: {show: false},
      type: 'category',
      data: []
    },
    series: [
      {
        name: '',
        type: 'bar',
        label: {
          normal: {
            show: true,
            position: 'insideRight'
          }
        },
        data: [],
        color: ['#70A7D8']
      }
    ]
  }
);

var myChart2 = echarts.init(document.getElementById('c_2'));
myChart2.setOption({
  title: {
    text: '24H内各单位汇入量(TOP5)',
    subtext: '',
    padding: [5, 0, 0, 200]
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    }
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true
  },
  xAxis: {
    axisLine: {show: false},
    axisTick: {show: false},
    type: 'value',
    boundaryGap: [0, 0.01]
  },
  yAxis: {
    axisLine: {show: false},
    axisTick: {show: false},
    type: 'category',
    data: []
  },
  series: [
    {
      name: '',
      type: 'bar',
      label: {
        normal: {
          show: true,
          position: 'insideRight'
        }
      },
      data: [],
      color: ['#70A7D8']
    }
  ]
})

var myChart4 = echarts.init(document.getElementById('c_4'));
myChart4.setOption({
  title: {
    text: '全部数据类型汇入统计-月',
    left: 'center'
  },
  tooltip: {
    trigger: 'axis'
  },
  toolbox: {
      show : true,
      feature : {
          mark : {show: true},
          dataView : {show: true, readOnly: false},
          magicType: {show: true, type: ['line', 'bar']},
          restore : {show: true},
          saveAsImage : {show: true}
      }
  },  
  legend: {
    data: [],
    left: 'center',
    top: [30]
  },
  grid: {
    left: '3%',
    right: '6%',
    bottom: '3%',
    containLabel: true
  },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data:[]
  },
  yAxis: {
    type: 'value'
  },
  series: []
});


var myChart5 = echarts.init(document.getElementById('c_5'));
myChart5.setOption({
  title: {
    text: 'botnet各数据类型汇入统计-周',
    left: 'center'
  },
  tooltip : {
    trigger: 'axis',
    axisPointer : {
      type : 'shadow'
    }
  },
  toolbox: {
      show : true,
      feature : {
          mark : {show: true},
          dataView : {show: true, readOnly: false},
          magicType: {show: true, type: ['line', 'bar']},
          restore : {show: true},
          saveAsImage : {show: true}
      }
  },
  legend: {
    data: [],
    padding: 30
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true
  },
  xAxis:  {
    type: 'category',
    boundaryGap: true,
    data:[]
  },
  yAxis: {
    type: 'value'
  },
  series: []
});

var myChart6 = echarts.init(document.getElementById('c_6'));
myChart6.setOption({
  title: {
    text: 'Sandbox各数据类型汇入统计-周',
    padding: [5, 0, 0, 200]
  },
  tooltip: {
    trigger: 'axis',
    axisPointer : {
      type : 'shadow'
    }
  },
  toolbox: {
      show : true,
      feature : {
          mark : {show: true},
          dataView : {show: true, readOnly: false},
          magicType: {show: true, type: ['line', 'bar']},
          restore : {show: true},
          saveAsImage : {show: true}
      }
  }, 
  legend: {
    data: [],
    padding: 30
  },
  grid: {
    left: '3%',
    right: '6%',
    bottom: '3%',
    containLabel: true
  },
  yAxis: {
    type: 'value'
  },
  xAxis: {
    type: 'category',
    boundaryGap: true,
    data: []
  },
  series: []
})

