$(".seek").click(function(){
  $("#main").show();
  $.ajax({

  })
});