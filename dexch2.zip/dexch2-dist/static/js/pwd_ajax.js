$("#sub").click(function () {
    var newP=$(".new_pwd").val();
    var oldP=$(".new_pwd2").val();
    if(newP==''){
      alert('新密码不能为空');
    }else if(newP != oldP) {
      alert("两次密码不一致！请重新输入");
    } else {
      var all = {
        'oldpass': $(".old_pwd").val(),
        'newpass': $(".new_pwd").val()
      };
      $.ajax({
        type: 'post',
        url: '/api/manage/passwd/',
        data: all,
        dataType: 'json',
        success: function (data) {
          if (data.result == true) {
            alert('修改成功，请重新登录');
            window.location.href='/api/logout/';
          } else {
            alert('原始密码不正确');
          }
        }
      })
    }
  }
);
