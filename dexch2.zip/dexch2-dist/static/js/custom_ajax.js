$('.selectpicker').selectpicker();

$(function () {
  $('#myModal').modal({
    keyboard: true
  })
});
$('.form_day').datetimepicker({
  language: 'zh-CN',
  format: 'yyyy/mm/dd',
  weekStart: 1,
  todayBtn: 1,
  autoclose: 1,
  todayHighlight: 1,
  startView: 2,
  minView: 2,
  forceParse: 0
});
//select请求
$(document).ready(function () {
  $.ajax({
    type: 'get',
    url: '/api/src/datatypes/',
    dataType: 'json',
    success: function (data) {
      var props = [];
      var a = 0;
      for (props[a++] in data);
      for (var b = 0; b < props.length; b++) {
        var new_opt = $('<option value="' + props[b] + '">');
        new_opt.html(props[b]);
        //new_opt.data('index',props[b]);
        $("#first_floor").append(new_opt).selectpicker('refresh');
      }
      var prop = [];
      var e = 0;
      var first_val = $('#first_floor option:selected').val();
      for (prop[e++] in data[first_val]);
      for (var s = 0; s < prop.length; s++) {
        var opts=$('<option value="' + prop[s] + '" selected>');
        opts.html(prop[s]);
        //var opts='<option value="' + prop[s] + '" selected>'+ prop[s] +'</option>';
        $("#second_floor").append(opts).selectpicker('refresh');
      }
      $('#first_floor').on('change', function () {
        $("#second_floor").empty();
        var index_from_1 = $('#first_floor option:selected').val();
        var select2_list = data[index_from_1];
        for (var value in select2_list) {
          var new_opt = $('<option value="' + value + '" selected>');
          new_opt.html(value);
          $('#second_floor').append(new_opt).selectpicker('refresh');
        }
      })
    }
  })
});
//初始化时间
(function () {
  var now = new Date();
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var date = now.getDate();
  var month_1 = month - 1;
  var time = year + '/' + month + '/' + date;
  //var now = new Date();
  //var year = now.getFullYear();
  //var month = now.getMonth();
  //var date = now.getDate();
  //var hour = now.getHours();
  //var minu = now.getMinutes();
  // console.log(time);
  var time2 = year + "/" + month_1 + "/" + date;
  $('#some_class_1').val(time2);
  $('#some_class_2').val(time);
})();
//统计ajax
$("#Statistics").click(function () {
  $("#Title").html('');
  $("#Thead tr").empty();
  $("#Tbody").empty();
  var str = $("#some_class_1").val();
  var data = new Date(str);
  var starTime = data.getTime() / 1000;
  var str1 = $("#some_class_2").val();
  var data1 = new Date(str1);
  var endTime = data1.getTime() / 1000;
  var dt1 = $("#second_floor").val();
  var Type = $("#Types").val();
  var all = {start_time: starTime, end_time: endTime, organization_selected: dt1, interval_type: Type};
  $.ajax({
    type: 'get',
    url: '/api/statistics/report/',
    data: all,
    dataType: 'json',
    success: function (data) {
      if (data['organizations_total']['name'] == '') {
        $('.cc').hide();
        $('.hides').show();
        $("#Title").show().html('无数据');
      } else {
        $('.hides').show();
        $('.cc').show();
        var dt = data['organizations_trend'];
        var dn = data['organizations_total'];
        var Name = [];
        var t_n_list = {};
        for (var key in dt) {
          for (var j = 0; j < dt[key]['name'].length; j++) {
            if (t_n_list[dt[key]['name'][j]] == undefined) {
              t_n_list[dt[key]['name'][j]] = {};
            }
            t_n_list[dt[key]['name'][j]][key] = dt[key]['value'][j];
          }
          Name.push(key);
        }
        $("#Thead tr").append('<th>' + '时间' + '</th>');
        for (var n = 0; n < Name.length; n++) {
          $("#Thead tr").append('<th>' + Name[n] + '</th>');
        }
        var one_line = "<tr>";
        for (var time in t_n_list) {
          one_line += "<td>" + time + "</td>";
          for (var name in t_n_list[time]) {
            one_line += "<td>" + t_n_list[time][name] + "</td>";
          }
          one_line += "</tr>";
        }
        $('#Title').html('汇入数据条数'+ '（'+str + '——' + str1+'）');
        $("#Tbody").append(one_line);
        $('#Tbody').append('<tr id="last">' + '<td>' + '总计' + '</td>' + '</tr>');
        for (var b = 0; b < dn['value'].length; b++) {
          $('#Tbody #last').append('<td>' + dn['value'][b] + '</td>')
        }
      }
    }
  })
  //}
});

function doExport(selector, params) {
  var options = {
    //ignoreRow: [1,11,12,-2],
    //ignoreColumn: [0,-1],
    tableName: 'Countries',
    worksheetName: 'Countries by population'
  };

  $.extend(true, options, params);

  $(selector).tableExport(options);
}

function DoOnCellHtmlData(cell, row, col, data) {
  var result = "";
  if (data != "") {
    var html = $.parseHTML(data)

    $.each(html, function () {
      if (typeof $(this).html() === 'undefined')
        result += $(this).text();
      else if ($(this).is("input"))
        result += $('#' + $(this).attr('id')).val();
      else if (!$(this).hasClass('no_export'))
        result += $(this).html();
    });
  }
  return result;
}

function DoOnMsoNumberFormat(cell, row, col) {
  var result = "";
  if (row > 0 && col == 0)
    result = "\\@";
  return result;
}

