$(document).ready(function () {
  $.ajax({
    type: 'get',
    url: '/api/sysstate/',
    dataType: 'json',
    success: function (data) {
      $(".A_name").val(data.logged_uname);
      if(data.is_superuser==true){
        $(".admin").html(data.logged_uname);
        $(".is_super").html('超级管理员&nbsp;');
        $(".role").html('超级管理员');
        //$(".user,.sysinfo,.journal,.py").show();
      }else{
        $(".admin").html(data.logged_uname);
        $(".is_super").html('普通用户&nbsp;');
        $(".role").html('普通用户');
        //$(".user,.sysinfo,.journal,.py").hide();
      }
    }
  });
  $.ajax({
    type: 'get',
    url: '/api/manage/sysinfo/',
    dataType: 'json',
    success:function (data) {
      $('.head_left').append('<div id="logo_name">'+data.info.organization_name+'</div>')
    }
  })
});
$(window).load(function () {
  $(".more").click(function () {
    if ($(this).siblings('ul').css('display') == 'block') {
      $(this).children('b').removeClass('jian');
      $(this).siblings('ul').slideUp(300);
    } else if ($(this).siblings('ul').css('display') == 'none') {
      $(this).children('b').addClass('jian');
      $(this).siblings('ul').slideDown(300);
      $(this).parent('li').siblings('li').children('ul').slideUp(300);
      $(this).parent('li').siblings('li').children('a').children('b').removeClass('jian')
    } else {
      $(this).siblings('ul').slideUp(300);
      $(this).parent('li').siblings('li').children('ul').slideDown(300);
    }
  })
});


