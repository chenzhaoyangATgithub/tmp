$('.exact').click(function () {
  $('#exact_show').show();
  $('#fuzzy_show').hide();
  $('.exact').addClass('active');
  $('.fuzzy').removeClass('active');
});
$('.fuzzy').click(function () {
  $('#fuzzy_show').show();
  $('#exact_show').hide();
  $('.exact').removeClass('active');
  $('.fuzzy').addClass('active');
});
$(document).ready(function () {
  $('#examles').DataTable({
    order: [[0, "desc"]],
    "lengthMenu": [10, 20, 50, 100]
  })
});
var es_ipt = $('#ipt_query').val();
var pageCount;
if (es_ipt == '') {
  var data_es = {
    rest_method: 'GET',
    rest_url: '/origin/report/_search?from=0&size=0',
    rest_json: ''
  };
  var Data;
  pageCount = Data;
  $.ajax({
    type: 'post',
    async: false,
    url: "/api/es/",
    dataType: 'json',
    crossDomain: true,
    data: data_es,
    success: function (dates) {
      Data = dates;
    }
  })
  page_hit = Math.ceil(Data.hits.total / 10);
  createPageNav({
    $container: $("#Page"),
    pageCount: page_hit
  });
} else {
  var data_q = {
    'query': {
      'match': {
        'report_futures.url.values': es_ipt
      }
    }
  }
  var data_es = {
    rest_method: 'GET',
    rest_url: '/origin/report/_search?from=0&size=0',
    rest_json: JSON.stringify(data_q)
  };
  var Data;
  pageCount = Data;
  $.ajax({
    type: 'post',
    async: false,
    url: "/api/es/",
    dataType: 'json',
    crossDomain: true,
    data: data_es,
    success: function (dates) {
      Data = dates;
    }
  });
  page_hit = Math.ceil(Data.hits.total / 10);
  // console.log(page_hit);
  createPageNav({
    $container: $("#Page"),
    pageCount: page_hit
  })
}
//展示内容
function add_table(b) {
  for (var i = 0; i < b.length; i++) {
    var new_length = b[i]._source.records.length;
    var new_tr = '<tr>';
    new_tr += '<td>' + b[i]._source._meta.dates.creating.hourly + '</td>';
    new_tr += '<td>' + b[i]._source._meta.dates.report.hourly + '</td>';
    new_tr += '<td>' + b[i]._source.enrich.origin_organization.brief_name + '</td>';
    new_tr += '<td>' + b[i]._source.enrich.origin_type_id + '</td>';
    new_tr += '<td>' + b[i]._source.enrich.secret_level + '</td>';
    new_tr += '<td>' + '<a class="messages">' + '共' + new_length + '条' + '</a>';
    new_tr += '</tr>';
    $("#Tbody").append(new_tr);
  }
}
//详细信息
var data_set = [];
var title_list = [];
var cols = [];
var f_table = null;
function detailClick(a) {
  $('.messages').click(function () {
    $('#detail_tbody').html('');
    $('.os_more').show();
    data_set = [];
    title_list = [];
    cols = [];
    var more_value = [];
    var more_index = $(".messages").index(this);
    var Details = a[more_index]._source.records;
    for (var i = 0; i < Details.length; i++) {
      record = Details[i];
      var k_s = [];
      var v_s = [];
      for (k in record) {
        k_s.push(k);
        v_s.push(record[k]);
      }

      title_list = k_s;
      data_set.push(v_s);
    }
    for (var i = 0; i < title_list.length; i++) {
      cols.push({'title': title_list[i]})
    }
    if (Details == '') {
      $('.os_more').hide();
    } else {
      $('.more_hide').hide();
      var Cat = [];
      var Cc = [];
      for (var i = 0; i < Details.length; i++) {
        for (var cat in Details[i])
          Cat.push(cat);
        var c = [];
        for (c in Details[i])
          Cc.push(Details[i][c]);
      }
      var amount = Details.length;
      if (amount < 1 || amount==1 ) {
        for (var i = 0; i < Cat.length; i++) {
          var new_tr = '<tr>';
          new_tr += '<td  class="p_name">' + Cat[i] + '</td>';
          new_tr += '<td>' + Cc[i] + '</td>';
          new_tr += '</tr>';
          $('#detail_tbody').append(new_tr);
          $('.mores').html('');
        }
      } else {
        var one_value = [];
        var one_name = Object.keys(Details[0]);
        for (var n in Details[0]) {
          one_value.push(Details[0][n]);
        }
        for (var e = 0; e < one_name.length; e++) {
          var new_trs = '<tr>';
          new_trs += '<td  class="p_name">' + one_name[e] + '</td>';
          new_trs += '<td>' + one_value[e] + '</td>';
          new_trs += '</tr>';
          $('#detail_tbody').append(new_trs);
          $('.mores').html('显示更多');
        }
      }

    }
  })
  $('.mores').click(function () {
    $('#modals').modal('show');
    if(f_table != null){
      f_table.fnDestroy();
      $('#examples').html('');
    }
      f_table = $('#examples').dataTable({
        order: [[0, "desc"]],
        language: {
          "lengthMenu": "每页 _MENU_ 条记录",
          "zeroRecords": "没有找到记录",
          "info": "第 _PAGE_ 页 ( 总共 _PAGES_ 页 )",
          "infoEmpty": "无记录",
          "infoFiltered": "(从 _MAX_ 条记录过滤)",
          "search": "搜索:",
          "paginate": {
            "next": "下一页",
            "previous": "上一页"
          }
        },
        data: data_set,
        columns: cols
      });

  })
}
//分页，页码导航,要求参数为一个对象
function createPageNav(opt) {
  opt = opt || {};
  var $container = opt.$container || null, //必需，页码容器，请确保这个容器只用来存放页码导航
    pageCount = Number(opt.pageCount) || 0,    //必需，页码总数
    currentNum = Number(opt.currentNum) || 1,    //选填，当前页码
    maxCommonLen = Number(opt.maxCommonLen) || 6,   //选填，普通页码的最大个数

    className = opt.className || "pagination",//选填，分页类型：pagination或pager等
    preText = opt.preText || "上一页",      //选填，上一页文字显示，适用于只有前后页按钮的情况
    nextText = opt.nextText || "下一页",      //选填，下一页文字，同上
    firstText = opt.firstText || "首页",
    lastText = opt.lastText || "末页",

    hasFirstBtn = opt.hasFirstBtn === false ? false : true,
    hasLastBtn = opt.hasLastBtn === false ? false : true,
    hasPreBtn = opt.hasPreBtn === false ? false : true,
    hasNextBtn = opt.hasNextBtn === false ? false : true,
    hasInput = opt.hasInput === false ? false : true,
    hasCommonPage = opt.hasCommonPage === false ? false : true,//选填，是否存在普通页

    beforeFun = opt.beforeFun || null,  //选填，页码跳转前调用的函数，可通过返回false来阻止跳转，可接收目标页码参数
    afterFun = opt.afterFun || null,  //选填，页码跳转后调用的函数，可接收目标页码参数
    noPageFun = opt.noPageFun || null;  //选填，页码总数为0时调用的函数

  //当前显示的最小页码，用于计算起始页码，直接容器,当前页，前，后，首，末，输入框
  var minNum = 1, changeLen, $parent, $currentPage, $preBtn, $nextBtn, $firstBtn, $lastBtn, $input;

  //容器
  if (!$container || $container.length != 1) {
    // console.log("分页容器不存在或不正确");
    return false;
  }
  //总页数
  if (pageCount <= 0) {
    if (noPageFun) noPageFun();
    return false;
  }
  //当前页
  if (currentNum < 1) currentNum = 1;
  else if (currentNum > pageCount) currentNum = pageCount;
  //普通页码的最大个数，起始页算法限制，不能小于3
  if (maxCommonLen < 3) maxCommonLen = 3;
  //跳转页响应长度，用于计算起始页码
  if (maxCommonLen >= 8) changeLen = 3;
  else if (maxCommonLen >= 5) changeLen = 2;
  else changeLen = 1;

  $container.hide();
  _initPageNav();
  $container.show();

  function _initPageNav() {
    var initStr = [];
    var Div = [];
    initStr.push('<nav><ul class="' + className + '" onselectstart="return false">');
    if (hasFirstBtn)initStr.push('<li class="first-page" value="1"><span>' + firstText + '</span></li>');
    if (hasPreBtn)  initStr.push('<li class="pre-page"  value="' + (currentNum - 1) + '"><span>' + preText + '</span></li>');
    if (hasNextBtn) initStr.push('<li class="next-page" value="' + (currentNum + 1) + '"><span>' + nextText + '</span></li>');
    if (hasLastBtn) initStr.push('<li class="last-page" value="' + pageCount + '"><span>' + lastText + '</span></li>');
    if (hasInput)initStr.push('<div class="input-page-div">第<input type="text" style="background: #fff;" disabled maxlength="6" value="' + currentNum + '" />页，共<span>' + pageCount + '</span>页</div>');
    initStr.push('</ul></nav>');
    $container.html(initStr.join(""));
    //初始化变量
    $parent = $container.children().children();
    if (hasFirstBtn) $firstBtn = $parent.children("li.first-page");
    if (hasPreBtn)   $preBtn = $parent.children("li.pre-page");
    if (hasNextBtn)  $nextBtn = $parent.children("li.next-page");
    if (hasLastBtn)  $lastBtn = $parent.children("li.last-page");
    if (hasInput) {
      $input = $parent.find("div.input-page-div>input");
      $parent.find("div.input-page-div>button").click(function () {
        _gotoPage($input.val());
      });
    }
    //初始化功能按钮
    _buttonToggle(currentNum);
    //生成普通页码
    if (hasCommonPage) {
      _createCommonPage(_computeStartNum(currentNum), currentNum);
    }
    //绑定点击事件
    $parent.on("click", "li", function () {
      var $this = $(this);
      if ($this.is("li") && $this.attr("value")) {
        if (!$this.hasClass("disabled") && !$this.hasClass("active")) {
          _gotoPage($this.attr("value"));
        }
      }
    });
  }

  //跳转到页码
  function _gotoPage(targetNum) {
    targetNum = _formatNum(targetNum);
    if (targetNum == 0 || targetNum == currentNum) return false;
    // 跳转前回调函数
    if (beforeFun && beforeFun(targetNum) === false) return false;
    //修改值
    currentNum = targetNum;
    if (hasInput)  $input.val(targetNum);
    if (hasPreBtn) $preBtn.attr("value", targetNum - 1);
    if (hasNextBtn) $nextBtn.attr("value", targetNum + 1);
    //修改功能按钮的状态
    _buttonToggle(targetNum);
    // 计算起始页码
    if (hasCommonPage) {
      var starNum = _computeStartNum(targetNum);
      if (starNum == minNum) {// 要显示的页码是相同的
        $currentPage.removeClass("active");
        $currentPage = $parent.children("li.commonPage").eq(targetNum - minNum).addClass("active");
      }
      else {// 需要刷新页码
        _createCommonPage(starNum, targetNum);
      }
    }
    // 跳转后回调函数
    if (afterFun) afterFun(targetNum);
  }

  //整理目标页码的值
  function _formatNum(num) {
    num = Number(num);
    if (isNaN(num)) num = 0;
    else if (num <= 0) num = 1;
    else if (num > pageCount) num = pageCount;
    return num;
  }

  //功能按钮的开启与关闭
  function _buttonToggle(current) {
    if (current == 1) {
      if (hasFirstBtn) $firstBtn.addClass("disabled");
      if (hasPreBtn)   $preBtn.addClass("disabled");
    }
    else {
      if (hasFirstBtn) $firstBtn.removeClass("disabled");
      if (hasPreBtn)   $preBtn.removeClass("disabled");
    }

    if (current == pageCount) {
      if (hasNextBtn) $nextBtn.addClass("disabled");
      if (hasLastBtn) $lastBtn.addClass("disabled");
    }
    else {
      if (hasNextBtn) $nextBtn.removeClass("disabled");
      if (hasLastBtn) $lastBtn.removeClass("disabled");
    }
  }

  //计算当前显示的起始页码
  function _computeStartNum(targetNum) {
    var startNum;
    if (pageCount <= maxCommonLen)
      startNum = 1;
    else {
      if ((targetNum - minNum) >= (maxCommonLen - changeLen)) {//跳转到靠后的页码
        startNum = targetNum - changeLen;
        if ((startNum + maxCommonLen - 1) > pageCount) startNum = pageCount - (maxCommonLen - 1);// 边界修正
      }
      else if ((targetNum - minNum) <= (changeLen - 1)) {//跳转到靠前的页码
        startNum = targetNum - (maxCommonLen - changeLen - 1);
        if (startNum <= 0) startNum = 1;// 边界修正
      }
      else {// 不用改变页码
        startNum = minNum;
      }
    }
    return startNum;
  }

  //生成普通页码
  function _createCommonPage(startNum, activeNum) {
    var initStr = [];
    for (var i = 1, pageNum = startNum; i <= pageCount && i <= maxCommonLen; i++ , pageNum++) {
      initStr.push('<li class="commonPage" value="' + pageNum + '"><a href="javascript:">' + pageNum + '</a></li>');
    }

    $parent.hide();
    $parent.children("li.commonPage").remove();
    if (hasPreBtn) $preBtn.after(initStr.join(""));
    else if (hasFirstBtn) $firstBtn.after(initStr.join(""));
    else $parent.prepend(initStr.join(""));
    minNum = startNum;
    $currentPage = $parent.children("li.commonPage").eq(activeNum - startNum).addClass("active");
    $parent.show();
    //翻页查询
    $('.pagination li').click(function () {
      $('.os_more').hide();
      var es_ipt = $('#ipt_query').val();
      var page = $(this).val();
      var new_img = '<img src="/static/images/load.gif" alt=""/>';
      if ($(this).hasClass('disabled')) {
        //nothing
      } else {
        var pages = page - 1;
        var es_ipt = $('#ipt_query').val();
        if (es_ipt == '' && $('#fuzzy_query').val() == '') {
          var data_q = {
            'query': {
              'match_all': {}
            },
            from: pages * 10,
            size: 10,
            "sort": {"_meta.dates.creating.iso": {"order": "desc"}}
          }
          var data_es = {
            rest_method: 'GET',
            rest_url: '/origin/report/_search',
            rest_json: JSON.stringify(data_q)
          }
          $.ajax({
            type: 'post',
            url: "/api/es/",
            dataType: 'json',
            crossDomain: true,
            data: data_es,
            beforeSend: function () {
              $(".load").show().html(new_img + '获取中...');
            },
            complete: function () {
              $(".load").hide().html('');

            },
            success: function (result) {
              // console.log(result);
              $('#Tbody').html('');
              var Hits = result.hits.hits;
              add_table(Hits);
              detailClick(Hits);
            }
          })
        }
        else if ($('#fuzzy_query').val() != '') {
          var es_ipt = $('#fuzzy_query').val();
          var data_q = {
            from: pages * 10,
            size: 10,
            "sort": {"_meta.dates.creating.iso": {"order": "desc"}}
          }
          var myurl = '/origin/report/_search?q=' + es_ipt;
          var data_es = {
            rest_method: 'GET',
            rest_url: myurl,
            rest_json: JSON.stringify(data_q)
          };
          $.ajax({
            type: 'post',
            url: "/api/es/",
            dataType: 'json',
            crossDomain: true,
            data: data_es,
            beforeSend: function () {
              $(".load").show().html(new_img + '获取中...');
            },
            complete: function () {
              $(".load").hide().html('');

            },
            success: function (result) {
              // console.log(result);
              $('#Tbody').html('');
              var Hits = result.hits.hits;
              add_table(Hits);
              detailClick(Hits);
            }
          })
        } else {
          var data_q = {
            'query': {
              'match': {
                'report_futures.url.values': es_ipt
              }
            },
            from: pages * 10,
            size: 10,
            "sort": {"_meta.dates.creating.iso": {"order": "desc"}}
          }
          var data_es = {
            rest_method: 'GET',
            rest_url: '/origin/report/_search',
            rest_json: JSON.stringify(data_q)
          }
          $.ajax({
            type: 'post',
            url: "/api/es/",
            dataType: 'json',
            crossDomain: true,
            data: data_es,
            beforeSend: function () {
              $(".load").show().html(new_img + '获取中...');
            },
            complete: function () {
              $(".load").hide().html('');

            },
            success: function (result) {
              // console.log(result);
              $('#Tbody').html('');
              var Hits = result.hits.hits;
              add_table(Hits);
              detailClick(Hits);
            }
          })
        }
      }
    })
  }
}
//页面加载显示信息
$(document).ready(function () {
  var data_q = {
    'query': {
      'match_all': {}
    },
    from: 0,
    size: 10,
    "sort": {"_meta.dates.creating.iso": {"order": "desc"}}
  };
  var data_es = {
    rest_method: 'GET',
    rest_url: '/origin/report/_search',
    rest_json: JSON.stringify(data_q)
  };
  $.ajax({
    type: 'post',
    url: "/api/es/",
    dataType: 'json',
    crossDomain: true,
    data: data_es,
    success: function (dates) {
      var Hits = dates.hits.hits;
      add_table(Hits);
      detailClick(Hits);
    }
  })
});
//精确查询
$('#Query').click(function () {
  $('.os_more').hide();
  var es_ipt = $('#ipt_query').val();
  if (es_ipt == '') {
    alert('请输入查询内容');
  } else {
    var opt = $('#Type').val();
    switch (opt) {
      case 'hash':
        var data_h = {
          'query': {
            'match': {
              'report_futures.hash.values': es_ipt
            }
          },
          from: 0,
          size: 10,
          "sort": {"_meta.dates.creating.iso": {"order": "desc"}}
        };
        var data_hs = {
          rest_method: 'GET',
          rest_url: '/origin/report/_search',
          rest_json: JSON.stringify(data_h)
        };
        $.ajax({
          type: 'post',
          async: false,
          url: "/api/es/",
          dataType: 'json',
          crossDomain: true,
          data: data_hs,
          success: function (dates) {
            data_f = dates;
            var Hits = dates.hits.hits;
            page_hit = Math.ceil(dates.hits.total / 10);
            createPageNav({
              $container: $("#Page"),
              pageCount: page_hit
            })
          }
        });
        var Hits = data_f.hits.hits;
        if (Hits == '') {
          alert('无数据');
        } else {
          $('#Tbody').html('');
          add_table(Hits);
          detailClick(Hits);
        }
        break;
      case 'ip':
        var data_i = {
          'query': {
            'match': {
              'report_futures.ip.values': es_ipt
            }
          },
          from: 0,
          size: 10,
          "sort": {"_meta.dates.creating.iso": {"order": "desc"}}
        };
        var data_is = {
          rest_method: 'GET',
          rest_url: '/origin/report/_search',
          rest_json: JSON.stringify(data_i)
        };
        $.ajax({
          type: 'post',
          async: false,
          url: "/api/es/",
          dataType: 'json',
          crossDomain: true,
          data: data_is,
          success: function (dates) {
            data_f = dates;
            var Hits = dates.hits.hits;
            page_hit = Math.ceil(dates.hits.total / 10);
            createPageNav({
              $container: $("#Page"),
              pageCount: page_hit
            })
          }
        });
        var Hits = data_f.hits.hits;
        if (Hits == '') {
          alert('无数据');
        } else {
          $('#Tbody').html('');
          add_table(Hits);
          detailClick(Hits);
        }
        break;
      case 'url':
        var data_u = {
          'query': {
            'match': {
              'report_futures.url.values': es_ipt
            }
          },
          from: 0,
          size: 10,
          "sort": {"_meta.dates.creating.iso": {"order": "desc"}}
        };
        var data_us = {
          rest_method: 'GET',
          rest_url: '/origin/report/_search',
          rest_json: JSON.stringify(data_u)
        };
        $.ajax({
          type: 'post',
          async: false,
          url: "/api/es/",
          dataType: 'json',
          crossDomain: true,
          data: data_us,
          success: function (dates) {
            data_f = dates;
            var Hits = dates.hits.hits;
            page_hit = Math.ceil(dates.hits.total / 10);
            createPageNav({
              $container: $("#Page"),
              pageCount: page_hit
            })
          }
        });
        var Hits = data_f.hits.hits;
        if (Hits == '') {
          alert('无数据');
        } else {
          $('#Tbody').html('');
          add_table(Hits);
          detailClick(Hits);
        }
        break;
    }
  }
});
//全文查询
$('#fu_Query').click(function () {
  //页数
  var data_f;
  $('.os_more').hide();
  var es_ipt = $('#fuzzy_query').val();
  if (es_ipt == '') {
    alert('请输入查询内容');
  } else {
    var data_q = {
      from: 0,
      size: 10,
      "sort": {"_meta.dates.creating.iso": {"order": "desc"}}
    };
    var myurl = '/origin/report/_search?q=' + es_ipt;
    var data_es = {
      rest_method: 'GET',
      rest_url: myurl,
      rest_json: JSON.stringify(data_q)
    };
    $.ajax({
      type: 'post',
      async: false,
      url: "/api/es/",
      dataType: 'json',
      crossDomain: true,
      data: data_es,
      success: function (dates) {
        data_f = dates;
        var Hits = dates.hits.hits;
        page_hit = Math.ceil(dates.hits.total / 10);
        createPageNav({
          $container: $("#Page"),
          pageCount: page_hit
        })
      }
    });
    var Hits = data_f.hits.hits;
    if (Hits == '') {
      alert('无数据');
    } else {
      $('#Tbody').html('');
      add_table(Hits);
      detailClick(Hits);
    }
  }
});

