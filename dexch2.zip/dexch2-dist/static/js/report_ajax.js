
$('.selectpicker').selectpicker();

$(function () {
  $('#myModal').modal({
    keyboard: true
  })
});
$('.form_day').datetimepicker({
  language: 'zh-CN',
  format: 'yyyy/mm/dd',
  weekStart: 1,
  todayBtn: 1,
  autoclose: 1,
  bootcssVer:3,
  todayHighlight: 1,
  startView: 2,
  minView: 2,
  forceParse: 0
});
$('#dy').datetimepicker({
  language: 'zh-CN',
  format: 'yyyy/mm/dd',
  daysOfWeekDisabled : "0,2,3,4,5,6",
  weekStart: 1,
  todayBtn: 0,
  autoclose: 1,
  todayHighlight: 1,
  startView: 2,
  minView: 2,
  forceParse: 0
}).on('changeDate', function(ev){
  var end_time= moment($("#dy").val()).add('days',6).format('YYYY/MM/DD');
  //alert(end_time);
  $("#end").val(end_time);
});
$('.form_month').datetimepicker({
  language: 'zh-CN',
  format: 'yyyy/mm',
  weekStart: 1,
  todayBtn: 1,
  autoclose: 1,
  todayHighlight: 1,
  startView: 3,
  minView: 3,
  forceParse: 0
});
$('.form_year').datetimepicker({
  language: 'zh-CN',
  format: 'yyyy',
  weekStart: 1,
  todayBtn: 1,
  autoclose: 1,
  todayHighlight: 1,
  startView: 4,
  minView: 4,
  forceParse: 0
});
(function () {
  var now = new Date();
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var date = now.getDate();
  var date2 = date-7;
  var time2 = year + '/' + month + '/' + date2;
  var time = year + '/' + month + '/' + date;
  $(".form_day").val(time);
  $("#dy").val('选择一周开始时间');
}());
(function () {
  var now = new Date();
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var time = year + '/' + month;
  $(".form_month").val(time);
}());
(function () {
  var now = new Date();
  var year = now.getFullYear();
  $(".form_year").val(year);
}());
//ajax
//统计天
$("#s_day").click(function(){
  $("#Title").html('');
  $("#Tbody,#Thead tr").empty();
  var Tim=$(".Day").val();
  var str1 = moment(Tim);
  var tim1 = str1.add(1,'day').format();
  var str2 = moment(tim1);
  var str3 = moment(Tim);
  var starTime = str3.unix();
  var endTime = str2.unix();
  var check = $("#second_floor").val();
  var all = {
    start_time: starTime,
    end_time: endTime,
    organization_selected: check,
    interval_type: "hourly"
  };
  $.ajax({
    type: 'get',
    url: '/api/statistics/report/',
    data: all,
    dataType: 'json',
    success: function (data) {
      if (data['organizations_total']['name'] == '') {
        $('.cc').hide();
        $('.hides').show();
        $("#Title").show().html('无数据');
      } else {
        $('.hides').show();
        $('.cc').show();
        var dt = data['organizations_trend'];
        var dn= data['organizations_total'];
        var Name = [];
        var t_n_list = {};
        for (var key in dt){
          for (var j = 0;j < dt[key]['name'].length;j++){
            if (t_n_list[dt[key]['name'][j]] == undefined){
              t_n_list[dt[key]['name'][j]] = {};
            }
            t_n_list[dt[key]['name'][j]][key] = dt[key]['value'][j];
          }
          Name.push(key);
        }
        $("#Thead tr").append('<th>' + '时间' + '</th>');
        for (var n = 0; n < Name.length; n++) {
          $("#Thead tr").append('<th>' + Name[n] + '</th>');
        }
        var one_line = "<tr>";
        for (var time in t_n_list){
          one_line+="<td>" + time + "</td>";
          for (var name in t_n_list[time]){
            one_line+="<td>" + t_n_list[time][name] + "</td>";
          }
          one_line += "</tr>";
        }
        $('#Title').html('汇入数据条数'+ '（'+ Tim +'）');
        $("#Tbody").append(one_line);
        $('#Tbody').append('<tr id="last">'+'<td>' + '总计' + '</td>'+'</tr>');
        for(var b = 0;b < dn['value'].length; b++){
          $('#Tbody #last').append('<td>' + dn['value'][b] + '</td>')
        }
      }
    }
  })
});
$("#s_week").click(function(){
  $("#Title").html('');
  $("#Thead tr").empty();
  $("#Tbody").empty();
  var star_time=$("#dy").val();
  var star = moment(star_time);
  var end_time = $('#end').val();
  var end = moment(end_time);
  var starTime = star.unix();
  var endTime = end.unix();
  var cheCkd = $("#second_floor").val();
  var all = {
    start_time: starTime,
    end_time: endTime,
    organization_selected: cheCkd,
    interval_type: "daily"
  };
  if (end_time=='') {
    $('.cc').hide();
    $('.hides').show();
    $("#Title").show().html('请选择开始时间');
  }else{
    $.ajax({
      type: 'get',
      url: '/api/statistics/report/',
      data: all,
      dataType: 'json',
      success: function (data) {
        if (data['organizations_total']['name'] == '') {
          $('.cc').hide();
          $('.hides').show();
          $("#Title").show().html('无数据');
        } else {
          $('.hides').show();
          $('.cc').show();
          var dt = data['organizations_trend'];
          var dn= data['organizations_total'];
          var Name = [];
          var t_n_list = {};
          for (var key in dt){
            for (var j = 0;j < dt[key]['name'].length;j++){
              if (t_n_list[dt[key]['name'][j]] == undefined){
                t_n_list[dt[key]['name'][j]] = {};
              }
              t_n_list[dt[key]['name'][j]][key] = dt[key]['value'][j];
            }
            Name.push(key);
          }
          $("#Thead tr").append('<th>' + '时间' + '</th>');
          for (var n = 0; n < Name.length; n++) {
            $("#Thead tr").append('<th>' + Name[n] + '</th>');
          }
          var one_line = "<tr>";
          for (var time in t_n_list){
            one_line+="<td>" + time + "</td>";
            for (var name in t_n_list[time]){
              one_line+="<td>" + t_n_list[time][name] + "</td>";
            }
            one_line += "</tr>";
          }
          $('#Title').html('汇入数据条数'+ '（'+star_time + '——' + end_time+'）');
          $("#Tbody").append(one_line);
          $('#Tbody').append('<tr id="last">'+'<td>' + '总计' + '</td>'+'</tr>');
          for(var b = 0;b < dn['value'].length; b++){
            $('#Tbody #last').append('<td>' + dn['value'][b] + '</td>')
          }
        }
      }
    })
  }
});
$("#s_month").click(function(){
  $("#Title").html('');
  $("#Thead tr").empty();
  $("#Tbody").empty();
  var Time=$(".form_month").val();
  var star_time = Time + "/" + "01";
  var Star = moment(star_time);
  var time_2 = Star.add(1,'month').format();
  var end = moment(time_2);
  var star = moment(star_time);
  var starTime = star.unix();
  var endTime = end.unix();
  var cheCkd = $("#second_floor").val();
  var all = {
    start_time: starTime,
    end_time: endTime,
    organization_selected: cheCkd,
    interval_type: "daily"
  };
  $.ajax({
    type: 'get',
    url: '/api/statistics/report/',
    data: all,
    dataType: 'json',
    success: function (data) {
      if (data['organizations_total']['name'] == '') {
        $('.cc').hide();
        $('.hides').show();
        $("#Title").show().html('无数据');
      } else {
        $('.hides').show();
        $('.cc').show();
        var dt = data['organizations_trend'];
        var dn= data['organizations_total'];
        var Name = [];
        var t_n_list = {};
        for (var key in dt){
          for (var j = 0;j < dt[key]['name'].length;j++){
            if (t_n_list[dt[key]['name'][j]] == undefined){
              t_n_list[dt[key]['name'][j]] = {};
            }
            t_n_list[dt[key]['name'][j]][key] = dt[key]['value'][j];
          }
          Name.push(key);
        }
        $("#Thead tr").append('<th>' + '时间' + '</th>');
        for (var n = 0; n < Name.length; n++) {
          $("#Thead tr").append('<th>' + Name[n] + '</th>');
        }
        var one_line = "<tr>";
        for (var time in t_n_list){
          one_line+="<td>" + time + "</td>";
          for (var name in t_n_list[time]){
            one_line+="<td>" + t_n_list[time][name] + "</td>";
          }
          one_line += "</tr>";
        }
        $('#Title').html('汇入数据条数'+ '（'+ Time +'）');
        $("#Tbody").append(one_line);
        $('#Tbody').append('<tr id="last">'+'<td>' + '总计' + '</td>'+'</tr>');
        for(var b = 0;b < dn['value'].length; b++){
          $('#Tbody #last').append('<td>' + dn['value'][b] + '</td>')
        }
      }
    }
  })
});
$("#s_quarter").click(function(){
  $("#Title").html('');
  $("#Thead tr").empty();
  $("#Tbody").empty();
  var Year = $(".Quarter").val();
  var Month = $('#j option:selected').val();
  var Text = $('#j option:selected').text();
  var star_time = Year + "/" + Month + "/" + "01";
  var Star = moment(star_time);
  var time_2 = Star.add(3,'month').format();
  var end = moment(time_2);
  var star = moment(star_time);
  var starTime = star.unix();
  var endTime = end.unix();
  var cheCkd = $("#second_floor").val();
  var all = {
    start_time: starTime,
    end_time: endTime,
    organization_selected: cheCkd,
    interval_type: "monthly"
  };
  $.ajax({
    type: 'get',
    url: '/api/statistics/report/',
    data: all,
    dataType: 'json',
    success: function (data) {
      if (data['organizations_total']['name'] == '') {
        $('.cc').hide();
        $('.hides').show();
        $("#Title").show().html('无数据');
      } else {
        $('.hides').show();
        $('.cc').show();
        var dt = data['organizations_trend'];
        var dn= data['organizations_total'];
        var Name = [];
        var t_n_list = {};
        for (var key in dt){
          for (var j = 0;j < dt[key]['name'].length;j++){
            if (t_n_list[dt[key]['name'][j]] == undefined){
              t_n_list[dt[key]['name'][j]] = {};
            }
            t_n_list[dt[key]['name'][j]][key] = dt[key]['value'][j];
          }
          Name.push(key);
        }
        $("#Thead tr").append('<th>' + '时间' + '</th>');
        for (var n = 0; n < Name.length; n++) {
          $("#Thead tr").append('<th>' + Name[n] + '</th>');
        }
        var one_line = "<tr>";
        for (var time in t_n_list){
          one_line+="<td>" + time + "</td>";
          for (var name in t_n_list[time]){
            one_line+="<td>" + t_n_list[time][name] + "</td>";
          }
          one_line += "</tr>";
        }
        $('#Title').html('汇入数据条数'+ '（'+Year+Text+'）');
        $("#Tbody").append(one_line);
        $('#Tbody').append('<tr id="last">'+'<td>' + '总计' + '</td>'+'</tr>');
        for(var b = 0;b < dn['value'].length; b++){
          $('#Tbody #last').append('<td>' + dn['value'][b] + '</td>');
        }

      }
    }
  })
});
$("#s_semester").click(function(){
  $("#Title").html('');
  $("#Thead tr").empty();
  $("#Tbody").empty();
  var Year = $(".sem").val();
  var Month = $('#year option:selected').val();
  var Text = $('#year option:selected').text();
  var star_time = Year + "/" + Month + "/" + "01";
  var Star = moment(star_time);
  var time_2 = Star.add(5,'month').format();
  var end = moment(time_2);
  var star = moment(star_time);
  //console.log(end);
  //console.log(star);
  var starTime = star.unix();
  var endTime = end.unix();
  var cheCkd = $("#second_floor").val();
  var all = {
    start_time: starTime,
    end_time: endTime,
    organization_selected: cheCkd,
    interval_type: "monthly"
  };
  $.ajax({
    type: 'get',
    url: '/api/statistics/report/',
    data: all,
    dataType: 'json',
    success: function (data) {
      if (data['organizations_total']['name'] == '') {
        $('.cc').hide();
        $('.hides').show();
        $("#Title").show().html('无数据');
      } else {
        $('.hides').show();
        $('.cc').show();
        var dt = data['organizations_trend'];
        var dn= data['organizations_total'];
        var Name = [];
        var t_n_list = {};
        for (var key in dt){
          for (var j = 0;j < dt[key]['name'].length;j++){
            if (t_n_list[dt[key]['name'][j]] == undefined){
              t_n_list[dt[key]['name'][j]] = {};
            }
            t_n_list[dt[key]['name'][j]][key] = dt[key]['value'][j];
          }
          Name.push(key);
        }
        $("#Thead tr").append('<th>' + '时间' + '</th>');
        for (var n = 0; n < Name.length; n++) {
          $("#Thead tr").append('<th>' + Name[n] + '</th>');
        }
        var one_line = "<tr>";
        for (var time in t_n_list){
          one_line+="<td>" + time + "</td>";
          for (var name in t_n_list[time]){
            one_line+="<td>" + t_n_list[time][name] + "</td>";
          }
          one_line += "</tr>";
        }
        $('#Title').html('汇入数据条数'+ '（'+Year+Text+'）');
        $("#Tbody").append(one_line+'<tr id="last">'+'<td>' + '总计' + '</td>'+'</tr>');
        for(var b = 0;b < dn['value'].length; b++){
          $('#Tbody #last').append('<td>' + dn['value'][b] + '</td>')
        }
      }
    }
  })
});
$("#s_year").click(function(){
  $("#Title").html('');
  $("#Thead tr").empty();
  $("#Tbody").empty();
  var Time=$(".Year").val();
  var star_time = Time + "/" + '01' + "/" + '01';
  var Star = moment(star_time);
  var time_2 = Star.add(11,'month').format();
  var end = moment(time_2);
  var star = moment(star_time);
  var starTime = star.unix();
  var endTime = end.unix();
  var cheCkd = $("#second_floor").val();
  var all = {
    start_time: starTime,
    end_time: endTime,
    organization_selected: cheCkd,
    interval_type: "monthly"
  };
  $.ajax({
    type: 'get',
    url: '/api/statistics/report/',
    data: all,
    dataType: 'json',
    success: function (data) {
      if (data['organizations_total']['name'] == '') {
        $('.cc').hide();
        $('.hides').show();
        $("#Title").show().html('无数据');
      } else {
        $('.hides').show();
        $('.cc').show();
        var dt = data['organizations_trend'];
        var dn= data['organizations_total'];
        var Name = [];
        var t_n_list = {};
        for (var key in dt){
          for (var j = 0;j < dt[key]['name'].length;j++){
            if (t_n_list[dt[key]['name'][j]] == undefined){
              t_n_list[dt[key]['name'][j]] = {};
            }
            t_n_list[dt[key]['name'][j]][key] = dt[key]['value'][j];
          }
          Name.push(key);
        }
        $("#Thead tr").append('<th>' + '时间' + '</th>');
        for (var n = 0; n < Name.length; n++) {
          $("#Thead tr").append('<th>' + Name[n] + '</th>');
        }
        var one_line = "<tr>";
        for (var time in t_n_list){
          one_line+="<td>" + time + "</td>";
          for (var name in t_n_list[time]){
            one_line+="<td>" + t_n_list[time][name] + "</td>";
          }
          one_line += "</tr>";
        }
        $('#Title').html('汇入数据条数'+ '（'+Time+'）');
        $("#Tbody").append(one_line+'<tr id="last">'+'<td>' + '总计' + '</td>'+'</tr>');
        for(var b = 0;b < dn['value'].length; b++){
          $('#Tbody #last').append('<td>' + dn['value'][b] + '</td>')
        }
      }
    }
  })
});