$(window).resize(function (){
  myChart1.resize();
  myChart2.resize();
  myChart3.resize();
});
$(document).ready(function () {
  query();
  $.ajax({
    type: 'get',
    url: '/api/src/datatypes/',
    dataType: 'json',
    success: function (data) {
      var props = [];
  var a = 0;
  for(props[a++] in data);
  for (var b = 0; b < props.length; b++) {
    var new_opt = $('<option value="'+props[b]+'">');
    new_opt.html(props[b]);
//    new_opt.data('index',props[b]);
    $("#select").append(new_opt);
    }
    $('#select').on('change',function(){
    $("#select1").empty();
    var index_from_1 = $('#select option:selected').val();
    var select2_list = data[index_from_1];
    for(var value in select2_list){
      $('#select1').append('<option value="'+value+'" selected>'+value+'</option>');
      }
     })
    }
  })
});
(function () {
  var now = new Date();
  var year = now.getFullYear();
  var month = now.getMonth();
  var date = now.getDate();
  var hour = now.getHours();
  var minu = now.getMinutes();
  month = month + 1;
  var month_1=month-1
  if (month < 10) month = "0" + month;
  if (date < 10) date = "0" + date;
  if (hour < 10) hour = "0" + hour;
  if (minu < 10) minu = "0" + minu;
  var time = "";
  time = year + "/" + month + "/" + date + " " + hour + ":" + minu;
  // console.log(time);
  time2 = year + "/" + month_1 + "/" + date + " " + hour + ":" + minu;
  // console.log(time2);
  $('#some_class_1').val(time2);
  $('#some_class_2').val(time);
})();
var myChart1 = echarts.init(document.getElementById('cake'));
myChart1.setOption({
  title: {
    text: '����λ����ռ��',
    subtext: '',
    x: 'center'
  },
  tooltip: {
    trigger: 'item',
    formatter: "{a} <br/>{b} : {c} ({d}%)"
  },
  legend: {
    orient: 'vertical',
    left: 'left',
    data: []
  },
  series: [
    {
      name: '������Դ',
      type: 'pie',
      radius: '55%',
      center: ['50%', '60%'],
      data: [],
      itemStyle: {
        emphasis: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    }
  ]
});
//�ڶ���ͼ��
var myChart2 = echarts.init(document.getElementById('line'));
myChart2.setOption({
  title: {
    text: '����λ��������',
    x: 'center'
  },
  tooltip: {
    trigger: 'axis'
  },
  toolbox: {
    show : true,
    feature : {
      dataView : {show: true, readOnly: false}
    }
  },
  legend: {
    data: [],
    x: 'center',
    top:'30'
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom:'5%',
    top:'30%',
    containLabel: true
  },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: []
  },
  yAxis: {
    type: 'value'
  },
  series: []
});
//3
var myChart3 = echarts.init(document.getElementById('zhuzt'));
myChart3.setOption({
  title: {
    text: '����λ��������',
    left: 'center'
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    }
  },
  toolbox: {
    feature: {
      magicType: {
        type: []
      },
      dataView: {}
    }
  },
  legend: {
    data: ['�Ʒ���']
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '5%',
    containLabel: true
  },
  xAxis: {
    type: 'value',
    boundaryGap: [0, 0.01]
  },
  yAxis: {
    type: 'category',
    data: []
  },
  series: [
    {
      name: '����',
      type: 'bar',
      data: []
    }
  ]
});

function query(){
  var str = $("#some_class_1").val();
  var data = new Date(str);
  var starTime = data.getTime() / 1000;

  var str1 = $("#some_class_2").val();
  var data1 = new Date(str1);
  var endTime = data1.getTime() / 1000;

  var all = {
    start_time: starTime,
    end_time: endTime
  };
  var se = $("#form").serializeArray();
  $.ajax({
    type: 'get',
    url: '/api/statistics/query/',
    data: all,
    dataType: 'json',
    success: function (data) {
      //����λ����ռ��
      (function () {
        var Data = [];
        var Name = data['percentage']['name'];
        var Val=data['percentage']['value'];
        for (var i = 0; i < Name.length; i++) {
          var n={value:Val[i], name:Name[i]};
          Data.push(n);
        }
        myChart1.setOption({
          legend: {
            orient: 'vertical',
            left: 'left',
            data: Name
          },
          series: [
            {
              name: '������Դ',
              type: 'pie',
              radius: '55%',
              center: ['50%', '60%'],
              data: Data,
              itemStyle: {
                emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
              }
            }
          ]
        });
      })();
      //����λ��������
      (function () {
        var series = [];
        var Name = [];
        var n = 0;
        var obj2 = [];
        var dt = data['trend'];
        for (Name[n++] in dt);
        for (var b in dt) {
          obj2.push(dt[b]['value']);
        }
        for (var i = 0; i < Name.length; i++) {
          series.push({
            type: 'line',
            name: Name[i],
            data: obj2[i]
          });
        }
        myChart2.setOption({
          legend: {
            data: Name,
            x: 'center',
            top:'30' 

          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            data: data["trend"]["shadowserver.org"]["name"]
          },
          yAxis: {
            type: 'value'
          },
          series: series
        });
      })();
      //����λ��������
      myChart3.setOption({
        yAxis: {
          type: 'category',
          data: data.counts.name
        },
        series: [
          {
            name: '����',
            type: 'bar',
            data: data.counts.value
          }
        ]
      });
    }
  })
}
query();