/**
 * Created by FF on 2016/9/5.
 */
$.ajax({
    type: 'get',
    url: '/api/homeinfo/',
    data: 'all',
    dataType: 'json',
    success: function (data) {
        $('.total').html(data.disk.totalsize);
        $('.file').html(data.disk.filesize);
        $('.db').html(data.disk.dbsize);
        $('.days').html(data.time.days);
        $('.info_in').html(data.info_counts.organizations_counts_in);
        $('.info_out').html(data.info_counts.organizations_counts_out);
        //表格
        var D = data.categories_statistics;
        var cat = [];
        for (cat in D) {
            $('.tbody').append('<tr>' + '<td>' + cat + '</td>' + '<td>' + D[cat]['in'] + '</td>' + '<td>' + D[cat]['out'] + '</td>' + '</tr>')
        }
        //威胁汇入
        var myTh_in = echarts.init(document.getElementById('th_in'));
        myTh_in.setOption({
            backgroundColor:'#fff',
            title: {
                text: '汇入威胁类型TOP5',
                x: 'center'
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: data.topn_intelligence_types_in.name
            },
            grid: {
                left: '3%',
                right: '15%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                name: '条数',
                type: 'value',
                minInterval: 1,
                // boundaryGap: [0, 0.01],
                axisLabel: {
                    interval: 0,
                    margin: 4
                }
            },
            yAxis: {
                type: 'category',
                data: data.topn_intelligence_types_in.name
            },
            series: {
                name: '',
                type: 'bar',
                label: {
                    normal: {
                        show: true,
                        position: 'right'
                    }
                },
                data: data.topn_intelligence_types_in.value
            }
        })
        //威胁汇出
        var myTh_out = echarts.init(document.getElementById('th_out'));
        myTh_out.setOption({
            backgroundColor:'#fff',
            title: {
                text: '汇出威胁类型TOP5',
                x: 'center'
            },
            color: ['#546570'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: data.topn_intelligence_types_out.name
            },
            grid: {
                left: '3%',
                right: '20%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                name: '条数',
                type: 'value',
                minInterval: 1
                // boundaryGap: [0, 0.01]
            },
            yAxis: {
                type: 'category',
                data: data.topn_intelligence_types_out.name
            },
            series: {
                name: '',
                type: 'bar',
                label: {
                    normal: {
                        show: true,
                        position: 'right'
                    }
                },
                data: data.topn_intelligence_types_out.value
            }
        })
        //情报来源组织TOP5
        var myLine_in = echarts.init(document.getElementById('top_in'));
        myLine_in.setOption({
            backgroundColor:'#fff',
            title: {
                text: '情报来源组织TOP5',
                x: 'center'
            },
            color: ['#3572B0','#eee'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: data.topn_organizations_in.name
            },
            grid: {
                left: '3%',
                right: '15%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                name: '条数',
                type: 'value',
                minInterval: 1,
                // boundaryGap: [0, 0.01],
                axisLabel: {
                    interval: 0,
                    margin: 10
                }
            },
            yAxis: {
                type: 'category',
                data: data.topn_organizations_in.name
            },
            series: {
                name: '',
                type: 'bar',
                label: {
                    normal: {
                        show: true,
                        position: 'right'
                    }
                },
                data: data.topn_organizations_in.value
            }
        })
        //汇出TOP5
        var myLine_out = echarts.init(document.getElementById('top_out'));
        myLine_out.setOption({
            backgroundColor:'#fff',
            title: {
                text: '情报汇出组织TOP5',
                x: 'center'
            },
            color: ['#3572B0'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: data.topn_organizations_out.name
            },
            grid: {
                left: '3%',
                right: '20%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                name: '条数',
                type: 'value',
                minInterval: 1
                // boundaryGap: [0, 0.01]
            },
            yAxis: {
                type: 'category',
                data: data.topn_organizations_out.name
            },
            series: {
                name: '',
                type: 'bar',
                label: {
                    normal: {
                        show: true,
                        position: 'right'
                    }
                },
                data: data.topn_organizations_out.value
            }
        })
//联动汇出饼图
        var dt = [];
        var dt2 = data.category_and_organization_in.detail;
        for (a in dt2)
            var Data = [];
        for (var i = 0; i < data.category_and_organization_in.name.length; i++) {
            var n = {
                value: data.category_and_organization_in.value[i],
                name: data.category_and_organization_in.name[i]
            };
            var g = (data.category_and_organization_in.name[i].toString());
            $('#mouse').append('<li class="lis" style="margin-left: 24%;width:42%;">' + g + '</li>');
            Data.push(n);
        }


        var myCake1 = echarts.init(document.getElementById('cake1'));
//联动汇入饼图
        myCake1.setOption({
            backgroundColor:'#fff',
            title: {
                text: '汇入数据',
                subtext: '',
                x: 'center'
            },
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                data: a
            },
            series: [
                {
                    name: [],
                    type: 'pie',
                    radius: '55%',
                    center: ['50%', '60%'],
                    data: Data,
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        });
        $('.reset').click(function () {
            myCake1.setOption({
                backgroundColor:'#fff',
                title: {
                    text: '汇入数据'
                },
                series: [
                    {
                        name: [],
                        type: 'pie',
                        radius: '55%',
                        center: ['50%', '60%'],
                        data: Data,
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            })
        });
        $('.lis').click(function () {
            var lis = $(this).text();

            var Dt = [];
            for (var i = 0; i < data['category_and_organization_in']['detail'][lis].name.length; i++) {
                var f = {
                    value: data['category_and_organization_in']['detail'][lis].value[i],
                    name: data['category_and_organization_in']['detail'][lis].name[i]
                };
                Dt.push(f);
            }
            myCake1.setOption({
                backgroundColor:'#fff',
                title: {
                    text: lis
                },
                series: [
                    {
                        name: [],
                        type: 'pie',
                        radius: '55%',
                        center: ['50%', '60%'],
                        data: Dt,
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            })

        });
        var myLine1 = echarts.init(document.getElementById('in_side'));
        myLine1.setOption({
            backgroundColor:'#fff',
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: ['']
            },
            grid: {
                left: '3%',
                right: '20%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                name: '条数',
                type: 'value',
                minInterval: 1
                // boundaryGap: [0, 0.01]
            },
            yAxis: {
                type: 'category',
                data: ['']
            },
            series: {
                name: '',
                type: 'bar',
                label: {
                    normal: {
                        show: true,
                        position: 'right'
                    }
                },
                data: ['']
            }
        })
        var txt_val = [];
        $('#mouse li').click(function () {
            var txt = $(this).text();
            txt_val = txt;
            myLine1.setOption({
                backgroundColor:'#fff',
                title: {
                    text: txt_val,
                    x: 'center'
                },
                legend: {
                    data: data['category_and_organization_in']['detail'][txt_val].name
                },
                yAxis: {
                    data: data['category_and_organization_in']['detail'][txt_val].name
                },
                series: {
                    name: data['category_and_organization_in']['detail'][txt_val].name,
                    data: data['category_and_organization_in']['detail'][txt_val].value
                }
            })
        })

        myCake1.on('click', function (param) {
            var d = [];
            d.push(param.data.name);
            var e = (d.toString());
            myLine1.setOption({
                backgroundColor:'#fff',
                title: {
                    text: e,
                    x: 'center'
                },
                legend: {
                    data: data['category_and_organization_in']['detail'][txt_val]['detail'][e].name
                },
                yAxis: {
                    data: data['category_and_organization_in']['detail'][txt_val]['detail'][e].name
                },
                series: {
                    name: data['category_and_organization_in']['detail'][txt_val]['detail'][e].name,
                    data: data['category_and_organization_in']['detail'][txt_val]['detail'][e].value
                }
            })
        })
//联动汇入
        var Data_out = [];
        for (var i = 0; i < data.category_and_organization_out.name.length; i++) {
            var m = {
                value: data.category_and_organization_out.value[i],
                name: data.category_and_organization_out.name[i]
            };
            var l = (data.category_and_organization_out.name[i].toString());
            $('#mouse_out').append('<li class="lis_out" style="margin-left: 24%;width:42%;">' + l + '</li>');
            Data_out.push(m);
        }
        var myCake2 = echarts.init(document.getElementById('cake2'));
//联动汇入饼图
        myCake2.setOption({
            backgroundColor:'#fff',
            title: {
                text: '汇出数据',
                subtext: '',
                x: 'center'
            },
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                data: ['']
            },
            series: [
                {
                    name: [],
                    type: 'pie',
                    radius: '55%',
                    center: ['50%', '60%'],
                    data: Data_out,
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        });
        $('.reset_out').click(function () {
            backgroundColor:'#fff',
            myCake2.setOption({
                title: {
                    text: '汇出数据'
                },
                series: [
                    {
                        name: [],
                        type: 'pie',
                        radius: '55%',
                        center: ['50%', '60%'],
                        data: Data_out,
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            })
        });
        $('.lis_out').click(function () {
            var lis_out = $(this).text();
            var Dt_out = [];
            for (var i = 0; i < data['category_and_organization_out']['detail'][lis_out].name.length; i++) {
                var h = {
                    value: data['category_and_organization_out']['detail'][lis_out].value[i],
                    name: data['category_and_organization_out']['detail'][lis_out].name[i]
                };
                Dt_out.push(h);
            }
            myCake2.setOption({
                backgroundColor:'#fff',
                title: {
                    text: lis_out
                },
                series: [
                    {
                        name: [],
                        type: 'pie',
                        radius: '55%',
                        center: ['50%', '60%'],
                        data: Dt_out,
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            })
        });
        var myLine2 = echarts.init(document.getElementById('out_side'));
        myLine2.setOption({
            backgroundColor:'#fff',
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: ['']
            },
            grid: {
                left: '3%',
                right: '20%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                name: '条数',
                type: 'value',
                minInterval: 1
                // boundaryGap: [0, 0.01]
            },
            yAxis: {
                type: 'category',
                data: ['']
            },
            series: {
                name: '',
                type: 'bar',
                label: {
                    normal: {
                        show: true,
                        position: 'right'
                    }
                },
                data: ['']
            }
        })
        var txt_val_out = [];
        $('#mouse_out li').click(function () {
            var txt_out = $(this).text();
            txt_val_out = txt_out;
            myLine2.setOption({
                backgroundColor:'#fff',
                title: {
                    text: txt_val_out,
                    x: 'center'
                },
                legend: {
                    data: data['category_and_organization_out']['detail'][txt_val_out].name
                },
                yAxis: {
                    data: data['category_and_organization_out']['detail'][txt_val_out].name
                },
                series: {
                    name: data['category_and_organization_out']['detail'][txt_val_out].name,
                    data: data['category_and_organization_out']['detail'][txt_val_out].value
                }
            })
        });
        myCake2.on('click', function (param) {
            var d_out = [];
            d_out.push(param.data.name);
            var e_out = (d_out.toString());
            myLine2.setOption({
                backgroundColor:'#fff',
                title: {
                    text: e_out,
                    x: 'center'
                },
                legend: {
                    data: data['category_and_organization_out']['detail'][txt_val_out]['detail'][e_out].name
                },
                yAxis: {
                    data: data['category_and_organization_out']['detail'][txt_val_out]['detail'][e_out].name
                },
                series: {
                    name: data['category_and_organization_out']['detail'][txt_val_out]['detail'][e_out].name,
                    data: data['category_and_organization_out']['detail'][txt_val_out]['detail'][e_out].value
                }
            })
        })
//威胁占比
        var dt_in = [];
        for (var i = 0; i < data.intelligence_types_in.name.length; i++) {
            var s = {
                value: data.intelligence_types_in.value[i],
                name: data.intelligence_types_in.name[i]
            };
            dt_in.push(s);
        }
        var myTh_cake = echarts.init(document.getElementById('th_cake'));
        myTh_cake.setOption({
            backgroundColor:'#fff',
            title: {
                text: '汇入威胁类型占比',
                subtext: '',
                x: 'center'
            },
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                data: data.intelligence_types_in.name
            },
            series: [
                {
                    name: [],
                    type: 'pie',
                    radius: '55%',
                    center: ['50%', '60%'],
                    data: dt_in,
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        })
        $(window).resize(function () {
            myLine_in.resize();
            myLine_out.resize();
            myTh_in.resize();
            myTh_out.resize();
            myTh_cake.resize();
            myCake1.resize();
            myCake2.resize();
            myLine1.resize();
            myLine2.resize();
        });
    }
})






