/**
 * Created by han on 2016/9/12.
 */
$(".a").children('a').children('b').addClass('jian');
$.ajax({
  url: "/static/templates/rule_in_template.html",
  async: false,
  dataType: 'html',
  success: function (data) {
    $("#iframe").html(data);
  }
});
$("#select_all").click(function () {
  var isChecked = $(this).prop("checked");
  $("input[name='ipt']").prop("checked", isChecked);
});

$('.first_tab').click(function () {
  $('#mail_test').hide();
  $('.active-tab span').html('APCERT');
  $('.modal-body').css('height', '270px');
});
$('.second_tab').click(function () {
  $('#mail_test').hide();
  $('.active-tab span').html('FTP');
  $('.modal-body').css('height', '440px');
});
$('.third_tab').click(function () {
  $('#mail_test').show();
  $('.active-tab span').html('Email');
  $('.modal-body').css('height', '480px');
});
//
$('#get_files').click(function () {
  $('#choose').empty();
  $('#dir_done').empty();
  var passpor = $('#passport').val();
  var passwor = $('#pass').val();
  var por = $('#numb').val();
  var serve = $('#server').val();
  var data_ee;
  if ($('#ssl').prop("checked")) {
    data_ee = {
      server: serve,
      port: por,
      mail_account: passpor,
      password: passwor,
      use_ssl: true
    }
  } else {
    data_ee = {
      server: serve,
      port: por,
      mail_account: passpor,
      password: passwor,
      use_ssl: false
    }
  }
  $.ajax({
    type: 'post',
    url: '/api/test/emailfolders/',
    dataType: 'json',
    data: data_ee,
    beforeSend: function () {
      $(".se_test").html('获取中...');
    },
    complete: function () {
      $(".se_test").html('');

    },
    success: function (data) {
      console.log(data);
      if (data.result == true) {
        for (var i = 0; i < data.info.length; i++) {
          var new_op = '<option value="' + data.info[i].dirname + '">';
          new_op += 'flag:' + data.info[i].flag;
          new_op += 'dirname:' + data.info[i].dirname;
          new_op += '</option>';
          $('#choose').append(new_op).selectpicker('refresh');
          $('#dir_done').append(new_op).selectpicker('refresh');
        }
      } else {

      }
    }
  })
})
var emailid;
$("#return1").click(function () {
  $("#myModal").modal("show");
  $("#new_modal").modal("hide");
  var re = $(".ac").text();
  var id = $('.ac').data('id');
  $("#ews").html(re);
  // $("#ews").data("id", id)
  emailid = id;
  // console.log(emailid);
});
var test_scri;
$('#mail_test').click(function () {
  $('#ip_type').html('').selectpicker('refresh');
  $('#hash_type').html('').selectpicker('refresh');
  $('#url_type').html('').selectpicker('refresh');
  var passport = $('#passport').val();
  var password = $('#pass').val();
  var port = $('#numb').val();
  var serve = $('#server').val();
  var dirfrom = $('#choose option:selected').val();
  var donedir = $('#dir_done option:selected').val();
  var mailtitle = $('#mail_title').val();
  var data_ee;
  if ($('#ssl').prop("checked")) {
    data_ee = {
      transport_type: 'email',
      transport_detail: {
        server: serve,
        port: port,
        mail_account: passport,
        password: password,
        use_ssl: true,
        dir_from: dirfrom,
        done_dir: donedir,
        mail_title_regex: mailtitle
      },
      script_id: scripid
    };
  } else {
    data_ee = {
      transport_type: 'email',
      'transport_detail': {
        server: serve,
        port: port,
        mail_account: passport,
        password: password,
        use_ssl: false,
        dir_from: dirfrom,
        done_dir: donedir,
        mail_title_regex: mailtitle
      },
      script_id: scripid
    };
  }
  $.ajax({
    type: 'post',
    url: '/api/test/reportfields/',
    dataType: 'json',
    data: JSON.stringify(data_ee),
    beforeSend: function () {
      $(".mail_ce").html('测试中...');
    },
    complete: function () {
      $(".mail_ce").html('');
    },
    success: function (data) {
      var test_scr = [];
      for (c in data.info)
        test_scr.push(data.info[c]);
      test_scri=test_scr;
      for (var i = 0; i < test_scr.length; i++) {
        var newop = '<option value="'+test_scr[i]+'">';
        newop += test_scr[i];
        newop += '</option>'
        $('#ip_type').append(newop).selectpicker('refresh');
        $('#hash_type').append(newop).selectpicker('refresh');
        $('#url_type').append(newop).selectpicker('refresh');
      }
    }
  })
})

var Data = [];
var scripid;
$(document).ready(function () {
  $.ajax({
    type: 'get',
    url: '/api/rules/in/',
    dataType: 'json',
    success: function (data) {
      Data = data;
      for (var i = 0; i < data.info.length; i++) {
        if (data.info[i].enable == true) {
          $('#tb_in').append('<tr class="get_tag">' + '<td>' + data.info[i].rule_name + '</td>'
            // + '<td>' + data.info[i].datatype + '</td>'
            + '<td>' + data.info[i].enrich.origin_organization.name + '</td>>'
            + '<td>' + data.info[i].process.transport_type + '</td>>'
            + '<td>' + data.info[i].data_storage.month_reserved + '</td>'
            + '<td>' + '<input checked type="checkbox" name="input" data-size="small" class="switch">' + '</td>'
            + '<td>' + '<a herf="#" data-toggle="modal" data-target="#myModal" class="rule_edit">' + '编辑' + '</a>' + '</td>'
            + '<td>' + '<a class="del text-danger">' + '删除' + '</a>' + '</td>'
            + '<td>' + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + '<input type="checkbox" name="ipt">' + '</td>' + '</tr>');
        } else {
          $('#tb_in').append('<tr class="get_tag">' + '<td>' + data.info[i].rule_name + '</td>'
            // + '<td>' + data.info[i].datatype + '</td>'
            + '<td>' + data.info[i].enrich.origin_organization.name + '</td>>'
            + '<td>' + data.info[i].process.transport_type + '</td>>'
            + '<td>' + data.info[i].data_storage.month_reserved + '</td>'
            + '<td>' + '<input type="checkbox" name="input" data-size="small" class="switch">' + '</td>>'
            + '<td>' + '<a herf="#" data-toggle="modal" data-target="#myModal" class="rule_edit">' + '编辑' + '</a>' + '</td>'
            + '<td>' + '<a class="del text-danger">' + '删除' + '</a>' + '</td>'
            + '<td>' + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + '<input type="checkbox" name="ipt">' + '</td>' + '</tr>')
        }
      }
      //编辑

      $('.rule_edit').click(function () {

        $('#ip_type').html('').selectpicker('refresh');
        $('#hash_type').html('').selectpicker('refresh');
        $('#url_type').html('').selectpicker('refresh');
        $('#choose').html('');
        $('#dir_done').html('');
        $('.clm').html('');
        $('.insert').html('');
        $('#myModalLabel').html('编辑策略');
        $('#myTabContent input').val('');
        $('#numb').val('993');
        var e_index = $(".rule_edit").index(this);
        scripid=data.info[e_index].process.script_id;
        $('#inputText').val(Data.info[e_index].rule_name);
        $('#storage_duration').val(Data.info[e_index].data_storage.month_reserved);
        $('.dropdown').hide();
        if (Data.info[e_index].process.transport_type == 'email') {
          $('#mail_edit').show();
          $('#mail_submit').hide();
          $.ajax({
            type: 'get',
            url: '/api/pyscripts/simple/',
            dataType: 'json',
            success: function (datass) {
              for (var i = 0; i < datass.info.length; i++) {
                if (datass.info[i]._id == data.info[e_index].process.script_id) {
                  var cat_script = datass.info[i].name;
                  $('#ews').html(cat_script);
                }
              }
            }
          })
          $('#storage_duration option[value="' + Data.info[e_index].data_storage.month_reserved + '"]').attr("selected", true);
          $('#mail_test').show();
          $('#firstWay').removeClass('in active');
          $('#secondWay').removeClass('in active');
          $('#thirdWay').removeClass('in active');
          $('#thirdWay').addClass('in active');
          $('#mail_title').val(Data.info[e_index].process.transport_detail.mail_title_regex);
          $('#passport').val(Data.info[e_index].process.transport_detail.mail_account);
          $('#pass').val(Data.info[e_index].process.transport_detail.password);
          $('#numb').val(Data.info[e_index].process.transport_detail.port);
          $('#server').val(Data.info[e_index].process.transport_detail.server);
          $('#choose').val(Data.info[e_index].process.transport_detail.dir_done);
          $('#organization_name').val(Data.info[e_index].enrich.origin_organization.name);
          $('#brief_name').val(Data.info[e_index].enrich.origin_organization.brief_name);
          $('#category option[value="' + Data.info[e_index].enrich.intelligence_type.category + '"]').attr("selected", true);
          $('#subcategory option[value="' + Data.info[e_index].enrich.intelligence_type.subcategory + '"]').attr("selected", true);
          $('#choose').append('<option>' + Data.info[e_index].process.transport_detail.dir_from + '</option>').selectpicker('refresh');
          $('#dir_done').append('<option>' + Data.info[e_index].process.transport_detail.dir_done + '</option>').selectpicker('refresh');
          var mailtitle = $('#mail_title').val();
          $('#mail_edit').click(function () {
            var dirfrom = $('#choose option:selected').val();
            var donedir = $('#dir_done option:selected').val();
            var rule_name = $('#inputText').val();
            var passport = $('#passport').val();
            var password = $('#pass').val();
            var port = $('#numb').val();
            var server = $('#server').val();
            var storage_duration = $('#storage_duration option:selected').val();
            var secret = $('#secret option:selected').val();
            var organization_name = $('#organization_name').val();
            var brief_name = $('#brief_name').val();
            var sub_category = $('#subcategory option:selected').val();
            var ip_type = $('#ip_type').val();
            var url_type = $('#url_type').val();
            var hash_type = $('#hash_type').val();
            var category = $('#category option:selected').val();
            var future_fields = $('#future_fields option:selected').val();
            if ($('#ssl').prop("checked")) {
              var edit = {
                '_id': Data.info[e_index]._id,
                'rule_action': 'update',
                'rule_name': rule_name,
                process: {
                  'transport_type': 'email',
                  transport_detail: {
                    'server': server,
                    'dir_done': donedir,
                    'dir_from': dirfrom,
                    'mail_account': passport,
                    'port': port,
                    'use_ssl': true,
                    'password': password,
                    'mail_title_regex': mailtitle
                  },
                  'script_id': emailid
                },
                'enrich': {
                  'origin_organization': {
                    'name': organization_name,
                    'brief_name': brief_name,
                    'category': category
                  },
                  intelligence_type: {
                    'category': future_fields,
                    'subcategory': sub_category,
                    'future_fields': {
                      'url': url_type,
                      'ip': ip_type,
                      'hash': hash_type
                    }
                  }
                },
                'data_storage': {
                  'month_reserved': storage_duration
                }
              }
            } else {
              var edit = {
                '_id': Data.info[e_index]._id,
                'rule_action': 'update',
                'rule_name': rule_name,
                process: {
                  'transport_type': 'email',
                  transport_detail: {
                    'server': server,
                    'dir_done': donedir,
                    'dir_from': dirfrom,
                    'mail_account': passport,
                    'port': port,
                    'use_ssl': false,
                    'password': password,
                    'mail_title_regex': mailtitle
                  },
                  'script_id': emailid
                },

                'enrich': {
                  // 'secret_level': secret,
                  'origin_organization': {
                    'name': organization_name,
                    'brief_name': brief_name,
                    'category': category
                  },
                  intelligence_type: {
                    'category': future_fields,
                    'subcategory': sub_category,
                    'future_fields': {
                      'url': url_type,
                      'ip': ip_type,
                      'hash': hash_type
                    }
                  }
                },
                'data_storage': {
                  'month_reserved': storage_duration
                }
              }
            }
            $.ajax({
              type: 'post',
              url: '/api/rules/in/',
              data: JSON.stringify(edit),
              dataType: 'json',
              success: function (data) {
                console.log(data);
                if (data['result'] == true) {
                  alert('修改成功');
                  window.location.herf = '/rules/in/';
                } else {
                  alert('提交失败');
                }
              }
            })
          })
        } else if (Data.info[e_index].process.transport_type == 'web_api') {
          $('#mail_test').hide();
          $('#firstWay').removeClass('in active');
          $('#secondWay').removeClass('in active');
          $('#thirdWay').removeClass('in active');
          $('#firstWay').addClass('in active');
          if (Data.info[e_index].enrich.secret_level == 'open') {
            $('#rule_open').attr('checked', '')
          } else {
            $('#rule_secret').attr('checked', '')
          }
          $('#ma').on('click', function () {
            var rule_name = $('#inputText').val();
            var organization_name = $('#organization_name').val();
            var brief_name = $('#brief_name').val();
            var category = $('#category').val();
            var secret = $('#secret option:selected').val();
            var storage_duration = $('#storage_duration option:selected').val();
            var edit =
            {
              'rule_name': rule_name,
              _id: Data.info[e_index]._id,
              rule_action: 'update',
              process: {
                'transport_type': 'web_api',
                transport_detail: {
                  'allowed_organization': [],
                  'allowed_datatypes': []
                },
                'script_id': ''//脚本id
              },

              'enrich': {
                'origin_organization': {
                  'name': organization_name,
                  'brief_name': brief_name,
                  'category': category
                },
                'intelligence_type': {
                  // 'contained_types': ['url', 'ip'],//
                  // 'future_fields': {
                  //   'url': [],//
                  //   'ip': [],
                  //   'hash': []
                  // },
                }
              },
              'data_storage': {
                'month_reserved': storage_duration
              }
            };
            $.ajax({
              type: 'post',
              url: '/api/rules/in/',
              data: JSON.stringify(edit),
              dataType: 'json',
              success: function (data) {
                console.log(data);
                if (data['result'] == true) {
                  window.location.herf = '/rules/in/';
                } else {
                  alert('提交失败');
                }
              }
            })
          })
        } else {
          $('#mail_test').hide();
          $('#firstWay').removeClass('in active');
          $('#secondWay').removeClass('in active');
          $('#thirdWay').removeClass('in active');
          $('#secondWay').addClass('in active');
          $('#inputText').val(Data.info[e_index].rule_name);
          $('#origin').val(Data.info[e_index].enrich.origin_organization.name);
          $('#storage_duration').val(Data.info[e_index].data_storage.month_reserved);
          $('#organization_name').val(Data.info[e_index].enrich.origin_organization.name)
          $('#brief_name').val(Data.info[e_index].enrich.origin_organization.brief_name)
          $('#category').val(Data.info[e_index].enrich.origin_organization.category)
          // $('#ip').val(Data.info[e_index].process.transport_detail)
          $('#addre').val(Data.info[e_index].process.transport_detail.password);
          $('#file_position').val(Data.info[e_index].process.transport_detail.dir_from);
          $('#target').val(Data.info[e_index].process.transport_detail.dir_done);
          $('#num').val(Data.info[e_index].process.transport_detail.port);
          if (Data.info[e_index].enrich.secret_level == 'open') {
            $('#rule_open').attr('checked', '')
          } else {
            $('#rule_secret').attr('checked', '')
          }
          $('#t').on('click', function () {
            var rule_name = $('#inputText').val();
            var organization_name = $('#organization_name').val();
            var brief_name = $('#brief_name').val();
            var category = $('#category').val();
            var storage_duration = $('#storage_duration option:selected').val();
            var secret = $('#secret option:selected').val();
            var addre = $('#addre').val();
            var target = $('#target').val();
            var num = $('#num').val();
            var ftp_ip = $('ip').val();
            var file_position = $('#file_position').val();
            var edit =
            {
              _id: Data.info[e_index]._id,
              rule_action: 'update',
              'rule_name': rule_name,
              process: {
                'transport_type': 'ftp',
                transport_detail: {
                  'ip': ftp_ip,
                  'password': addre,
                  'dir_from': file_position,
                  'dir_done': target,
                  'port': num
                },
                'script_id': ''//脚本id
              },
              'enrich': {
                'origin_organization': {
                  'name': organization_name,//来源单位
                  'brief_name': brief_name,//来源简称
                  'category': category//来源类型
                },
                'intelligence_type': {
                  // 'contained_types': ['url', 'ip'],//
                  // 'future_fields': {
                  //   'url': [],//
                  //   'ip': [],
                  //   'hash': []
                  // },
                }
              },
              'data_storage': {
                'month_reserved': storage_duration
              }
            }
            $.ajax({
              type: 'post',
              url: '/api/rules/in/',
              data: JSON.stringify(edit),
              dataType: 'json',
              success: function (data) {
                console.log(data);
                if (data['result'] == true) {
                  window.location.herf = '/rules/in/';
                } else {
                  alert('提交失败');
                }
              }
            })
          })
        }
      });
      // 启用关闭
      $('input[name="input"]').on('switchChange.bootstrapSwitch', function () {
        m = $(this).parents("tr").index();
        if ($(this).is(':checked')) {
          var action = {
            rule_action: 'update',
            _id: Data.info[m]._id,
            enable: true
          };

        } else {
          var action = {
            rule_action: 'update',
            _id: Data.info[m]._id,
            enable: false
          };
        }
        $.ajax({
          type: 'post',
          url: '/api/rules/in/',
          data: JSON.stringify(action),
          dataType: 'json',
          success: function (data) {
            if (data['result'] == true) {
            } else {
              alert('提交失败');
            }
          }
        })
      });
      $(".switch").bootstrapSwitch();
      //单个删除
      var del_index;
      $(".del").click(function () {
        $("#bg,#bg_two").fadeIn();
        $(".remove").hide();
        $(".delete").show();
        del_index = $('.del').index(this);
      });
      $(".res").click(function () {
        $("#bg,#bg_two").fadeIn();
        $(".remove").show();
        $(".delete").hide();
      });
      $('.delete').click(function () {
        var s_id = data.info[del_index]._id;
        var ss_id = [];
        ss_id.push(s_id);
        var all = {
          '_idlist': ss_id
        };
        $.ajax({
          type: 'post',
          url: '/api/rules/in/bulkinvalid/',
          data: all,
          dataType: 'json',
          success: function (data) {
            console.log(data);
            if (data['result'] == true) {
              window.location.href = '/rules/in/';
            } else {
              alert('删除失败');
            }
          }
        });
        $("#bg,#bg_two").hide();
      })
    }
  })
});
//批量删除
$('.remove').click(function () {
  var list = [];
  $("input[name='ipt']:checked").each(function () {// 遍历选中的checkbox
    n = $(this).parents("tr").index();// 获取checkbox所在行的顺序
    list.push(Data.info[n]._id);

  });
  $.ajax({
    type: 'post',
    url: '/api/rules/in/bulkinvalid/',
    data: {
      '_idlist': list
    },
    dataType: 'json',
    success: function (data) {
      console.log(data);
      if (data['result'] == true) {
        window.location.href = '/rules/in/';
      } else {
        alert('删除失败');
      }
    }
  });
  $("#bg,#bg_two").hide();
});
$('.create').click(function () {
  $('#ip_type').html('').selectpicker('refresh');
  $('#hash_type').html('').selectpicker('refresh');
  $('#url_type').html('').selectpicker('refresh');
  $('#mail_edit').hide();
  $('#mail_submit').show();
  $('.insert').html('');
  // $('.mail_btn').html('<button class="btn btn-default" id="mail_submit">提交</button>');
  $('.dropdown').show();
  $('#myModalLabel').html('新建策略');
  $('#myTabContent input').val('');
  $('#choose').html('').selectpicker('refresh');
  $('#dir_done').html('').selectpicker('refresh');
  $('.modal-body input').val('');
  $('#mail_submit').click(function () {
    var rule_name = $('#inputText').val();
    var passport = $('#passport').val();
    var password = $('#pass').val();
    var port = $('#numb').val();
    var server = $('#server').val();
    var dir_done = $('#choose option:selected').val();
    var dirfrom = $('#choose option:selected').val();
    var storage_duration = $('#storage_duration option:selected').val();
    var organization_name = $('#organization_name').val();
    var brief_name = $('#brief_name').val();
    var category = $('#category').val();
    var mailtitle = $('#mail_title').val();
    var sub_category = $('#subcategory option:selected').val();
    var ip_type = $('#ip_type').val();
    var url_type = $('#url_type').val();
    var hash_type = $('#hash_type').val();
    // var ip_type=[],url_type=[],hash_type=[];
    // ip_type.push(ip);
    // url_type.push(url);
    // hash_type.push(hash);
    var future_fields = $('#future_fields option:selected').val();
    if ($('#ssl').prop("checked")) {
      var data_in = {
        'rule_name': rule_name,
        'process': {
          'transport_type': 'email',
          'transport_detail': {
            'server': server,
            'dir_done': dir_done,
            'dir_from': dirfrom,
            'mail_account': passport,
            'port': port,
            'use_ssl': true,
            'password': password,
            'mail_title_regex': mailtitle
          },
          'script_id': emailid
        },
        'enrich': {
          // 'secret_level': secret,
          'origin_organization': {
            'name': organization_name,
            'brief_name': brief_name,
            'category': category
          },
          'intelligence_type': {
            'category': future_fields,
            'subcategory': sub_category,
            'future_fields': {
              'url': url_type,
              'ip': ip_type,
              'hash': hash_type
            }
          },
          'field_names':test_scri
        },
        'data_storage': {
          'month_reserved': storage_duration
        }
      }
    } else {
      var data_in = {
        'rule_name': rule_name,
        'process': {
          'transport_type': 'email',
          'transport_detail': {　//传输协议类型 email,ftp,web api
            'server': server,
            'dir_done': dir_done,
            'dir_from': dirfrom,
            'mail_account': passport,
            'port': port,
            'use_ssl': false,
            'password': password,
            'mail_title_regex': mailtitle
          },
          'script_id': emailid
        },

        'enrich': {
          // 'secret_level': secret,
          'origin_organization': {
            'name': organization_name,
            'brief_name': brief_name,
            'category': category
          },
          'intelligence_type': {
            'category': future_fields,
            'subcategory': sub_category,
            'future_fields': {
              'url': url_type,
              'ip': ip_type,
              'hash': hash_type
            }
          },
          'field_names':test_scri
        },
        'data_storage': {
          'month_reserved': storage_duration
        }
      }
    }
    $.ajax({
      type: 'POST',
      url: '/api/rules/in/',
      data: JSON.stringify(data_in),
      datatype: 'json',
      success: function (data) {
        var data_create = JSON.parse(data);
        if (data_create['result'] == true) {
          alert('新建成功')
          // window.location = '/rules/in/';
        } else {
          alert('新建失败');
        }
      }
    })

  });
});
//web api
$('.create').click(function () {
  $('.insert').html('');
  $('.dropdown').show();
  $('#myModalLabel').html('新建策略');
  $('#myTabContent input').val('');
  $('.modal-body input').val('');
  $('#ma').click(function () {
    if ($('.define input') == '') {
      alert('输入不完整')
    } else {
      var rule_name = $('#inputText').val();
      var organization_name = $('#organization_name').val();
      var brief_name = $('#brief_name').val();
      var category = $('#category').val();
      var secret = $('#secret option:selected').val();
      var storage_duration = $('#storage_duration').val();
      var data_in =
      {
        'rule_name': rule_name,
        process: {
          'transport_type': 'web_api',
          transport_detail: {
            'allowed_organization': [],
            'allowed_datatypes': []
          },
          'script_id': ''//脚本id
        },

        'enrich': {
          'secret_level': secret,
          'origin_organization': {
            'name': organization_name,
            'brief_name': brief_name,
            'category': category
          },
          'intelligence_type': {
            // 'contained_types': ['url', 'ip'],//
            // 'future_fields': {
            //   'url': [],//
            //   'ip': [],
            //   'hash': []
            // },
          }
        },
        'data_storage': {
          'month_reserved': storage_duration
        }
      }
      $.ajax({
        type: 'POST',
        url: '/api/rules/in/',
        data: JSON.stringify(data_in),
        datatype: 'json',
        success: function (data) {
          var data_create = JSON.parse(data);
          if (data_create['result'] == true) {
            alert('提交成功');
            // window.location = '/rules/in/';
          } else {
            alert('提交失败');
          }
        }
      })
    }
  });
});
//ftp
$('.create').click(function () {
  $('.insert').html('');
  $('.dropdown').show();
  $('#myModalLabel').html('新建策略');
  $('#myTabContent input').val('');
  $('.modal-body input').val('');
  $('#t').click(function () {
    var rule_name = $('#inputText').val();
    var organization_name = $('#organization_name').val();
    var brief_name = $('#brief_name').val();
    var category = $('#category').val();
    var storage_duration = $('#storage_duration').val();
    var secret = $('#secret option:selected').val();
    var addre = $('#addre').val();
    var target = $('#target').val();
    var num = $('#num').val();
    var ftp_ip = $('ip').val();
    var file_position = $('#file_position').val();
    if ($('.define input') == '') {
      alert('输入不完整')
    } else {
      var data_type = $('#type_ftp').val();
      var data_in =
      {
        'rule_name': rule_name,
        'datatype': data_type,
        process: {
          'transport_type': 'ftp',
          transport_detail: {
            'ip': ftp_ip,
            'password': addre,
            'dir_from': file_position,
            'dir_done': target,
            'port': num
          },
          'script_id': ''//脚本id
        },
        'enrich': {
          'secret_level': secret,
          'origin_organization': {
            'name': organization_name,//来源单位
            'brief_name': brief_name,//来源简称
            'category': category//来源类型
          },
          'intelligence_type': {
            // 'contained_types': ['url', 'ip'],//
            // 'future_fields': {
            //   'url': [],//
            //   'ip': [],
            //   'hash': []
            // },
          }
        },
        'data_storage': {
          'month_reserved': storage_duration
        }
      }
      $.ajax({
        type: 'POST',
        url: '/api/rules/in/',
        data: JSON.stringify(data_in),
        datatype: 'json',
        success: function (data) {
          var data_create = JSON.parse(data);
          if (data_create['result'] == true) {
            alert('提交成功');
            // window.location = '/rules/in/';
          } else {
            alert('提交失败');
          }
        }
      })
    }
  });
});

//


$(".Off").click(function () {
  $('#bg').fadeOut();
  $('#bg_two').fadeOut();
});
$("#return").click(function () {
  $("#myModal").modal("show");
  $("#new_modal").modal("hide");
  var re = $(".ac").text();
  var id = $('.ac').data('id');
  $("#news").html(re);
  $("#news").data("id", id);
});
$("#return2").click(function () {
  $("#myModal").modal("show");
  $("#new_modal").modal("hide");
  var re = $(".ac").text();
  var id = $('.ac').data('id');
  $("#Eews").html(re);
  var ss = $("#Eews").data("id", id);
});
$("#news").click(function () {
  $("#myModal").modal("hide");
  $("#new_modal").modal("show");
});
$(document).ready(function () {

});
$(window).load(function () {
  $("#news").click(function () {
    $(".cd").html('');
    $("#return1").hide();
    $("#return2").hide();
    $("#return").show();
    $("#myModal").modal("hide");
    $("#new_modal").modal("show");
    $.ajax({
      type: 'get',
      url: '/api/pyscripts/simple/',
      dataType: 'json',
      success: function (data) {
        var Che = $(".checKed").text();
        var cce = $.trim(Che);
        for (var i = 0; i < data.info.length; i++) {
          if (cce == data.info[i]['category']) {
            //console.log(data.info[i]['category']);
            var new_span = "<span class='amore' data-placement='bottom' data-target='hover' rel='popover' data-id='" + data.info[i]['_id'] + "'>"
              + data.info[i]['name'] + "</span>";
            $(".cd").append(new_span);
            $(".cd span:first-child").addClass("ac");
            $(".amore").click(function () {
              $(this).addClass("ac");
              $(this).siblings("span").removeClass("ac");
            });
          }
        }
      }
    })
  });
  $("#ews").click(function () {
    $(".cd").html('');
    $("#return").hide();
    $("#return2").hide();
    $("#return1").show();
    $("#myModal").modal("hide");
    $("#new_modal").modal("show");
    $.ajax({
      type: 'get',
      url: '/api/pyscripts/simple/',
      dataType: 'json',
      success: function (data) {
        var Che = $(".checKed").text();
        var cce = $.trim(Che);
        for (var i = 0; i < data.info.length; i++) {
          if (cce == data.info[i]['category']) {
            //console.log(data.info[i]['category']);
            var new_span = "<span class='amore' data-placement='bottom' data-target='hover' rel='popover' data-id='" + data.info[i]['_id'] + "'>" + data.info[i]['name'] + "</span>";
            $(".cd").append(new_span);
            $(".cd span:first-child").addClass("ac");
            $(".amore").click(function () {
              $(this).addClass("ac");
              $(this).siblings("span").removeClass("ac");
            });
          }
        }
      }
    })
  });
  $("#Eews").click(function () {
    $(".cd").html('');
    $("#return").hide();
    $("#return1").hide();
    $("#return2").show();
    $("#myModal").modal("hide");
    $("#new_modal").modal("show");
    $.ajax({
      type: 'get',
      url: '/api/pyscripts/simple/',
      dataType: 'json',
      success: function (data) {
        var Che = $(".checKed").text();
        var cce = $.trim(Che);
        for (var i = 0; i < data.info.length; i++) {
          if (cce == data.info[i]['category']) {
            //console.log(data.info[i]['category']);
            var new_span = "<span class='amore' data-placement='bottom' data-target='hover' rel='popover' data-id='" + data.info[i]['_id'] + "'>" + data.info[i]['name'] + "</span>";
            $(".cd").append(new_span);
            $(".cd span:first-child").addClass("ac");
            $(".amore").click(function () {
              $(this).addClass("ac");
              $(this).siblings("span").removeClass("ac");
            });
          }
        }
      }
    })
  });
  $(function () {
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
      var activeTab = $(e.target).text();
      $(".active-tab span").html(activeTab);
    });
  });
  $("#t").click(function () {
    var inp = $("#inputText").val();
    var or = $("#origin").val();
    var st = $("#storage_duration").val();
    var su = $("#type_ftp").val();
    var Ip = $("#ip").val();
    var ad = $("#addre").val();
    var ta = $("#target").val();
    var nu = $("#num").val();
    var ne = $("#news").data("id");
    console.log(inp);
    console.log(or);
    console.log(st);
    console.log(su);
    console.log(Ip);
    console.log(ad);
    console.log(ta);
    console.log(nu);
    console.log(ne);
  })
});
$(function () {
  $(".amore1").popover({title: 'Bootstrap 弹出框', content: "为我的网站创建一个提示框如此简单！"});
});
if ($('#secondWay').hasClass('active')) {
  $('.FTP_sub').show().siblings().hide();
} else if ($('#thirdWay').hasClass('active')) {
  $('.email_sub').show().siblings().hide();
} else {
  $('.APC_sub').show().siblings().hide();
}
;
$('#brief_name').blur(function () {
  var brief_value = $('#brief_name').val();
  var brief_reg = /^[A-Za-z0-9]*$/g;
  if (brief_reg.test(brief_value)) {
  } else {
    alert('单位简称只能由字母和数字组成');
    // $('.test_email').append('<span style="color: red;">'+'*邮箱格式错误'+'</span>') ^[A-Za-z0-9]+$
  }
})
$('#inputText').blur(function () {
  var rule_val = $('#inputText').val();
  if (rule_val == '') {
    $('.clm').html('策略名不能为空');
  }
  else {
    $('.clm').html('');
  }
})
$('#ip').blur(function () {
  var ip_val = $('#ip').val();
  if (ip_val == '') {
    $('.iptest').html('服务器地址不能为空')
  } else {
    $('.iptest').html('');
  }
})
$('#addre').blur(function () {
  var addre_val = $('#addre').val();
  if (addre_val == '') {
    $('.mmt').html('密码不能为空')
  } else {
    $('.mmt').html('');
  }
})
$('#passport').blur(function () {
  var ips_val = $('#passport').val();
  var emailreg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
  if (ips_val == '') {
    $('.ip_test').html('Email不能为空')
  } else if (emailreg.test(ips_val)) {
    $('.ip_test').html('')
  } else {
    $('.ip_test').html('Email格式不正确');
  }
})
// mm_te
$('#pass').blur(function () {
  var pass_val = $('#pass').val();
  if (pass_val == '') {
    $('.mm_te').html('密码不能为空')
  } else {
    $('.mm_te').html('');
  }
})
$('#server').blur(function () {
  var se_val = $('#server').val();
  if (se_val == '') {
    $('.se_test').html('服务器地址不能为空')
  } else {
    $('.se_test').html('');
  }
})
