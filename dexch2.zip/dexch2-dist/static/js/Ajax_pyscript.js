$(".a-upload").on("change", function () {
  var file_con = $('#py_file').val();
  $('.show_file').html(file_con);
});
$(".d").children('a').children('b').addClass('jian');
var Data;
$('#file_look').html('').html('<label for="py_file" class="col-sm-2 control-label">' + '选择文件' + '</label>' +
'<div class="file a-upload">' + '选择文件' +
'<input type="file" name="file" id="py_file"/>' +
'</div>' +
'<span class="show_file">' + '</span>');
$(document).ready(function () {
  $.ajax({
    type: 'get',
    url: '/api/pyscripts/',
    dataType: 'json',
    success: function (data) {
      Data = data;
      for (var i = 0; i < data.info.length; i++) {
        // console.log(typeof(data));
        // console.log(data);
        $('#tbody').append('<tr>'
        + '<td>' + data.info[i].name + '</td>'
        + '<td>' + data.info[i].description + '</td>'
        + '<td>' + data.info[i].create_time + '</td>'
        + '<td>' + data.info[i].last_time + '</td>'
        + '<td>' + data.info[i]._id + '</td>'
        + '<td>' + data.info[i].category + '</td>'
        + '<td class="action">'
        + '<a href="#" class="del">' + '删除' + '</a>'
        + '<a data-toggle="modal" href="#myModal" class="look">' + '查看' + '</a>'
        + '<a data-toggle="modal" href="#myModal" class="change">' + '修改' + '</a>'
        + '</td>' + '</tr>');
      }
      //修改
      $('.change').on('click', function () {
        var index = $(".change").index(this);
        $('#category,#n_sub,.xjt').hide();
        $('.dropdown,#c_sub').show();
        $('.modal-body').css('height', '360px');
        $('.create_action').val('update');
        $('#form').append('<div id="edit_id" style="display: none;">' + '<input type="text" name="_id" id="change_id" required/>' + '</div>');
        $('#myModalLabel').html('修改脚本');
        $('.modal-body input').val('');
        // $('#category option').html('<option>'+'</option>'+'<option>'Email'</option>'+'<option>'+FTP+'</option>'+'<option>'+APCERT+'</option>');
        $('#file_look').html('').html('<label for="py_file" class="col-sm-2 control-label">' + '选择文件' + '</label>' +
        '<div class="file a-upload">' + '选择文件' +
        '<input type="file" name="file" id="py_file"/>' +
        '</div>' + '<span class="show_file">' + '</span>');
        $(".a-upload").on("change", function () {
          var file_con = $('#py_file').val();
          $('.show_file').html(file_con);
        });
        $('.modal-footer').show();
        $('#name,#descripe').removeAttr('disabled');
        $('.xjn').show().val(data.info[index].category).attr('disabled', true);
        $('#name').val(data.info[index].name);
        $('#change_id').val(data.info[index]._id);
        $('#descripe').val(data.info[index].description);
        // $('#category option:selected').val(data.info[index].category);
        $('#c_sub').click(function () {
          var fd = new FormData(document.getElementById("form"));
          // fd.append("CustomField", "This is some extra data");
          $.ajax({
            url: "/api/pyscripts/",
            type: "POST",
            data: fd,
            dataType: 'json',
            processData: false,
            contentType: false,
            success: function (data) {
              if (data['result'] == true) {
                alert('修改成功');
                // window.location.href = '/pyscripts/';
              } else {
                alert('修改失败');
              }
            }
          })
        })
      });
      //删除
      var del_index;
      $('.del').click(function () {
        $('#bg').fadeIn();
        $('#bg_two').fadeIn();
        del_index = $('.del').index(this);
      });
      $('.delete').on('click', function () {
        $('#bg').hide();
        var s_id = data.info[del_index]._id;
        var all = {
          action: 'delete',
          _id: s_id
        };
        $.ajax({
          type: 'post',
          url: '/api/pyscripts/',
          dataType: 'json',
          data: all,
          success: function (data) {
            if (data['result'] == true) {
              window.location.href = '/pyscripts/';
            } else {
              console.log(data.result);
            }
          }
        })
      });
      //查看
      $('.look').on('click', function () {
        $('.dropdown,.xjt').hide();
        $('#myModalLabel').html('查看脚本');
        var look_index = $(".look").index(this);
        $('.modal-footer').hide();
        $('#category').hide();
        $('.xjn').show().val(data.info[look_index].category);
        $('#name').val(data.info[look_index].name);
        $('#name,.xjn,#descripe').attr('disabled', true);
        $('#descripe').val(data.info[look_index].description);
        $('.modal-body').css('height', '440px');
        $('#file_look').html('<label for="content" class="parse col-sm-2">' + '内容' + '</label>' +
        '<textarea class="form-control col-sm-8" id="content" rows="5" disabled>' + data.info[look_index].content + '</textarea>')
      });
    }
  })
});
//
//新建
$('.new').click(function () {
  $("#name").blur(function(){
    var name_val = $('#name').val();
    var namereg = /^[A-Za-z]*$/g;
    if($(this).val()==''){
      $('.xjt').show().html('脚本名称不能为空');
    }else if(namereg.test(name_val)){
      $('.xjt').show().html('脚本名称只能为字母');
    }else{
      $('.xjt').hide();
    }
  });
  $('.xjn,#c_sub').hide();
  $('#n_sub,#category,.dropdown').show();
  $('#edit_id').html('');
  $('#myModalLabel').html('新建脚本');
  $('.modal-footer').show();
  $('#name,#descripe').removeAttr('disabled');
  $('.modal-body').css('height', '360px');
  $('#name').val('');
  $('#descripe').val('');
  $('#file_look').html('').html('<label for="py_file" class="col-sm-2 control-label">' + '选择文件' + '</label>' +
  '<div class="file a-upload">' + '选择文件' +
  '<input type="file" name="file" id="py_file"/>' +
  '</div>' +
  '<span class="show_file">' + '</span>');
  $(".a-upload").on("change", function () {
    var file_con = $('#py_file').val();
    $('.show_file').html(file_con);
  });
  $('#n_sub').click(function () {
    if ($('#name').val() == '') {
      //alert('脚本名称不能为空');
      $('.xjt').show().html('脚本名称不能为空');
    } else {
      $('.xjt').hide();
      var fd = new FormData(document.getElementById("form"));
      fd.append("CustomField", "This is some extra data");
      $.ajax({
        url: "/api/pyscripts/",
        type: "POST",
        data: fd,
        dataType: 'json',
        processData: false,
        contentType: false,
        success: function (data) {
          if (data['result'] == true) {
            alert('新建成功');
            $('#myModal').fadeOut();
            $('.modal-backdrop').fadeOut();
            window.location.href = '/pyscripts/';
          } else {
            alert('新建失败');
          }
        }
      })
    }
  })
});

$('.first_tab').click(function () {
  $('#now_choose').val('APCERT');
});
$('.second_tab').click(function () {
  $('#now_choose').val('FTP');
});
$('.third_tab').click(function () {
  $('#now_choose').val('Email');
});
//
$('.Off').click(function () {
  $('#bg').fadeOut();
  $('#bg_two').fadeOut();
});


