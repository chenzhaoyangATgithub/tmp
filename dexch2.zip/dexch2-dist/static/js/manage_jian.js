$(".d").children('a').children('b').addClass('jian');
