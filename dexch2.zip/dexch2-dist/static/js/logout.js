$(".out").click(function(){
  $.ajax({
    type: "post",
    url: '/api/logout'
  })
})
