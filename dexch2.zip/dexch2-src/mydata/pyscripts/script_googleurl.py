#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'
import re
import datetime
import time

def run(parsedinfo,fileobj_list):
    """
    :param parsedinfo:
    :param fileobj_list:
    :return:
    """
    ret = {
           '_meta':{
               'dates':{
                   'creating':None,
                   'report':None
               },
               'tracking_code':None,
           },

           'records':None,
           'files':None
    }

    ret['records'] = get_records(parsedinfo)
    email_dt = get_email_date(parsedinfo)
    ret['_meta']['dates']['report'] =  _dt_make(email_dt)
    ret['_meta']['dates']['creating'] = _dt_make(datetime.datetime.now())

    return ret


def get_records(jsoninfo):

    content = ''.join(jsoninfo['body']['html'])
    #print content
    record_list = _pick_body(content)

    return record_list

def get_email_date(jsoninfo):
    raw_date_string = jsoninfo['date']
    parsed_date = jsoninfo['parsed_date']

    if parsed_date:
        email_date = parsed_date
    else:
        #Tue, 23 Aug 2016 17:25:43
        email_date = datetime.datetime.strptime(raw_date_string.split('+')[0],'%a, %d %b %Y %H:%M:%S ')#有加号或者无加号
    return email_date

def _dt_make(dttime,tz=None):
    ret = {}
    ret['obj'] = dttime
    ret['tz'] = tz
    ret['iso'] = dttime.isoformat()
    ret['yearly'] = dttime.strftime('%Y')
    ret['monthly'] = dttime.strftime('%Y-%m')
    ret['daily'] = dttime.strftime('%Y-%m-%d')
    ret['hourly'] = dttime.strftime('%Y-%m-%d-%H')
    ret['iso'] = dttime.isoformat()
    ret['epoch'] = time.mktime(dttime.timetuple())#todo:tz相关

    return ret


def _pick_body(body_str):

    pattern_str = r'.*\<a href="(http.*)">'
    pattern = re.compile(pattern_str,re.M|re.I)
    results = pattern.findall(body_str)
    #print(results)
    ret = [{'url':url} for url in results]
    return ret

def get_from_fileobj_list(files):
    pass
