#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import re
import datetime

def run(parsedinfo,fileobj_list):
    ret = dict()
    ret['_meta'] = {
        'dates':{
           'creating':None,
           'report':None
        },
    }

    ret['records'] = get_records(parsedinfo)
    ret['files'] = get_files(fileobj_list)

    ret['_meta']['dates']['creating'] = _dt_make(datetime.datetime.now())
    ret['_meta']['dates']['report'] = _get_useful_date(parsedinfo)

    return ret


def get_records(jsoninfo):
    records = []

    
    #todo: fill the procedure

    return records

def get_files(files):
    #todo:fill the procedure

    return files


def _get_useful_date(jsoninfo):
    pass
    return None

def _dt_make(dttime):
    ret = {}
    ret['obj'] = dttime
    ret['yearly'] = dttime.strftime('%Y')
    ret['monthly'] = dttime.strftime('%Y-%m')
    ret['daily'] = dttime.strftime('%Y-%m-%d')
    ret['hourly'] = dttime.strftime('%Y-%m-%d-%H')

    return ret

def _pick_body(body_str):

    pass

