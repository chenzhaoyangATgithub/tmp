#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

def run(parsedinfo,fileobj_list):
    print parsedinfo
    return 'good'

