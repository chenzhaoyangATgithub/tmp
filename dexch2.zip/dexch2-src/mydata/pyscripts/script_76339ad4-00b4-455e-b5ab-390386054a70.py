#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import re
import datetime
import time
import logging
import StringIO
import zipfile
import csv
import requests

logger = logging.getLogger(__name__)

def run(parsedinfo,fileobj_list):
    print parsedinfo
    ret = dict()
    ret['_meta'] = {
        'dates':{
           'creating':None,
           'report':None
        },
        'links':[],
    }

    # filter the name
    subject = parsedinfo['subject']
    report_type,report_date_str = identify_shadowserver(subject)
    if not (report_type and report_date_str):
        logger.info('not shadowserver,script running skipped..\n')
        ret['_meta']['skip_run'] = True
        raise ValueError('bad shadowserver type,script running skipped..\n')


    ret['_meta']['dates']['creating'] = _dt_make(datetime.datetime.now())

    report_date = datetime.datetime.strptime(report_date_str,'%Y-%m-%d')
    ret['_meta']['dates']['report'] = _dt_make(report_date)

    ret['_meta']['links'] = get_links(parsedinfo)
    #todo: download files from links


    ret['records'] = get_records(fileobj_list)
    ret['files'] = get_files(fileobj_list)

    return ret

def get_records(file_obj_list):
    records = []
    if len(file_obj_list) > 1:
        raise ValueError('too many attatchements')

    for file_obj in file_obj_list:
        file_like = file_obj['content']
        zipf = zipfile.ZipFile(file_like,mode='r')
        nmlist =  zipf.namelist()
        if len(nmlist) == 1:
            csv_str = zipf.read(nmlist[0])
            # print csv_str
            # print type(csv_str)

            csv_f = StringIO.StringIO(csv_str)
            # print type(hh)
            reader = csv.DictReader(csv_f,delimiter=',')
            for line in reader:
                print line
                records.append(line)
            csv_f.close()
        else:
            zip_name = file_obj['filename']
            raise ValueError('too many files in zip:%s'%zip_name)

        zipf.close()
    return records

def get_files(files):
    #todo:fill the procedure

    return files

def get_links(info):
    ret = []
    body_str = ''.join(info['body']['plain'])
    pattern_str = r'The report content can be obtained from the following link:\r\n'+\
                  r'(.*)\s*\r\n'+\
                  r'The report is (.*) bytes and contains (.*) events?'
    pattern = re.compile(pattern_str,re.M|re.I)
    print body_str

    results = pattern.findall(body_str)
    #print(results)
    if not results:
        logger.error(body_str)
        raise ValueError('Bad content')

    for result in results:
        tmp = {}
        for n,k in enumerate(['link','report_bytes','events_contained']):
            tmp[k] = result[n]

        print(tmp)
        ret.append(tmp)

    return ret

def _get_useful_date(jsoninfo):
    pass
    return None

def _dt_make(dttime,tz=None):
    ret = {}
    ret['obj'] = dttime
    ret['tz'] = tz
    ret['iso'] = dttime.isoformat()
    ret['yearly'] = dttime.strftime('%Y')
    ret['monthly'] = dttime.strftime('%Y-%m')
    ret['daily'] = dttime.strftime('%Y-%m-%d')
    ret['hourly'] = dttime.strftime('%Y-%m-%d-%H')
    ret['iso'] = dttime.isoformat()
    ret['epoch'] = time.mktime(dttime.timetuple())#todo:tz相关

    return ret

def _pick_body(body_str):

    pass

def identify_shadowserver(title_str):
    def _convert_report_type(raw):
        new = raw.lower().strip().replace(' ','_',).replace('/','|')
        return new.rstrip('_report')

    report_type = None
    utc_datestr = ''

    print('raw:',title_str)
    title_str = title_str.replace('\r\n',' ')#
    print('new:',title_str)

    #[China] Shadowserver China Vulnerable NAT-PMP Systems Report:2016-08-24
    pattern_str = r'\[China\] Shadowserver China (.*):\s.*(\d{4}-\d{2}-\d{2})' #todo:不对
    pattern = re.compile(pattern_str,re.DOTALL|re.I)
    m = pattern.search(title_str)
    if m:
        report_type = m.group(1)
        utc_datestr = m.group(2)

        report_type = _convert_report_type(report_type)
        utc_datestr = utc_datestr.strip()

    print('Report_type:',report_type,'\tReport_date:',utc_datestr)

    return report_type,utc_datestr
