#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import re
import datetime
import time

def run(parsedinfo,fileobj_list):
    ret = dict()
    ret['_meta'] = {
        'dates':{
           'creating':None,
           'report':None
        },
        'tracking_code':None
    }

    ret['records'] = get_records(parsedinfo)  #正文
    ret['files'] = get_files(fileobj_list) #附件

    ret['_meta']['dates']['creating'] = _dt_make(datetime.datetime.now())
    email_dt = get_email_date(parsedinfo)
    ret['_meta']['dates']['report'] = _dt_make(email_dt)

    ret['_meta']['tracking_code'] = identify_auscert(parsedinfo['subject'])
    return ret


def get_records(jsoninfo):
    records = []
    #todo: fill the procedure

    body_str = ''.join(jsoninfo['body']['html'])
    records = _pick_body(body_str)
    return records

def get_files(files):
    #todo:fill the procedure
    return files


def get_email_date(jsoninfo):
    raw_date_string = jsoninfo['date']
    parsed_date = jsoninfo['parsed_date']

    if parsed_date:
        email_date = parsed_date
    else:
        #Tue, 23 Aug 2016 17:25:43
        email_date = datetime.datetime.strptime(raw_date_string.split('+')[0],'%a, %d %b %Y %H:%M:%S ')#有加号或者无加号
    return email_date

def _dt_make(dttime,tz=None):
    ret = {}
    ret['obj'] = dttime
    ret['tz'] = tz
    ret['yearly'] = dttime.strftime('%Y')
    ret['monthly'] = dttime.strftime('%Y-%m')
    ret['daily'] = dttime.strftime('%Y-%m-%d')
    ret['hourly'] = dttime.strftime('%Y-%m-%d-%H')
    ret['iso'] = dttime.isoformat()
    ret['epoch'] = time.mktime(dttime.timetuple())#todo:tz相关

    return ret

def _pick_body(body_str):
    ret = []
    pattern_str = r'Filename:\s*(.*)<br>\r\n'+\
                  r'Scanned:\s*(.*)<br>\r\n'+\
                  r'Malware size:\s*(.*)<br>\r\n'+\
                  r'Malware MD5:\s*(.*)<br>\r\n'+\
                  r'Malware SHA1:\s*(.*)<br>\r\n'+\
                  r'Malware SHA256:\s*(.*)<br>\r\n'+\
                  r'VirusTotal Report URL:.*\<a href="(.*)">'

    pattern = re.compile(pattern_str,re.M|re.I)
    results = pattern.findall(body_str)
    print(results)

    for result in results:
        tmp = {}
        keys = ['filename','scanned','malware_size','malware_md5',
                'malware_sha1','malware_sha256','malware_vt_report']
        for n,k in enumerate(keys):
            tmp[k] = result[n]
        ret.append(tmp)
        print(tmp)

    return ret


def identify_auscert(title_str):
    tracking_code = None
    pattern_str = r'\[AusCERT virus-submit AR#1\] \((.*)\) Malware submission'
    pattern = re.compile(pattern_str,re.M|re.I)
    m = pattern.search(title_str)
    #if m.group(0)
    if m:
        tracking_code = m.group(1)
    return tracking_code

