https://www.digitalocean.com/community/tutorials/how-to-serve-django-applications-with-uwsgi-and-nginx-on-ubuntu-16-04
https://www.digitalocean.com/community/tutorials/how-to-serve-django-applications-with-uwsgi-and-nginx-on-centos-7


## 6.4 整体测试uwsgi

### 测试uwsgi+django

以下如果想让外网访问，前提得让防火墙允许8000端口，否则只能用curl登陆

```
cd 进入project目录
# 以http方式启动uwsgi
uwsgi --http :8001 --module mysite.wsgi
使用curl 访问 localhost:8001
返回结果正常，说明
the web client <-> uWSGI <-> Django 已经通了。
```

- 如果地址想公开给所有本地网络访问，则上面地址要变，而且对应端口防火墙要注意允许访问才行
- 正常情况下80端口开放的化，上面端口可以改为 80，防火墙能暂时不用配置
```
cd /root/dexch2-src/
uwsgi --http :80 --moduel mysite.wsgi
```




### ps:测试nginx+uwsgi+django 

```
# 如果与前端nginx通信，则要使uwsgi以socket方式链接tcp端口
# uwsgi --socket :8000 --module dataexchange.wsgi
```

## nginx 安装配置、测试

- 安装nginx略
```

```

- 复制配置文件
```
$
copy ./nginx_dexch2.conf /etc/nginx/conf.d/

```