#!/usr/bin/env bash

# install nginx
sudo rpm -Uvh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm
sudo yum install -y nginx
sudo systemctl start nginx.service #开启nginx
sudo systemctl enable nginx.service #开机启动

# install uwsgi
yum install python-devel gcc
sudo pip install uwsgi

# only for test.condition: port 80 is open in iptables
# uwsgi --http :8000 --wsgi-file test_uwsgi.py
# curl http://127.0.0.1:8000

#  test uwsig <->  django
# request http://<IP>
# cd /path/to/project
# uwsgi --http :8000 --module mysite.wsgi
# curl http://localhost:8000



