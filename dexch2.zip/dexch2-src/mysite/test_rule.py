#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import pymongo

conn_mongo = pymongo.MongoClient()
collection = conn_mongo.rules.datain

rules = [{'rule_name':'apcert_rule',
          'datatype':'undefined',#下拉菜单
          'origin':'dataexchanger.apcert.org',
          'storage_duration':{
              'month':3,
          },
          'used_storage':{
              'M':50,
          },
          'enable':True,
          'transport_type':'apcert_dataexchanger_platform',#传输类型：默认的数据交换平台,亚太数据交换系统（一期系统）
          'transport_detail':{
              ''
              'allowed_organization':[],
              'allowed_datatypes':[]
          }
        },
        {'rule_name':'googleurl_rule',
          'datatype':'googleurl',
          'origin':'google.com',
          'storage_duration':{
              'month':3,
          },
          'used_storage':{
              'M':50,
          },
         'enable':True,
         'transport_type':'email',#传输类型：email方式
         #传输相关的细节
         'transport_detail':{
            'server':'imap.mxhichina.com',
             'port':'993',
             'use_ssl':True,
             'mail_account':'sunboxuan@antiy.cn',
             'password':'******',
             'dir_from':'Intelligence',
             'dir_done':'googleurl_dumped'
         },
         'processing_detail':{  #处理接收的正文和附件的细节;规则化邮件标题；字符串re匹配；
            #skip
         }
        },

        ]

collection.insert_many(rules)

