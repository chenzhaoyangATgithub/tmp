#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'ms'

import requests

def send():
    url = 'https://dataexchanger.apcert.org/api/send/'
    apikey = '4928935b6e1c43db8cf173f4eb9aa4eb'

    data = {'apikey':apikey,
            'to':['test_team'],
            'datatype':'test_data_type',
            'note':'test'}
    files = {'file': open('tt.py', 'rb')}
    resp = requests.post(url=url,data=data,files=files)
    print resp.status_code
    print resp.json()





