#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'
"""
本脚本用于从原始数据库中取出数据并打包相关文件
导出给dexch2使用
导出结果保留原有sql原貌,以及pubkey.　
同时load函数负责将数据按照接口规范导入数据库，将来可以复用某些函数来编写同步接口
"""


def convert_teaminfo():
    pass

def convert_pubkey():
    pass

def convert_pubkey():
    pass
