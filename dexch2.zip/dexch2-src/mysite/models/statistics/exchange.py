#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from dateutil.rrule import rrule,HOURLY,DAILY,MONTHLY,YEARLY
from pymongo import MongoClient

from ..mongo_helper import value_convert

conn_mongo = MongoClient()
Name2MongoKey = {'country_code':'exchange.out.geo.country_code',
                 'country_name':'exchange.out.geo.country_name',
                 'send_to':'exchange.out.send_to',
                 'creating_date':'_meta.dates.creating.obj',

                 'report_type_intelligence_type':'enrich.intelligence_type.subcategory',

                 'report_type':'enrich',

                 'report_type_name':'enrich.origin_type_id',
                 'report_type_shortname':'enrich.origin_type_id',
                 'report_type_id':'enrich.origin_type_id',

                 'report_type_category':'enrich.origin_organization.category',
                 'report_type_organization':'enrich.origin_organization.name',

                 'DAILY':'_meta.dates.creating.daily',
                 'HOURLY':'_meta.dates.creating.hourly',
                 'MONTHLY':'_meta.dates.creating.monthly',
                 'YEARLY':'_meta.dates.creating.yearly',

                 'exchange_from':'enrich.origin_organization.name',
                 'exchange_to':'exchange.out.to'
                 }

case_table={
            'YEARLY':('%Y',YEARLY),
            'MONTHLY':('%Y-%m',MONTHLY),
            'DAILY':('%Y-%m-%d',DAILY),
            'HOURLY':('%Y-%m-%d-%H',HOURLY),
            }

def get_counts(filter_input, group_by='report_type_name',order_by=None,limit=None, conn=conn_mongo):
    """
    :param filter_input:list or dict
    :param group_by:string
    :param conn:
    :return:
    """
    FILTER={}
    report = conn.origin.report
    for k,v in filter_input.items():
        FILTER.update(value_convert(Name2MongoKey[k], v))

    print 'FILTER:',FILTER

    pipeline = [{'$match': FILTER},
                {'$group': {'_id': '$%s'%(Name2MongoKey[group_by]),
                           'counts': {'$sum':1}}}]
    if order_by is not None:
        pipeline.append({'$sort':{'counts':order_by}})
    if limit is not None:
        pipeline.append({'$limit':limit})

    #print 'pipeline:',pipeline
    ret = {'name':[],
           'value':[]}
    for item in report.aggregate(pipeline):
        #print item
        #todo:group_by也可能取到没有相应的键值；不能保证每一种数据类型都有对应的键值
        if not item['_id']:
            # ret['name'].append('other')
            # ret['value'].append(item['counts'])
            continue #不计入总数
        else:
            ret['name'].append(item['_id'])
            ret['value'].append(item['counts'])

        #ret[item['_id']] = item['counts']

    return ret

def get_trends(filter_input, group_by='report_type_organization',
               interval='DAILY', conn=conn_mongo):
    """
    filter in:
                {'country_code':'report_info.geo.country_code',
                 'country_name':'report_info.geo.country_name',
                 'send_to':'report_info.send_to',
                 'creating_date':'report_info.creating_date',

                 'report_type':'report_info.report_type',
                 'report_type_name':'report_info.report_type.name',
                 'report_type_category':'report_info.report_type.category',
                 'report_type_organization':'report_info.report_type.organization',
                 'report_type_id':'report_info.report_type.id',
                 ...
                 }
    :param filter_input:
    :param group_by:
    :param conn:
    :return:
    """
    FILTER={}
    report = conn.origin.report
    for k,v in filter_input.items():
        FILTER.update(value_convert(Name2MongoKey[k], v))
    #print 'FILTER:',FILTER

    # pipeline = [{'$match': FILTER},
    #             {'$group': {'_id': '$%s'%(Name2MongoKey[interval_type]),
    #                        'counts': {'$sum':1}
    #                         }}]

    pipeline = [{'$match': FILTER},
                {'$group': {'_id':{
                                group_by:'$%s'%(Name2MongoKey[group_by]),
                                interval: '$%s' % (Name2MongoKey[interval]),
                            },
                           'counts': {'$sum':1}
                            }
                }]

    #print 'pipeline:',pipeline

    ret = {}

    for item in report.aggregate(pipeline):
        #print 'item:',item
        #todo:group_by也可能取到没有相应的键值；不能保证每一种数据类型都有对应的键值
        if group_by in item['_id']:
            type = item['_id'][group_by]
        else:
            continue #不计入总数
        datestring = item['_id'][interval]
        counts = item['counts']
        if type in ret:
            ret[type][datestring]=counts
        else:
            ret[type] = {}
            ret[type][datestring]=counts

    return ret

def mygroups(filter_input, group_by=['report_type_name'], order_by=None, limit=None, conn=conn_mongo):
    FILTER={}
    report = conn.origin.report
    for k,v in filter_input.items():
        FILTER.update(value_convert(Name2MongoKey[k], v))
    print 'FILTER:',FILTER

    group_id = {}
    for k in group_by:
        group_id.update({k:'$%s'%(Name2MongoKey[k])})
    print 'group_id:',group_id

    pipeline = [{'$match': FILTER},
                {'$group': {'_id': group_id,
                           'counts': {'$sum':1}}}]
    if order_by is not None:
        pipeline.append({'$sort':{'counts':order_by}})
    if limit is not None:
        pipeline.append({'$limit':limit})

    #print 'pipeline:',pipeline
    # ret = {'name':[],
    #        'value':[]}
    ret = []
    for item in report.aggregate(pipeline):
        #print item
        # #todo:group_by也可能取到没有相应的键值；不能保证每一种数据类型都有对应的键值
        ret.append(item)

        # if item['_id'] is None:
        #     ret['name'].append('unknow')
        # else:
        #     ret['name'].append(item['_id'])
        #
        # ret['value'].append(item['counts'])

        #ret[item['_id']] = item['counts']
    return ret


def gen_datestring(start_dt,end_dt,interval='DAILY'):

    return [dt.strftime(case_table[interval][0]) for dt in rrule(case_table[interval][1],
                                                                 dtstart=start_dt,until=end_dt)]

# def get_reportinfo_list(info_key, conn=conn_mongo):
#     """
#     用于给界面下拉菜单提供数据
#     the empty element won't be in result
#
#     :param info_key:
#     :param conn:
#     :return: a list
#     """
#     key = "$report_info.%s"%(info_key)
#     result_list = []
#     cursor = conn.origin.report.aggregate([{'$group':{"_id":key,"count":{"$sum":1}}}])
#
#     for doc in cursor:
#         if doc['_id']:#去掉值为空的选项
#             result_list.append(doc)
#             #print doc['_id']
#     return result_list


if __name__ == '__main__':
    pass