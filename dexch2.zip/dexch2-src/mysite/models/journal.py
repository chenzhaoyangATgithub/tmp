#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import pymongo
import datetime

c= pymongo.MongoClient()

def operation_log():
    pass


def get_all(dt_fmt='%Y-%m-%d %H:%M:%S',collection=c.journal.operation):
    cursor = collection.find({},{'_id': False})
    cursor.sort('time',pymongo.DESCENDING)
    ret = []
    for doc in cursor:
        tmp = doc.copy()
        tmp['time'] = tmp['time'].strftime(dt_fmt)
        ret.append(tmp)
    print ret
    return ret

def new(request,operation_type,result,user_obj=None):
    common = _journal_helper(request, user_obj)
    _insert_one(common['username'],common['role_type'],
                common['ip'],common['time'],
                operation_type,result)

def _insert_one(uname,role_name,ip,datetime_obj,operation_type,result,collection= c.journal.operation):
    doc = {'username':uname,
           'role_type':role_name,
           'ip':ip,
           'operation_type':operation_type,
           'result':result,
           'time':datetime_obj}

    result = collection.insert_one(doc)
    return result.inserted_id

def _journal_helper(request, user_obj=None):
    if user_obj is None:
        user_obj = request.user
    uname = user_obj.username
    if user_obj.is_superuser:
        role_name = 'admin'
    else:
        role_name = 'normal_user'
    ip = get_client_ip(request)

    return {'username':uname,
            'role_type':role_name,
            'ip':ip,
            'time':datetime.datetime.now(),
            }

def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip