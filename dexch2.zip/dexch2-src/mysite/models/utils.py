#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

def query_make(original_query):
    pass
