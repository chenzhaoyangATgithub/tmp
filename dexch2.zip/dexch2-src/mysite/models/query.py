#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

def q_hash(hash,hash_type):
    pass

def q_url(url):
    pass

def q_geo(gcode):
    pass

