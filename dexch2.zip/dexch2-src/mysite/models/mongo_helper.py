#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'


# class ReportInfoKey():
#     report_type = 'report_info.report_type'
#     report_type_name = 'report_info.report_type.name'
#     report_type_shortname = 'report_info.report_type.shortname'
#     report_type_intelligence_type = 'report_info.report_type.intelligence_type'
#     report_type_category = 'report_info.report_type.category'
#     report_type_organization = 'report_info.report_type.organization'
#     report_type_id = 'report_info.report_type.id'
#     def __init__(self):
#         pass
#
# class ExchangeInKey():
#     creating_date = 'exchange.in.date.obj'
#     daily = 'exchange.in.date.daily'
#     hourly = 'exchange.in.date.hourly'
#     monthly = 'exchange.in.date.monthly'
#     yearly = 'exchange.in.date.yearly'
#
#     exchange_from = 'exchange.in.from'
#     def __init__(self):
#         pass
#
# class ExchangeOutKey():
#     daily = 'exchange.out.date.daily'
#     hourly = 'exchange.out.date.hourly'
#     monthly = 'exchange.out.date.monthly'
#     yearly = 'exchange.out.date.yearly'
#
#     exchange_to = 'exchange.out.to'
#
#     country_code = 'exchange.out.geo.country_code'
#     country_name = 'exchange.out.geo.country_name'
#     send_to = 'exchange.out.send_to'
#     def __init__(self):
#         pass


def value_convert(mongo_key, input_value):
    """
    根据input_value形式进行转换
        1.自动为list形式的input_value添加$in操作符;
        2.转None为{},表示全选
        3.转
    :param mongo_key:string
    :param input_value:string or dict or list
    :param default_keypairs:
    :return:dict {key:value} 作为new filter
    """
    ff = {}
    if input_value is not None:
        if isinstance(input_value,list):
            ff.update({mongo_key:{'$in':input_value}})
        else:
            ff.update({mongo_key:input_value})

    return ff

def make_filter():
    pass

# k_info = ReportInfoKey()
# k_in = ExchangeInKey()
# k_out = ExchangeOutKey()
