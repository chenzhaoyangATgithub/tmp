#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'
import datetime
from .statistics import exchange


def query_organization_reports(start_dt, end_dt, interval_type, organization_names):

    if interval_type in ('daily','hourly','monthly','yearly'):
                interval_type = interval_type.upper()
    else:
        raise ValueError('illegal interval_type!')
    #　得到总数
    ret_organization_counts = exchange.get_counts({'creating_date':{'$gt':start_dt, '$lt':end_dt},
                                        'report_type_organization':organization_names},
                                         group_by='report_type_organization')
    #print 'ret_organization_counts',ret_organization_counts


    #生成datestring
    dtstring_list = exchange.gen_datestring(start_dt,end_dt,interval=interval_type)
    #print 'dtstring:',dtstring_list

    # ret organization trend
    ret_organization_trend = exchange.get_trends({'creating_date':{'$gt':start_dt, '$lt':end_dt},
                                        'report_type_organization':organization_names},
                                    group_by='report_type_organization',
                                    interval=interval_type)

    #装载datestring,
    for type,counts_kv in ret_organization_trend.items():
        counts_list = [counts_kv[dt_str] if dt_str in counts_kv else 0 for dt_str in dtstring_list ]

        ret_organization_trend[type]={'name':dtstring_list,'value':counts_list}

    return {'organizations_total':ret_organization_counts,
            'organizations_trend':ret_organization_trend}

def query_datatyes_report(start_dt, end_dt, interval_type, type_names):

    if interval_type in ('daily','hourly','monthly','yearly'):
                interval_type = interval_type.upper()
    else:
        raise ValueError('illegal interval_type!')

    ret_datatype_counts = exchange.get_counts({'creating_date':{'$gt':start_dt, '$lt':end_dt},
                                        'report_type_name':type_names
                                    # 'report_type_id':type_id_list,
                                    })
    print 'ret_datatype_counts:',ret_datatype_counts

    #生成趋势数据

    #生成datestring
    dtstring_list = exchange.gen_datestring(start_dt,end_dt,interval=interval_type)
    print 'dtstring:',dtstring_list

    # ret datatypes trend
    ret_datatype_trend = exchange.get_trends({'creating_date':{'$gt':start_dt, '$lt':end_dt},
                                        'report_type_name':type_names},
                                    group_by='report_type_name',
                                    interval=interval_type)

    #装载datestring
    for type,counts_kv in ret_datatype_trend.items():
        counts_list = [counts_kv[dt_str] if dt_str in counts_kv else 0 for dt_str in dtstring_list ]

        ret_datatype_trend[type]={'name':dtstring_list,'value':counts_list}

    return {
            'datatypes_total':ret_datatype_counts,
            'datatypes_trend':ret_datatype_trend,
            }