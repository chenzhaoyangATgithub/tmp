#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import datetime
import pymongo
import os

c= pymongo.MongoClient()

import subprocess

def du(d_path):
    """disk usage in human readable format (e.g. '2,1GB')"""
    return subprocess.check_output(['du','-sh','-m', d_path]).split()[0].decode('utf-8')



def get_timeinfo():
    ret= {}
    now = datetime.datetime.now()
    server_start = datetime.datetime(year=2016,month=8,day=1)
    how_long = now - server_start

    ret['days'] = how_long.days
    return ret

def get_diskinfo():#todo:unused_size,used_filesize,used_dbsize
    filesize = 0
    dbsize = 0
    filepath_list = ['/home/mk/source/dexch2-tools/dexch2-feedin/mydata',
                '/root/dexch2-tools/dexch2-feedin/mydata']
    dbpath_list = ['/var/lib/mongodb','/var/lib/mongo']
    for fpath in filepath_list:
        try:
            filesize = du(fpath)
            print fpath,':',filesize
            break
        except Exception as err:
            print err
            continue

    for fpath in dbpath_list:
        try:
            dbsize = du(fpath)
            print fpath,':',dbsize
            break
        except Exception as err:
            print err
            continue

    ret = {'totalsize':str(int(filesize)+int(dbsize))+'M',
           'filesize':filesize+'M',
           'dbsize':dbsize+'M'}
    return ret

def get_sysinfo(collection = c.info.sys):

    # ret = {'apikey':'4928935b6e1c43db8cf173f4eb9aa4eb',
    #        'country':'',
    #        'organization_name':'test_team',
    #        'organization_email':''}

    doc = collection.find_one({},{'_id': False}) #fisrt
    # if doc:
    #     tmp = doc.copy()
    #     tmp['_id'] = str(tmp['_id'])
    # else:
    #     tmp = {}
    return doc

def set_sysinfo(sysinfo,collection = c.info.sys):
    fisrt = collection.find_one()
    if fisrt:
        r = collection.update_one({'_id':fisrt['_id']},{'$set':sysinfo})
        return True,r.modified_count
    else:
        r = collection.insert_one(sysinfo)
        return True,r.inserted_id
    # r = collection.find_one_and_update({},{'$set':sysinfo})
    # return True,r.modified_count