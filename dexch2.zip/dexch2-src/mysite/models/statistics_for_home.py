#!/usr/bin/python
# -*- coding: utf-8 -*-
from .statistics.exchange import get_counts, mygroups
__author__ = 'mk'


def get_top_n_organizations_in(n):
    FILTER = {}
    ret_organizations_in = get_counts(FILTER,group_by='exchange_from',order_by=-1,limit=n)

    ret_organizations_in['name'].reverse()
    ret_organizations_in['value'].reverse()
    return ret_organizations_in


def get_top_n_organizations_out(n):
    FILTER = {'exchange_to':{'$exists':True}}
    ret_organizations_out = get_counts(FILTER,group_by='exchange_to',order_by=-1,limit=n)

    ret_organizations_out['name'].reverse()
    ret_organizations_out['value'].reverse()
    return ret_organizations_out


def get_top_n_intelligence_type_in(n=None):
    """

    :param n:
    :return:
    """
    FILTER = {'exchange_from':{'$exists':True}}
    ret_intelligence_type = get_counts(FILTER,group_by='report_type_intelligence_type',order_by=-1,limit=n)

    ret_intelligence_type['name'].reverse()
    ret_intelligence_type['value'].reverse()
    return ret_intelligence_type

def get_top_n_intelligence_type_out(n=None):
    """
    :param n:
    :return:
    """
    FILTER = {'exchange_to':{'$exists':True}}
    ret_intelligence_type = get_counts(FILTER,group_by='report_type_intelligence_type',order_by=-1,limit=n)

    ret_intelligence_type['name'].reverse()
    ret_intelligence_type['value'].reverse()
    return ret_intelligence_type


def get_organizations_counts_in():
    ret_organizations_in = get_counts({},group_by='exchange_from')
    return len(ret_organizations_in['name'])


def get_organizations_counts_out():
    ret_organizations_out = get_counts({},group_by='exchange_to')
    return len(ret_organizations_out['name'])


def get_exchange_counts():
    result = mygroups({}, group_by=['report_type_category','exchange_from', 'exchange_to'])
    ret = {}
    for item in result:
        # init
        report_type_category = item['_id']['report_type_category']
        exchange_from = item['_id'].get('exchange_from')
        exchange_to = item['_id'].get('exchange_to')
        counts = item['counts']


        if report_type_category not in ret:
            ret[report_type_category] = {'in':0,'out':0}

        # 'from' addition
        if exchange_from:
            ret[report_type_category]['in'] += counts

        # 'to' addition
        if exchange_to:
            ret[report_type_category]['out'] += counts

        print item['_id']
    return ret