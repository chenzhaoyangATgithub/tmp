#!/usr/bin/python
# -*- coding: utf-8 -*-
import datetime

from .statistics.exchange import gen_datestring, get_trends, get_counts

__author__ = 'mk'


def shadowserver_recentdays():
    def _fill_the_holes(trend_dict,whole_dt_str_list):
        ret = {}
        for single_type,counts_kv in trend_dict.items():
            tmp_cnt_list =[counts_kv[dt_str] if dt_str in counts_kv else 0 for dt_str in whole_dt_str_list]

            ret[single_type] = {'name':whole_dt_str_list,'value':tmp_cnt_list}
        return ret

    start_dt_7ago = datetime.datetime.now() - datetime.timedelta(days=6)
    start_dt_30ago = datetime.datetime.now() - datetime.timedelta(days=29)
    end_dt = datetime.datetime.now()
    #生成datestring
    dtstr7_list = gen_datestring(start_dt_7ago,end_dt,interval='DAILY')
    #print 'dtstr7:',dtstr7_list
    dtstr30_list = gen_datestring(start_dt_30ago,end_dt,interval='DAILY')

    #top types
    typetrend_last30days_tmp = get_trends({'creating_date':{'$gt':start_dt_30ago, '$lt':end_dt}},
                                    group_by='report_type_intelligence_type')
    typetrend_last30days = _fill_the_holes(typetrend_last30days_tmp,dtstr30_list)

    # botnet
    botnet_recent_7days_tmp = get_trends({'creating_date':{'$gt':start_dt_7ago, '$lt':end_dt},
                                            'report_type_intelligence_type':'botnet'},
                                         group_by='report_type_shortname')
    botnet_recent_7days = _fill_the_holes(botnet_recent_7days_tmp,dtstr7_list)

    #sandbox
    sandbox_recent_7days_tmp = get_trends({'creating_date':{'$gt':start_dt_7ago, '$lt':end_dt},
                                            'report_type_intelligence_type':'sandbox'},
                                         group_by='report_type_shortname')
    sandbox_recent_7days = _fill_the_holes(sandbox_recent_7days_tmp,dtstr7_list)

    return {'total':typetrend_last30days,
            'botnet':botnet_recent_7days,
            'sandbox':sandbox_recent_7days}


def get_top_n_24h(n):
    start_dt = datetime.datetime.now()-datetime.timedelta(hours=24)
    end_dt = datetime.datetime.now()
    FILTER = {'creating_date':{'$gte':start_dt, '$lte':end_dt}}
    ret_types = get_counts(FILTER,group_by='report_type_name',order_by=-1,limit=n)
    ret_by = get_counts(FILTER,group_by='exchange_from',order_by=-1,limit=n)

    ret_types['name'].reverse()
    ret_types['value'].reverse()

    ret_by['name'].reverse()
    ret_by['value'].reverse()
    return {'top_n_types':ret_types,
            'top_n_by':ret_by}