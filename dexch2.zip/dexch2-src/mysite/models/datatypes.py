#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from pymongo import MongoClient
from .mongo_helper import value_convert
from .statistics.exchange import Name2MongoKey

conn_mongo = MongoClient()

# def rebuild_datatypes_collection():#only for 临时处理, 此表应该提前建立
#     pipeline = [{'$group':{'_id':'$report_info.report_type'}}]
#     report = conn_mongo.origin.report
#
#     for item in report.aggregate(pipeline):
#         dt = item['_id']
#         result = conn_mongo.origin.datatypes.insert(dt)
#         print result.inserted_id
#
# def update_reports_collection():#临时处理
#     cursor = conn_mongo.origin.datatypes.find()
#     for item in cursor:
#         id = item['_id']
#         name = item['name']
#         result = conn_mongo.origin.report.update_many({'report_info.report_type.name':name},
#                                         {'$set':{'report_info.report_type.id':id}})
#         print result.modified_count

def get_types_tree_from_reports(category=None, organization=None):
    """
    :param category: list or string
    :param organization: list or string
    :return: dict {"category1":{"organization1":[datetype1,datatypes2,...],
                                ""organization2:[datatype1,datetype2,...],
                                ...
                                },
                    ...
                }

    """

    ret = {}
    FILTER={}
    # 用于将来对权限的控制
    FILTER.update(value_convert('report_info.report_type.category', category))
    FILTER.update(value_convert('report_info.report_type.organization', organization))
    print 'FILTER',FILTER

    pipeline = [{'$match':FILTER},
                {'$group':{'_id':'$%s'%Name2MongoKey['report_type'],
                           'count':{'$sum':1}}}]

    report = conn_mongo.origin.report
    for item in report.aggregate(pipeline):

        print 'item:',item
        if item: #有可能为none
            category = item['_id']['origin_organization']['category']
            organization = item['_id']['origin_organization']['name']
            nm = item['_id']['origin_type_id']

            # if 'id' in item['_id']:
            #     id = item['_id']['id']
            # else:
            #     id = conn_mongo.origin.report

            if category not in ret:
                ret[category] = {}
            if organization not in ret[category]:
                ret[category][organization]=[]
            ret[category][organization].append(nm)

    #假数据
    ret.update({
                # 'enterprise':{'google':['google_url'],
                #               'microsoft':['microsoft_confiker']},

                # 'APCERT':{},
                # 'ASEANCERT':{},
                # 'private':{}
                })
    return ret

def _get_counts_tree_from_reports(filter_input={},category=None, organization=None):
    """
    递归得到数据数据类型
    :param category: list or string
    :param organization: list or string
    :return: dict {"category1":{"organization1":[datetype1,datatypes2,...],
                                ""organization2:[datatype1,datetype2,...],
                                ...
                                },
                    ...
                }

    """

    ret = {}
    FILTER={}
    # 用于将来对权限的控制
    for k,v in filter_input.items():
        FILTER.update(value_convert(Name2MongoKey[k], v))

    FILTER.update(value_convert(Name2MongoKey['report_type_category'], category))
    FILTER.update(value_convert(Name2MongoKey['report_type_organization'], organization))
    print 'FILTER',FILTER

    pipeline = [{'$match':FILTER},
                {'$group':{'_id':'$%s'%Name2MongoKey['report_type'],
                           'count':{'$sum':1}}}]

    report = conn_mongo.origin.report
    for item in report.aggregate(pipeline):
        # 跟数据库表结构强相关
        print 'item:',item
        if item: #有可能为none
            category = item['_id']['origin_organization']['category']
            organization = item['_id']['origin_organization']['name']
            nm = item['_id']['origin_type_id']
            cnt = item['count']

            # if 'id' in item['_id']:
            #     id = item['_id']['id']
            # else:
            #     id = conn_mongo.origin.report

            if category not in ret:
                ret[category] = {}
            if organization not in ret[category]:
                ret[category][organization]={}
            ret[category][organization][nm] = cnt

    #假数据
    ret.update({
                # 'APCERT':{},
                # 'ASEANCERT':{},
                # 'private':{}
                })
    print ret
    return ret

def get_counts_tree_in(category_name=None, organization_name=None):
    def _get_names_and_values(detail_dict):
        names = detail_dict.keys()
        values = []
        for name in detail_dict:
            value = sum(detail_dict[name]['value'])
            values.append(value)
        return names,values

    filter = {'exchange_from':{'$exists':True}}
    raw = _get_counts_tree_from_reports(filter,category=category_name, organization=organization_name)

    ret_category = {'name':[],'value':[],'detail':{}}
    # makeup categories detail
    for category_name in raw:
        ret_category['detail'][category_name] = {'name':[], 'value':[], 'detail':{}}
        #makeup organizations detail
        for organization_name in raw[category_name]:
            # for list
            obj = raw[category_name][organization_name]
            names = obj.keys()
            values = obj.values()
            ret_category['detail'][category_name]['detail'][organization_name] = {'name':names, 'value':values}

        organizations_detail = ret_category['detail'][category_name]['detail']
        names,values = _get_names_and_values(organizations_detail)
        ret_category['detail'][category_name]['name'] = names
        ret_category['detail'][category_name]['value'] = values
        # category:name and value

    categories_detail = ret_category['detail']
    names,values = _get_names_and_values(categories_detail)
    ret_category['name'] = names
    ret_category['value'] = values

    # get organization counts
    #ret_category['organization_counts'] = len(ret_category['detail'])
    return ret_category

def get_counts_tree_out(category_name=None, organization_name=None):
    def _get_names_and_values(detail_dict):
        names = detail_dict.keys()
        values = []
        for name in detail_dict:
            value = sum(detail_dict[name]['value'])
            values.append(value)
        return names,values

    filter = {'exchange_to':{'$exists':True}}
    raw = _get_counts_tree_from_reports(filter,category=category_name, organization=organization_name)

    ret_category = {'name':[],'value':[],'detail':{}}
    # makeup categories detail
    for category_name in raw:
        ret_category['detail'][category_name] = {'name':[], 'value':[], 'detail':{}}
        #makeup organizations detail
        for organization_name in raw[category_name]:
            # for list
            obj = raw[category_name][organization_name]
            names = obj.keys()
            values = obj.values()
            ret_category['detail'][category_name]['detail'][organization_name] = {'name':names, 'value':values}

        organizations_detail = ret_category['detail'][category_name]['detail']
        names,values = _get_names_and_values(organizations_detail)
        ret_category['detail'][category_name]['name'] = names
        ret_category['detail'][category_name]['value'] = values
        # category:name and value

    categories_detail = ret_category['detail']
    names,values = _get_names_and_values(categories_detail)
    ret_category['name'] = names
    ret_category['value'] = values

    # get organization counts
    #ret_category['organization_counts'] = len(ret_category['detail'])
    return ret_category



def _datatype_list(category=None, organization=None):
    """

    :param category: list or non-list or None
    :param organization: list or non-list or None
    :return: datatypes list
    """

    FILTER={}
    FILTER.update(value_convert('report_info.report_type.category', category))
    FILTER.update(value_convert('report_info.report_type.organization', organization))

    report = conn_mongo.origin.report
    pipeline = [{'$match':FILTER},
                {'$group':{'_id':'$report_info.report_type.name',
                           #'count':{'$sum': 1}
                           }}]
    ret = []
    for r in report.aggregate(pipeline):
        print r
        ret.append(r['_id'])
    return ret

def _organizations(category=None):
    pass

def _categories():
    pass

#todo:需要专门维护一个库，用来存储分类信息category
def get_all_by_typecache():
    pass

def get_all_directly():
    return conn_mongo.origin.datatypes.find_all()

def update_disksize():#todo:database:datatypes
    """
    statistics.datatype:
    {
        '_id':pass,
        'category':pass,
        'organization':pass,
        'name':pass,
        'fullname':pass,
        'briefname':pass,
        'disksize':pass,
        'dbpath':pass,
        'databasepath':pass,
    }
    :return:
    """
    pass


def tmp_migrage_from_reports():
    pass



if __name__ == '__main__':
    rebuild_datatypes_collection()

