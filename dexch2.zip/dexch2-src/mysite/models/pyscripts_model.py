#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import pymongo

conn_mongo = pymongo.MongoClient()
collection = conn_mongo.rules.pyscripts

def add_one(script):
    print 'script:',script
    r = collection.insert_one(script)
    ret = True if r.inserted_id else False
    return ret,str(r.inserted_id)

def list_all(id=None):
    if id is None:
        filter = {}
    else:
        filter = {"_id":id}

    ret = []
    cursor = collection.find(filter)
    for doc in cursor:
        ret.append(doc)
    return ret

def find_one(id):
    ret = collection.find_one({'_id':id})
    return ret

def check_exsited(key,value):
    filter = {key:value}
    cursor = collection.find_one(filter)
    if cursor is None:
        return False
    else:
        return True

def update_one(id,scripts):
    r = collection.update_one({'_id':id}, {'$set':scripts})

    ret = True if r.modified_count else False
    return ret,r.modified_count

def delete_one(id):
    r = collection.delete_one({'_id':id})
    ret = True if r.deleted_count else False
    return ret,r.deleted_count



# def disable_one(rule_id):
#     pass
#
# def active_one(rule_id):
#     pass
#
