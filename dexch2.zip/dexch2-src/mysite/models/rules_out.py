#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import pymongo
from bson import ObjectId
conn_mongo = pymongo.MongoClient()
collection = conn_mongo.rules.dataout

def find(rule_id=None):
    if rule_id is None:
        filter = {}
    else:
        filter = {"_id":rule_id}

    ret = []
    cursor = collection.find(filter)
    for doc in cursor:
        ret.append(doc)
    return ret

def insert_one(data_input):
    """
    :param data_input:
    :return:
    """

    try:
        if '_id' not in data_input:
            data_input['_id'] = str(ObjectId())
        r = collection.insert_one(data_input)
    except Exception,err:
        print err
        return False,str(err)

    ret = True if r.inserted_id else False
    return ret,str(r.inserted_id)

def delete_one(rule_id):
    r = collection.delete_one({'_id':rule_id})
    ret = True if r.deleted_count else False
    return ret,r.deleted_count

def find_one(rule_id):
    pass

def update_one(rule_id, new):

    if not isinstance(new,dict):
        return False,'data must be dict.data:%s'%new

    if 'enable' in new and not isinstance(new['enable'],bool):
        return False,'data["enable"] must be bool'

    r = collection.update_one({'_id':rule_id}, {'$set':new})

    ret = True if r.modified_count else False
    return ret,r.modified_count

def delete_many(rule_ids):
    print rule_ids

    if not isinstance(rule_ids,list):
        return False,'ids must be list!'

    r = collection.delete_many({'_id':{'$in':[id for id in rule_ids]}})
    # print r.deleted_count
    ret = True if r.deleted_count else False
    return ret,r.deleted_count

