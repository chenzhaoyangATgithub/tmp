#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import logging
import logging.config
import logging.handlers
import json

def setup_logging(
    default_path='logger.json',
    default_level=logging.INFO,
    env_key='LOG_CFG'
):
    """Setup logging configuration

    """
    path = default_path
    value = os.getenv(env_key, None)
    if value:
        path = value
    if os.path.exists(path):
        with open(path, 'rt') as f:
            config = json.load(f)
        logging.config.dictConfig(config)
    else:
        logging.basicConfig(level=default_level)


def file_logger_make(logger_name, log_path, log_level=logging.INFO,
                     log_formatter='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s'):

    logger = logging.getLogger(logger_name)
    file_handler = logging.handlers.TimedRotatingFileHandler(log_path,when='D',backupCount=7)
    file_handler.setFormatter(logging.Formatter(log_formatter))
    logger.addHandler(file_handler)
    logger.setLevel(log_level)

    return logger
