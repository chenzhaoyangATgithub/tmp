#!/usr/bin/python
# -*- coding: utf-8 -*-

"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""

from django.conf.urls import url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

from mysite import views_api, views

urlpatterns = [
    url(r'^login/$', views.login_page),
    url(r'^$', views.index),
    url(r'^admin/', admin.site.urls),
    url(r'^intelligence/query/$',views.intelligence_query_page),
    url(r'^nav/$',views.nav_page),

    url(r'^manage/passwd/$', views.passwd_manage_page),
    url(r'^manage/admin/$',views.admin_manage_page),
    url(r'^manage/users/$',views.users_manage_page),
    url(r'^manage/sysinfo/$',views.sysinfo_manage_page),
    url(r'^manage/journal/$',views.journal_manage_page),

    url(r'^rules/in/$', views.rule_in_page),
    url(r'^rules/out/$',views.rule_out_page),
    url(r'^pyscripts/$',views.pyscripts_admin_page),

    url(r'^statistics/query/$', views.statistics_query_page),
    url(r'^statistics/report/$',views.statistics_report_page),
    url(r'^statistics/custom/$',views.statistics_custom_page),

    # url(r'^statistics/day/$',views.statistics_day_page),
    # url(r'^statistics/week/$',views.statistics_week_page),
    # url(r'^statistics/month/$',views.statistics_month_page),
    # url(r'^statistics/quarter/$',views.statistics_quarter_page),
    # url(r'^statistics/halfyear/$',views.statistics_halfyear_page),
    # url(r'^statistics/year/$',views.statistics_year_page),

    url(r'^api/src/datatypes/$', views_api.get_datatypes),##todo:任何数据类型要首先注册

    url(r'^api/statistics/$', views_api.get_recent_statistics),#暂时弃用
    # url(r'^api/statistics/query/$', views_api.get_statistics_query),# 显示图形
    url(r'^api/statistics/report/$', views_api.get_statistics_reports),#显示文字,应该区分方向,表示汇入

    url(r'^api/login/$', views_api.user_login), #进行认证和鉴权
    url(r'^api/logout/$', views_api.user_logout),
    url(r'^api/homeinfo/$', views_api.home_info),
    url(r'^api/manage/passwd/$',views_api.manage_passwd),
    url(r'^api/manage/users/$',views_api.manage_users),
    url(r'^api/manage/sysinfo/$',views_api.manage_sysinfo),
    url(r'^api/logoreset/$',views_api.reset_logo),
    url(r'^api/sysstate/$',views_api.sysstate),

    url(r'^api/rules/in/$', views_api.rules_datain),#新增或列出或删除rule
    url(r'^api/rules/in/bulkinvalid/$', views_api.rules_datain_bulkinvalid),#批量删除rule状态
    url(r'^api/rules/out/$',views_api.rules_dataout),
    url(r'^api/rules/out/bulkinvalid/$',views_api.rules_dataout_bulkinvalid),

    url(r'^api/journals/$',views_api.get_journals),

    url(r'^api/pyscripts/$',views_api.manage_pyscripts),
    url(r'^api/pyscripts/simple/$',views_api.list_pyscripts_simple),

    url(r'^api/es/', views_api.es_operation),
    url(r'^api/test/emailfolders/$', views_api.test_email_folders),
    url(r'^api/test/reportfields/$', views_api.test_report_fields),
]

if settings.DEBUG:
    # static files (images, css, javascript, etc.)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)