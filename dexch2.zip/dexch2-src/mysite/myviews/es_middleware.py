#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import requests


def transport(rest_method,rest_url,rest_json):
    result = False
    info = 'default'

    url = 'http://localhost:9200'+ rest_url
    if rest_method == 'GET':
        print url
        response = requests.get(url =url,json=rest_json)
        result = True
        info = response.content

    # elif rest_method == 'POST':
    #     response = requests.post(url =url,json=rest_json)
    #     result = True
    #     info = response.content
    else:
        result = False
        info = 'bad rest method'
    print 'es:',result,info

    return result,info



