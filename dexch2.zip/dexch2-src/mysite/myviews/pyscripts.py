#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'
from mysite.models import pyscripts_model
import uuid
from mysite.settings import ScriptsDir
import os

"""
本模块对脚本进行管理，入库字段如下：
{
    #从脚本库中加载,输入为脚本文件,输出为可入库json
    'name':'XXX',#
    'description':'XXX',
    'category':'XXX',#email,ftp,其他的(<>)
    'file':'/XX/XX/XX.py',#上传的文件的绝对路径，后台程序使用,前台为上传框
    'content':'XXX',#给前段显示内容用
    'script_id':'xxxxxxxx......',#用来做脚本索引的,对页面来说，应该是invisible
}


"""

def read_pyscripts_file(file_name):
    content = None
    if file_name:
        fname = os.path.join(ScriptsDir,file_name)
        with open(fname,'rb') as fobj:
            content = fobj.read()
    return content

def write_pyscript_file(fh, file_name):
    if not file_name:
        raise ValueError('bad filename for pyscript: %s'%filename)

    fname = os.path.join(ScriptsDir,file_name)
    with open(fname,'wb') as fobj:
        for chunk in fh.chunks():
            fobj.write(chunk)

def get_all(request,ret_full=True):
    ret = pyscripts_model.list_all()
    if ret_full: #返回所有内容
        for doc in ret:
            filename = doc['filename']
            content = read_pyscripts_file(filename)
            doc.update({'content':content})

    return True,ret


def create_one(request):
    try:
        name = request.POST['name']
        description = request.POST['description']
        category = request.POST['category']
    except KeyError,err:
        return False,'KeyError:%s'%err


    if pyscripts_model.check_exsited('name',name):
        return False,'name: has existed!'
    if not name:
        return False,'name: can not be empty'

    # stat,check_info = check_format(category)
    # if not stat:
    #     return False,'category: %s'%(check_info)

    uu_id = uuid.uuid4()
    script_id = 'script_%s'%(str(uu_id))

    file = request.FILES.get('file')
    fname = None
    if file:
        fname = '%s.py'%script_id
        write_pyscript_file(file,fname) #todo: csrf
    else:
        return False,'file required'

    script = {'name':name,
              'description':description,
              'category':category,
              '_id':script_id,
              'filename':fname,
              }

    ret,info = pyscripts_model.add_one(script)
    return ret,info

def update_one(request):
    try:
        script_id = request.POST['_id']
        name = request.POST['name']
        description = request.POST['description']
        category = request.POST['category']

    except KeyError,err:
        return False,'KeyError:%s'%err

    #上传文件
    file = request.FILES.get('file')
    if file:
        fname = '%s.py'%script_id
        write_pyscript_file(file,fname) #todo: csrf
    # else:
    #     return False,'file required'

    script = {'name':name,
              'description':description,
              'category':category,

              }

    ret,info = pyscripts_model.update_one(script_id,script)
    return True,info

def delete_one(request):
    try:
        script_id = request.POST['_id']
    except KeyError,err:
        return False,'KeyError:%s'%err

    result,info = pyscripts_model.delete_one(script_id)
    return result,info



def check_format(name):
    if not (isinstance(name,str) and name):
        return False,"must be str and can't be empty"
    if not name[0].isalpha():
        return False,'must start with letter'
    #todo: can't be empty
    return True,name




