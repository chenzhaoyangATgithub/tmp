#!/usr/bin/python
# -*- coding: utf-8 -*-

from mysite.data_in_v1.task import makeup_process_conf
from mysite.data_in_v1.task_process.email_trans.trans import get_all_folders
from mysite.data_in_v1.task_process.process import do_process
import logging
logging.basicConfig(level=logging.INFO)
logging.info('print logging...')

def test_getting_fields(process_conf):
    result = False
    info = 'default'
    try:
        new_process_conf = makeup_process_conf(process_conf,process_conf['script_id'],None)
    except Exception as err:
        print err
        raise err
        result = False
        info = err
        return result, info
    else:
        print 'new_process_conf:',new_process_conf

        generator = do_process(new_process_conf,test_mode=True)
        for report in generator:
            records = report['records']
            if len(records) > 0:  #todo：有可能捕获结果为空，应该继续下一轮
                fields = records[0].keys()
                result = True
                info = fields
                return result, info
            else:
                result = False
                info = 'empty fields'
                return result, info

def test_getting_email_dirs(email_trans_detail):
    from pprint import pprint
    dirs = get_all_folders(email_trans_detail)
    return dirs

if __name__ == '__main__':
    process_conf = {         #处理脚本化：传输协议可走克重协议；但是信息处理过程本期只能脚本化，不支持细分
            'transport_type':'email', #传输协议类型 email,ftp,web api
            'transport_detail':{
                "server":'imap.exmail.qq.com',
                "port":'993',
                "use_ssl":True,
                "mail_account":"shadowserver@cert.org.cn",
                "password":'WOai123',
                "dir_from":'&UXZO1mWHTvZZOQ-/test_inbox',
                "done_dir":'&UXZO1mWHTvZZOQ-/test_out',
                "mail_title_regex":'\[China\] Shadowserver China Spam URL Report:\s.*(\d{4}-\d{2}-\d{2})',
            }, #传输协议细节,具体见其他的细节,输出为文件，文本文件或者其他文件，可预览。
            'script_id':'script_shadowserver_spamurl',#前端传过来的
            'script':{           #从脚本库中加载,输入为脚本文件,输出为可入库json
                'name':'XXX',#
                'description':'XXX',
                'file':'/XX/XX/XX.py',#上传的文件,上传框
                'content':'XXX',#给使用者看的，
                'filename':'script_shadowserver_spamurl.py',#用来索引磁盘的存储路径
                '_id':'script_shadowserver_spamurl',#用来做脚本索引的,invisible
            },#输出以json文件方式提供，然后由上次调度器来解决json文件入库问题
            '_meta':{
                'rule_id':'',#不能删除，一定要留档
            }
        }
    result,info = test_getting_fields(process_conf)
    print result,info
    #
    # transport_detail = {
    #             "server":'imap.mxhichina.com',
    #             "port":'993',
    #             "use_ssl":True,
    #             "mail_account":"sunboxuan@antiy.cn",
    #             "password":'********',
    #             "dir_from":'Intelligence',
    #             "done_dir":'googleurl_dumped',
    #             "mail_title_regex":'\s*Compromised URLs on .cn',
    #         }
    # test_get_email_dirs(transport_detail)


