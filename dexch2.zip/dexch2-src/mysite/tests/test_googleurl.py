#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'
"""
#处理规则
api version v0.1
"""
from mysite.data_in_v1.task import finish_task

def rule_in():
    """
    - input:
    与用户交互，获得相应的输入

    - output:
    向数据库中输入以下结构json，用于处理程序处理：

    rules.datain: #此json作为数据汇入处理接口的输入,处理接口的输出为：数据库中的统一化json结构,该结构请见下面
    {
        '_id':'xxxxxxxx', #由后台创建，invisable 只能增加，不能被删除，审计或者其他考虑；用于关联处理结果与规则，rule_id
        'rule_name':'test_finish',
        'enable':True, #是否开启本策略，
        'process':{         #数据获取及处理策略。处理脚本化：传输协议可走克重协议；但是信息处理过程本期只能脚本化，不支持细分
            'transport_type':'email', #传输协议类型 email,ftp,web api
            'transport_detail':{
                "server":'imap.mxhichina.com',
                "port":'993',
                "use_ssl":True,
                "mail_account":"xxx@antiy.cn",
                "password":'******',
                "dir_from":'Intelligence',
                "done_dir":'googleurl_dumped',
                "mail_title_regex":'\s*Compromised URLs on .cn',
            }, #传输协议细节,具体见其他的细节,输出为文件，文本文件或者其他文件，可预览。
            'script_id':'',#前端传过来的，其他脚本因袭由后台据此来自动填充
        },
        'enrich':{ #数据丰富化策略。本步骤用来对process步骤获得的json信息进行填充,相应参数需要用户填写,里面信息用于搜索与汇出的依据
            'origin_type_id':'google_ioc_url',#组织简称+包括种类
            'origin_organization':{'name':'google.com',
                                 'brief_name':'google',
                                 'category':'open_feed'},
            'intelligence_type':{'category':'ioc',  #还需要调整,前端应该为下拉列表，之后会对其进行专门管理
                                 'future_fields':{'url':[], # 哪些字段能体现改威胁情报的特征，用于查找，由用户填写
                                                  'ip':[],
                                                  'hash':[]
                                                  }
                                 },
            #'field_names':[], #所有的字段名称，暂时不由用户传输
            'secret_level':'open',   #保密等级 open or secret
        },
        'data_storage':{ #数据存储策略
            'month_reserved':3, #单位为月':<int>,#单位为月，需要用户填写，默认为3个月
            #'storage_used':3,#单位为M,由后台自动产生本字段，不需要填写
        }

        #用于对数据库的指定，暂时保留;如果不同的数据类型要指定不同库来存储，则需要此处来指定
        # 'database_info':{
        #     'dbname':{}
        # },

    },



    #对上面的详细解释，不同的transport detail:email,ftp,apcert
    {
        transport_type:'email',
        transport_detail: # for email
        {
            "server":<string>,
            "port":<string>,
            "use_ssl":T/F,
            "mail_account":"XXX@antiy.cn",
            "password":<string>,
            "dir_from":<string>,
            "dir_done":<string>,
            "mail_title_regex":<string>,
        }
    }

    {
        transport_type:'ftp',
        transport_detail: # for ftp
        {
            "server":<string>,
            "password":<string>,
            "dir_from":<string>,
            "dir_done":<string>,
            "filename_regex":<string>,
        }


    }

    {
        transport_type:'apcert_dataexchanger_platform',
        transport_detail: # for apcert_dataexchanger_platform
        {
              'allowed_organization':[],
              'allowed_datatypes':[]
        }

    }
    """
    pass


def process_datain(in_rule):
    """
    接收输入in_rule,根据规则进行相应的后台处理，最终输出符合要求的json重新入库

    - input:
    见上面的rule_in()函数的输出


    - output:
    # 统一化输出的json结构，用于查询，输出的结构应该有所体现

    origin.report:
    {
        '_id':<report_id>,
        '_meta':{
            'dates':{},
            'ids':{},

        }
        'records':[
            {#k-v对,可能存在嵌套结构
            'k1':'v1',
            'k2':'v2',
            ...
            },
            ...
        ],
        'files':[
            {
            #'content': <StringIO.StringIO instance>,# 存储到硬盘后,删掉此字段,增加saving_dir_id,便于后续持久化，；以saving_dir_id,作为名称。
            'filename': "avatar.png",
            'content-type': 'image/png',
            'size': 80264,
            },

        ],
        'report_info':{
            'origin_type_id':'google_ioc_url',#格式必须进行限定,

            'origin_organization':{'name':'google.com',
                                 'brief_name':'google',
                                 'category':'open_feed'},
            'intelligence_type':{'category':'ioc',  #还需要调整
                                 'subcategory':'url',
                                 'contained_types':['url','ip'],
                                 'future_fields':{'url':[],# 哪个字段能体现改威胁情报的特征，用于查找
                                                  'ip':[],
                                                  'hash':[]},
                                 },
            'field_names':[],
            'secret_level':'open', #保密等级 open or secret
            'rule_in_id':rule_id,#对数据源的汇入处理的规则的id，见上面rule_in()
        },

    }
    """
    pass

def test_finish_task():

    task_conf = {
        #'rule_version':'v0.1', #暗示处理结构,这个信息是后台对应的调度器来控制填写的
        '_id':'xxxxxxxx', #由后台创建，invisable 只能增加，不能被删除，审计或者其他考虑；用于关联处理结果与规则，rule_id
        'rule_name':'test_finish',#检查，不可重复
        'enable':True, #是否开启本策略，默认为False

        'process':{         #处理脚本化：传输协议可走克重协议；但是信息处理过程本期只能脚本化，不支持细分
            'transport_type':'email', #传输协议类型 email,ftp,web api
            'transport_detail':{
                "server":'imap.mxhichina.com',
                "port":'993',
                "use_ssl":True,
                "mail_account":"sunboxuan@antiy.cn",
                "password":'wondering321!',
                "dir_from":'Intelligence',
                "dir_done":'googleurl_dumped',
                "mail_title_regex":'\s*Compromised URLs on .cn',
            }, #传输协议细节,具体见其他的细节,输出为文件，文本文件或者其他文件，可预览。
            'script_id':'',#前端传过来的
            'script':{           #从脚本库中加载,输入为脚本文件,输出为可入库json
                'name':'XXX',#
                'description':'XXX',
                'file':'/XX/XX/XX.py',#上传的文件,上传框
                'content':'XXX',#给使用者看的，
                'filename':'script_googleurl.py',#用来索引磁盘的存储路径
                '_id':'script_googleurl',#用来做脚本索引的,invisible
            },#输出以json文件方式提供，然后由上次调度器来解决json文件入库问题
            'rule_id':'xxxxxxxx',#不能删除，在处理过程中会用到
        },
        'enrich':{ #本步骤用来对process步骤获得的json信息进行填充,相应参数需要用户填写,里面信息用于搜索与汇出
            'origin_type_id':'google_ioc_url',#组织简称+包括种类
            'origin_organization':{'name':'google.com',
                                 'brief_name':'google',
                                 'category':'corporation'},#open_feed,corporation
            'intelligence_type':{'category':'ioc',  #还需要调整,前端应该为下拉列表
                                 'subcategory':'url', #分类标准
                                 'future_fields':{'url':['url'], # 哪些字段能体现改威胁情报的特征，用于查找
                                                  'ip':[],
                                                  'hash':[]
                                                  }
                                 },
            #'field_names':[], #所有的字段名称
            'secret_level':'open',   #保密等级 open or secret
        },
        'data_storage':{ #数据存储策略,用户批量删除或者转移数据的参考
            'month_reserved':3, #单位为月':<int>,#单位为月，需要用户填写，默认为3个月
            'M_storage_used':3,#单位为M,由后台自动产生本字段，不需要填写
            'disk_saving_strategy':'BaseDir|OriginTypeId|YYMMDD|ProcessId|Data', #后台可自行产生,for human
        }
        #用于对数据库的指定，暂时保留;如果不同的数据类型要指定不同库来存储，则需要此处来指定
        # 'database_info':{
        #     'dbname':{}
        # },

    }
    ret,info = finish_task(task_conf)
    print 'result:',ret,info

if __name__ == '__main__':
    test_finish_task()
