#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from mysite.data_in_v1.task import finish_task

def test_finish_task():

    task_conf = {
        #'rule_version':'v0.1', #暗示处理结构,这个信息是后台对应的调度器来控制填写的
        '_id':'xxxxxxxx', #由后台创建，invisable 只能增加，不能被删除，审计或者其他考虑；用于关联处理结果与规则，rule_id
        'rule_name':'test_finish_shadowserver',#检查，不可重复
        'enable':True, #是否开启本策略，默认为False

        'process':{         #处理脚本化：传输协议可走克重协议；但是信息处理过程本期只能脚本化，不支持细分
            'transport_type':'email', #传输协议类型 email,ftp,web api
            'transport_detail':{
                "server":'imap.exmail.qq.com',
                "port":'993',
                "use_ssl":True,
                "mail_account":"shadowserver@cert.org.cn",
                "password":'WOai123',
                "dir_from":'&UXZO1mWHTvZZOQ-/test_inbox',
                "dir_done":'&UXZO1mWHTvZZOQ-/test_out',
                "mail_title_regex":'\[China\] Shadowserver China Spam URL Report:\s.*(\d{4}-\d{2}-\d{2})',
            }, #传输协议细节,具体见其他的细节,输出为文件，文本文件或者其他文件，可预览。
            'script_id':'',#前端传过来的
            'script':{           #从脚本库中加载,输入为脚本文件,输出为可入库json
                'name':'XXX',#
                'description':'XXX',
                'file':'/XX/XX/XX.py',#上传的文件,上传框
                'content':'XXX',#给使用者看的，
                'filename':'script_shadowserver_spamurl.py',#用来索引磁盘的存储路径
                '_id':'script_shadowserver_spamurl',#用来做脚本索引的,invisible
            },#输出以json文件方式提供，然后由上次调度器来解决json文件入库问题
            'rule_id':'xxxxxxxx',#不能删除，在处理过程中会用到
        },
        'enrich':{ #本步骤用来对process步骤获得的json信息进行填充,相应参数需要用户填写,里面信息用于搜索与汇出
            'origin_type_id':'shadowserver_ioc_spamurl',#组织简称+包括种类
            'origin_organization':{'name':'shadowserver.org',
                                 'brief_name':'shadowserver',#不允许有特殊字符，只能是字母或数字
                                 'category':'open_feed'},
            'intelligence_type':{'category':'ioc',  #还需要调整,前端应该为下拉列表，不允许有特殊字符，只能时字母或数字
                                 'subcategory':'spamurl', #分类标准；不允许有特殊字符，只能是字母或数字
                                 'future_fields':{'url':['url','host'], # 哪些字段能体现改威胁情报的特征，用于查找
                                                  'ip':['ip','src'],
                                                  'hash':[]
                                                  }
                                 },
            'field_names':[], #所有的字段名称
            'secret_level':'secret',   #保密状态 open or secret,默认为secret
        },
        'data_storage':{ #数据存储策略,用户批量删除或者转移数据的参考
            'month_reserved':3, #单位为月':<int>,#单位为月，需要用户填写，默认为3个月
            'M_storage_used':3,#单位为M,由后台自动产生本字段，不需要填写
            'disk_saving_strategy':'BaseDir|OriginTypeId|YYMMDD|ProcessId|Data', #后台可自行产生,for human
        }
        #用于对数据库的指定，暂时保留;如果不同的数据类型要指定不同库来存储，则需要此处来指定
        # 'database_info':{
        #     'dbname':{}
        # },

    }
    ret,info = finish_task(task_conf)
    print 'result:',ret,info

if __name__ == '__main__':
    test_finish_task()