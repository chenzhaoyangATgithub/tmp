#!/usr/bin/python
# -*- coding: utf-8 -*-

__author__ = 'mk'


# 输入rule规则,输出json
# v0.1
import logging
import os
logger = logging.getLogger(__name__)

from .task_process import do_process
from .to_db import mongo,es
from mysite.models import pyscripts_model
from mysite.models import rules_in as rules_report_in
from .to_disk import dump_attatchments_strio,dump_json
from mysite.settings import DATA_DUMPED_ROOT
from uuid import uuid4


def start():
    # get conf from db
    task_conf_list = fetch_new_task()
    for task_conf in task_conf_list:
        logger.info('start task:%s'%task_conf)
        ret,info = finish_task(task_conf)
        #todo:log record
        logger.info('%s %s'%(ret,info))


def fetch_new_task():
    new_task = {}
    tasks = rules_report_in.find()
    #todo:从数据库拿到task conf
    return tasks

def test_process(process_conf):
    pass


def finish_task(rule_conf_datain,test_mode=False):
    """
    输入用户输入的rule,输出根据信息得到的json,
    作为data_collection中的一例或者若干例
    :param rule:

    :return:

    """

    # 1.process
    whole_process_conf = makeup_process_conf(rule_conf_datain['process'],
                                             rule_conf_datain['process']['script_id'],
                                             rule_conf_datain['_id'])
    rule_conf_datain.update({'process':whole_process_conf})
    logger.info(rule_conf_datain)

    data_from_many_reports = do_process(whole_process_conf) # generator or list

    for data_in_one_report in data_from_many_reports:

        # raw_data should be a dict
        status,info = check_rawdata_format(data_in_one_report)
        if not status:
            #todo:raise err,response to user
            raise ValueError('raw data:%s'%info)

        # _dump_raw_report(data_in_one_report)
        # print data_in_one_report

        # 2.enrich report data
        rich_data_one_batch = _enrich(data_in_one_report, rule_conf_datain)
        #logger.info('rich_data:',rich_data)

        # 3.other process
        #final_jsons_batch = _other_process(rich_data_one_batch)
        # final_json_batch = rich_data_one_batch

        print 'rich:'
        print rich_data_one_batch

        # 4.to disk
        ## dump file
        json_with_newer_fn = _dump_files_to_disk(rich_data_one_batch)

        ## dump info
        final_json_batch = _clear_file_content(json_with_newer_fn)
        _dump_fulljson_to_disk(final_json_batch)

        # 5.to db
        ## to
        _to_db(final_json_batch)

    return True,'finish'



def makeup_process_conf(raw_process_conf,script_id,rule_id):

    new_process = dict()
    new_process.update(raw_process_conf)

    # add script content to process
    if 'script' not in new_process:
        ret = pyscripts_model.find_one(script_id)
        if ret:
            new_process['script'] = ret
        else:
            raise ValueError('bad script id:%s' % (script_id))

    if 'rule_id' not in new_process:
        new_process['rule_id'] = rule_id

    return new_process


def check_rawdata_format(raw_data):
    """

    :param raw_data:

    {
            'records':[{},{}],
            'files':[{
                    'content': <StringIO.StringIO instance>,
                    'filename': "avatar.png",
                    'content-type': 'image/png',
                    'size': 80264
                    },
                    ...

            ]
    },
    :return:
    """
    if isinstance(raw_data,dict):
        return True,'good'
    else:
        return False,'dict format required'


def _dump_raw_report(raw_data):
    """
    :param raw_data:
    {
            'process_id':<str>,
            'records':[{},{}],
            'files':[{
                    'content': <StringIO.StringIO instance>,
                    'filename': "avatar.png",
                    'content-type': 'image/png',
                    'size': 80264
                    },
                    ...

            ]
    },
    """

    pass

def _enrich(raw_report_json, rule_conf):
    """

    :param raw_report_json:
    {
        '_meta':{
            'dates'
        }
       'records':[{

                },
       ...
       ],
       'files':[{
                    'content': <StringIO.StringIO instance>,
                    'filename': "avatar.png",
                    'content-type': 'image/png',
                    'size': 80264
                    },
                    ...
                ]
    }
    :param rule_conf:
    :return:
    final report json
    {

    }

    """

    ret = {}
    ret.update(raw_report_json)

    # enrich
    enrich_conf = rule_conf['enrich']
    ret.update({'enrich':enrich_conf})

    # update ret:  _meta.ids
    print '_meta:',ret['_meta']

    ids = ret['_meta']['ids']

    creating_date = ret['_meta']['dates']['creating']
    YMD_str = creating_date['daily']
    # get origin id
    origin_type_id = rule_conf['enrich']['origin_type_id']
    # generate process id
    process_id = ret['_meta']['ids'].get('process_id',str(uuid4()))
    # generate saving dir id
    saving_dir_id_tmplt = os.path.join('{origin_type_id}','{YMD}','{process_id}')
    saving_dir_id = saving_dir_id_tmplt.format(origin_type_id=origin_type_id,YMD=YMD_str,
                                                process_id=process_id)
    ids.update({'origin_type_id':origin_type_id,
                'process_id':process_id,
                'saving_dir_id':saving_dir_id,
                })

    # update ret: data_storage
    data_storage_conf = rule_conf['data_storage']
    if 'saving_dir_id' not in data_storage_conf:
        data_storage_conf.update({'saving_dir_id':saving_dir_id})
    ret.update({'data_storage':data_storage_conf})

    # update ret:report_futures

    future_fields_conf = rule_conf['enrich']['intelligence_type']['future_fields']
    raw_records = raw_report_json['records']
    report_futures = dict()
    for future_type,raw_field_name_list in future_fields_conf.items():# ip ,hash,url ,or other
        report_futures[future_type] = [{'name':raw_field_name,'values':[ record.get(raw_field_name) for record in raw_records]} \
                            for raw_field_name in raw_field_name_list]

    ret.update({'report_futures':report_futures})
    return ret

def _other_process(input_data):
    ret = input_data
    return ret

def _to_db(data):
    """
    :param jsons:
    {
        '_id':'',#record id
        '_meta':{ #处理过程中来进行
            'dates':{
                'creating':{
                    'obj':<datetime obj>,
                    'yearly':<>,
                    'monthly':'',
                    'daily':'',
                    'hourly':'',
                    'epoch':'',#可以定位file的disk path,采用epoch time str
                },
                'report':{
                    'obj':<datetime obj>,
                    'yearly':<>,
                    'monthly':'',
                    'daily':'',
                    'hourly':'',
                    'epoch':'',#可以定位file的disk path,采用epoch time str
                },
            },
            'ids':{
                'rule_id':'',
                'process_id':'',
            },
        },
        'records':[],#最终入库用的信息,里面是具体的字段
        'files':[ {  #相关联的文件，二进制存储于磁盘，以process id作为索引

                },
                ...
        ],
        'enrich':{},#分类,种类,等相应信息，配置信息
        'future_fields':{
            'ip':[{'name':'','value':''},
                ...
            ],
            'url':[{'name':'','value':''},
                ...
            ],
            'hash':[{'name':'','value':''}
                    ...
            ],

        }

    }
    :return: 
    """

    if data:
        mongo.insert_json_to_mongo(data)
        if '_id' in data:
            data.pop('_id')
        es.insert_json_to_es(data)

def _dump_files_to_disk(data_input):
    """
    有副作用
    {
        '_id':'',#record id
        '_meta':{ #处理过程中来进行
            'dates':{
                'creating':{
                    'obj':<datetime obj>,
                    'yearly':<>,
                    'monthly':'',
                    'daily':'',
                    'hourly':'',
                    'epoch':'',#可以定位file的disk path,采用epoch time str
                },
                'report':{
                    'obj':<datetime obj>,
                    'yearly':<>,
                    'monthly':'',
                    'daily':'',
                    'hourly':'',
                    'epoch':'',#可以定位file的disk path,采用epoch time str
                },
            },
            'ids':{
                'rule_id':'',
                'process_id':'',
                'origin_type_id':'',
                'saving_dir_id':'',
            },
            '':
        },
        'records':[],#最终入库用的信息,里面是具体的字段
        'files':[ {  #相关联的文件，二进制存储于磁盘，以process id作为索引
                 {
                    #'content': <StringIO.StringIO instance>,# 存储到硬盘后,删掉此字段,增加saving_dir_id,便于后续持久化，；以saving_dir_id,作为名称。
                    'filename': "avatar.png",
                    'content-type': 'image/png',
                    'size': 80264,
                },
                ...
        ],
        'enrich':{ #分类,种类,等相应信息，配置信息

        },
        'future_fields':{
            'ip':[{'name':'','values':[]},
                ...
            ],
            'url':[{'name':'','values':[]},
                ...
            ],
            'hash':[{'name':'','values':[]}
                    ...
            ],

        }
    }
    :param data_input:
    :return:
    """
    ret = dict()
    ret.update(data_input)

    if data_input and data_input['files']:
        attatchments = data_input['files']

        saving_dir_id = data_input['_meta']['ids']['saving_dir_id']
        save_dir = os.path.join(DATA_DUMPED_ROOT,saving_dir_id)
        print 'save to:',save_dir

        actual_fns = dump_attatchments_strio(attatchments, dirpath=save_dir)#todo:拆分函数实现，保持纯粹

        # update attatchments
        for cnt,one in enumerate(attatchments):
            one.update({'actual_fn':actual_fns[cnt]})
        ret.update({'files':attatchments})
    return ret

def _dump_fulljson_to_disk(data_input):
    saving_dir_id = data_input['_meta']['ids']['saving_dir_id']
    save_dir = os.path.join(DATA_DUMPED_ROOT,saving_dir_id)
    print 'save to:',save_dir

    tracking_code = data_input['_meta'].get('tracking_code')
    if not tracking_code:
        fn = 'info.json'
    else:
        fn = str(tracking_code) + '.json'
    dump_json(data_input,save_dir,fn)

def _clear_file_content(data):
    """
    替换文件里的content内容，以便持久化存储
    :param data:
    :return:
    """
    ret = dict()
    ret.update(data)

    if data and data['files']:
        # update data['files]
        for one_file in data['files']:
            one_file.pop('content')

        ret.update({'files':data['files']})

    return ret



