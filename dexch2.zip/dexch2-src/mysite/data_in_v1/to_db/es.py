#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import json
import datetime
import requests

from elasticsearch import Elasticsearch
es = Elasticsearch([{'host': 'localhost', 'port': 9200}])


def insert_json_to_es(report):
    ret = None
    if report:
        # print 'to es:',report
        # str = json.dumps(report,indent=4,default=json_serial)
        ret = es.create('origin','report',body=report)
    return ret

def delete_all_reports():
    # dangerous

    url = 'http://localhost:9200'+ '/origin/'
    ret = requests.delete(url=url)
    # ret = es.indices.delete(index='origin')
    return ret


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, datetime.datetime):
        serial = obj.isoformat()
        return serial
    raise TypeError ("Type not serializable")

