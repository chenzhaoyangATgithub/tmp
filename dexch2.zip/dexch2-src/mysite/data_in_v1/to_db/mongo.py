#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from pymongo import MongoClient
mongo_conn = MongoClient()
collection = mongo_conn.origin.report

def insert_jsons_to_mongo(jsons, collection=collection):
    #todo:根据一定的规则，将json入库

    result = collection.insert_many(jsons)
    return result.inserted_ids

def insert_json_to_mongo(json, collection=collection):
    #todo:根据一定的规则，将json入库

    result = collection.insert_one(json)
    return result

def remove_all():
    collection.remove()
