#!/usr/bin/python
# -*- coding: utf-8 -*-
import re
import logging
logger = logging.getLogger(__name__)

__author__ = 'mk'


def belong_to_me(message, something_re):
    subject = message.subject
    logger.info('subject:%s'%subject)
    ret = identify_title(subject,something_re)

    if ret:
        return True
    else:
        logger.info('not mine,skip and continue..\n')
        return False


def identify_title(raw_title_str,title_re):
    ret = False

    logger.info('raw title:%s'%raw_title_str)
    title_str = raw_title_str.replace('\r\n',' ') # fix some bad character
    logger.info('new title:%s'%title_str)

    pattern_str = r'%s'%title_re
    pattern = re.compile(pattern_str,re.M|re.I)
    m = pattern.search(title_str)
    #if m.group(0)
    if m:
        ret = True

    return ret