#!/usr/bin/python
# -*- coding: utf-8 -*-
import datetime
import time

from .imbox import Imbox
from .dumpfile import dump_all_to_disk
from .identify import belong_to_me
import re

import logging
__author__ = 'mk'

logger = logging.getLogger(__name__)

def get_all_folders(trans_conf):
    imapbox = Imbox(trans_conf['server'],
                    username=trans_conf['mail_account'],
                    password=trans_conf['password'],
                    ssl=trans_conf['use_ssl'],
                    ssl_context=None)
    resp,folders = _all_folders(imapbox)

    ret = []
    print 'raw:',folders
    for folder in folders:
        # '(\\HasChildren) "/" NameOfFolder'
        # flag,_,c = folder.partition(' ')
        # separator,_, dirname = c.partition(' ')
        re_pattern = r'\((.*)\) "(.*)" "(.*)"'

        pattern = re.compile(re_pattern,re.M|re.I)
        m = pattern.search(folder)
        print m.groups()
        if m:
            flag = m.group(1)
            dirname = m.group(3)
            print flag,dirname
            ret.append({'flag':flag,
                        'dirname':dirname})

    return ret

def do_transport_email(trans_conf,test_mode=False,dump_dir=None, nday=7, markseen=False, **kwargs):
    """
    根据传输协议进行处理
    :param trans_conf:
    :param dump_dir:
    :param nday:
    :param markseen:
    :param kwargs:
    :return: generator
    [
        {
            'info':{},
            'files':[{
                    'content': <StringIO.StringIO instance>,
                    'filename': "avatar.png",
                    'content-type': 'image/png',
                    'size': 80264
                    },
                    ...

            ]
        },
        ...
    ]
    """
    imapbox = Imbox(trans_conf['server'],
                    username=trans_conf['mail_account'],
                    password=trans_conf['password'],
                    ssl=trans_conf['use_ssl'],
                    ssl_context=None)
    all = _all_folders(imapbox)
    print(all)
    logger.info(all)

    # today = datetime.date.today()
    # daysago = today-datetime.timedelta(days=nday)
    # print('today:',today,'ago:',daysago)

    messages = imapbox.messages(
                                unread=True,
                                # date__lt=trans_conf.get('date_gt'),
                                #date__gt=daysago,
                                folder=trans_conf['dir_from'],
                                sent_from=trans_conf.get('sent_from',False)
                                )

    for uid,message in messages:
        #print(message['raw_email'])

        # skip if not mine
        if not belong_to_me(message, trans_conf['mail_title_regex']):
            logger.info('message skip:%s'%message.subject)
            continue

        try:
            logger.info('process uid:%s'%uid)
            logger.info('message subject:%s'%message.subject)

            info,attachments = parse_and_dump(message, dump_dir, **kwargs)
            result = {'info':info,'files':attachments}
            yield result

            if not test_mode:
                if markseen:
                    imapbox.mark_seen(uid)
                    logger.info('markseen.')
                if trans_conf.get('dir_done'):
                    imapbox.move(uid, trans_conf['dir_done'])
                    logger.info('mv to:%s'%trans_conf['dir_done'])
        except Exception as err:

            logger.exception(err)
            raise ValueError('test')

        time.sleep(0.1)


def _all_folders(imapbox):
    all = imapbox.folders()
    return all


def parse_and_dump(imap_message_obj, dump_dir, **kwargs):
    """
    分析邮件内容并dump相关信息
    :param imap_message_obj:
    :return:T/F,info
    """

    message = imap_message_obj
    message_dict = unpack_message(message)
    # # meta info
    # email_date_string = message_dict['date']
    # # Tue, 23 Aug 2016 17:25:43
    # email_date = datetime.datetime.strptime(email_date_string.split('+')[0],'%a, %d %b %Y %H:%M:%S ')
    # my_name_code = email_date.strftime('%Y%m%d')+'_'+str(int(time.time())) #todo:需要重新考虑索引机制

    #all info but for attachments
    attachments = message_dict.pop('attachments')
    # remove character " in filename
    for attatchment in attachments:
        if 'filename' in attatchment:
            attatchment['filename'] = attatchment['filename'].strip('"')
    # parsed_info = message_dict
    # if dump_dir:
    #     dump_all_to_disk(my_name_code, parsed_info, attachments, dump_dir)#todo:重构，name_code文件夹里存放正文和附件

    # exit(0)

    return message_dict,attachments


def unpack_message(message):
    ret = {}
    #print message.keys()

    #ret['sent_from'] = message.sent_from
    kk = message.to_dict()
    ret.update(kk)

    return ret