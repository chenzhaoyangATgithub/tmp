#!/usr/bin/python
# -*- coding: utf-8 -*-
import os

import logging

__author__ = 'mk'
logger = logging.getLogger(__name__)

def dump_all_to_disk(name_code,parsed_info,attachments,dump_dir,**kwargs):
    raw_path = os.path.join(dump_dir,'raw',report_date)
    info_path = os.path.join(dump_dir,'info',report_date)

    email_utils.dump_json(parsed_info,info_path,my_name_code+'.json')
    if attachments:
        fn = my_name_code +'.zip' #todo:需要根据上层来命名
        dump_attatchmets(attachments,dirpath=info_path,
                         filenames=[fn]) #todo:现阶段附件只有一个
    # raw eml
    if kwargs.get('dump_raw') is True:
        email_utils.dump_raw_eml(message.raw_email,raw_path,my_name_code+'.eml')


def dump_attatchmets(attachments_strio, dirpath,filenames=None):
    def _save_to_disk(stringio_obj,filepath):
        with open(filepath,'wb') as fd:
            stringio_obj.seek(0)
            print(type(stringio_obj))
            shutil.copyfileobj(stringio_obj,fd)


    for num,attach in enumerate(attachments_strio):
        origin_fn = attach['filename'].strip('"')
        sp = os.path.splitext(origin_fn)
        # file name
        if filenames is None:
            if num == 0:
                filename = origin_fn
            else:
                filename = sp[-2]+str(num)+sp[-1]
        else:
            filename = filenames[num]

        # skip condition
        email_utils.ensure_dir(dirpath)
        f_path = os.path.join(dirpath,filename)
        if os.path.isfile(f_path):
            logger.info('exists,continue..')
            continue

        # dump content
        content = attach['content']
        _save_to_disk(content,f_path)


def dump_valid_bodyinfo(body):
    #body plain
    body_plain = body['plain']
    if body_plain:
        unicoded = [item.decode('utf-8') if (type(item) is bytes) else item for item in body_plain] #python3
        strings = ''.join(unicoded) #todo:safety
        details = pick_body_shadowserver(strings) #todo:考虑之后直接扔进数据库
        INFO = {'_meta':{'email_date':email_date.isoformat(),'num':len(details),'by':'email','report_date':report_date},#todo:isoformat
                'details':details}

        email_utils.dump_json(INFO,info_path,my_name_code+'.json')
        #todo:db operation

    else:
        print('empty body plain')
        logger.error('empty plain body,please check the info blew:')
        logger.info(body_plain)

    body_html = body['html']
    if body_html:
        logger.error('wrong format for the email feed')
        logger.info(body_html)