#!/usr/bin/python
# -*- coding: utf-8 -*-

__author__ = 'mk'

# 输出正文信息，附件信息，采用imbox结构
#　list

import os

from .trans import do_transport_email



