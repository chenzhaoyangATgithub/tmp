#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import logging
logger = logging.getLogger(__name__)

def run_in_host(script_conf, json_info, file_list = None):

    data = None
    print 'script_conf:',script_conf
    module_name = script_conf['_id']
    #todo:test
    print 'module_name:',module_name
    # module_name = 'my_uploaded_test'
    module = get_module(module_name)
    data = module.run(json_info, file_list)

    return data


def get_module(module_name):
    if not module_name:
        return None
    else:
        return __import__(module_name)