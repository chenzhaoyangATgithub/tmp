#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

def run_in_docker(script_conf, json_info, bytes_io_list = None):
    #脚本试运行运行

    script_fname = script_conf['filename']
    # 构建运行环境
    prepare_env(script_fname,json_info,bytes_io_list)
    data = running()
    clean_env()
    return data


def prepare_env(script_fname,json_info,bytes_io_obj):

    pass


def running():

    pass

def clean_env():
    pass
