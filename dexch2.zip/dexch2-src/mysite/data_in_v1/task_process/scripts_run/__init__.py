#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from mysite.settings import DOCKER_SHARE_ROOT,PYSCRIPT_PLACED_ROOT
import shutil
import os
import sys
from r_docker import run_in_docker
from r_host import run_in_host

print 'PYSCRIPT_PLACED_ROOT:',PYSCRIPT_PLACED_ROOT
sys.path.append(PYSCRIPT_PLACED_ROOT)

RUN_IN_DOCKER = False

def run_my_script(script_conf, json_info, files_list):
    if RUN_IN_DOCKER:
        data = run_in_docker(script_conf, json_info, files_list)
    else:
        data = run_in_host(script_conf, json_info, files_list)

    return data




