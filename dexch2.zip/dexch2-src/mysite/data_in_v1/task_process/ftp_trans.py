#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

# 输出文件列表


def do_ftp_transport(ftp_trans_conf, script_conf):
    pass