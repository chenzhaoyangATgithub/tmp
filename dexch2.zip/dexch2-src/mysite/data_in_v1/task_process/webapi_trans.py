#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

#输入api，输出脚本

def do_webapi_transport(webapi_trans_conf, script_conf):
    pass