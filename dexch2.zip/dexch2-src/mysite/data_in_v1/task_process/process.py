#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from .email_trans import do_transport_email
from .scripts_run import run_my_script
from .ftp_trans import do_ftp_transport
from .webapi_trans import do_webapi_transport

DISK_PROCESS_MODE = False
# logger = logging.getLogger(__name__)
import os
from mysite.mylogger import file_logger_make
from mysite.settings import LOG_ROOT
import logging
from uuid import uuid4

log_path = os.path.join(LOG_ROOT,'process.log')
logger = file_logger_make(None, log_path=log_path,log_level=logging.INFO) #root logger
import bson


def do_process(process_conf,test_mode=False):
    """
    :param process_conf:
    {
        'process':{#处理脚本化：传输协议可走克重协议；但是信息处理过程本期只能脚本化，不支持细分
                'transport_type':'email', #传输协议类型 email,ftp,web api
                'transport_detail':{
                    "server":'imap.mxhichina.com',
                    "port":'993',
                    "use_ssl":True,
                    "mail_account":"sunboxuan@antiy.cn",
                    "password":'******',
                    "dir_from":'Intelligence',
                    "done_dir":'googleurl_dumped',
                    "mail_title_regex":'\s*Compromised URLs on .cn',
                }, #传输协议细节,具体见其他的细节,输出为文件，文本文件或者其他文件，可预览。
                'script_id':'',#前端传过来的用户所选的id
                'script':{           #后端得到，非前端上传;根据用户所选id从脚本库中加载而来,输入为脚本文件,输出为可入库json
                    'name':'XXX',#
                    'description':'XXX',
                    'file':'/XX/XX/XX.py',#上传的文件,上传框
                    'content':'XXX',#给使用者看的，
                    'filename':'my_uploaded_test.py',#用来索引磁盘的存储路径
                    '_id':'googleurl',#用来做脚本索引的,invisible
                },#输出以json文件方式提供，然后由上次调度器来解决json文件入库问题
                '_meta':{  #后端自主生成
                    'rule_id':'',#不能删除，一定要留档
                }
            },
    }
    :return:generator
    [
        {
            '_meta':{
                'dates':{},
                'ids':{

                }
            },
            'records':[{},{}],
            'files':[{
                    'content': <StringIO.StringIO instance>,
                    'filename': "avatar.png",
                    'content-type': 'image/png',
                    'size': 80264
                    },
                    ...

            ]
        },
        ...
    ]
    """

    trans_type = process_conf['transport_type']
    process_func_collection = {'email': email_process,
                    'ftp': ftp_process,
                    'webapi': webpai_process,
    }

    func = process_func_collection.get(trans_type)
    if func:
        json_list = func(process_conf,test_mode)
        #print 'json list:',json_list
        return json_list
    else:
        return []

def email_process(process_conf,test_mode = False):
    """
    一次连接活动，可能会返回多次数据
    :param process_conf:
    {

    }
    :return:generator
    [
        {
           '_meta':{
                'dates':{
                    'creating':{},
                    'report':{},
                },
                'ids':{
                    'rule_id':'',
                    'process_id':''},

           },
           'records':[{k1:v1},
                    {k1:v2},
                    ...
            ],
           'files':[
                        {
                        'content': <StringIO.StringIO instance>,
                        'filename': "avatar.png",
                        'content-type': 'image/png',
                        'size': 80264
                        },
                    ...
            ]
        },
        ...
    ]
    """
    emails = do_transport_email(process_conf['transport_detail'],test_mode=test_mode)#获取文件实体集合<generator>
    for email in emails:
        body_info = email['info']
        attatchments = email['files']

        try:
            #print 'bodyinfo:',type(body_info)
            data_page = run_my_script(process_conf['script'], json_info=body_info, files_list=attatchments)
            #print 'email_data:',data
            print 'email data return by script:',type(data_page)

            # fill in _meta.ids
            if '_meta' not in data_page:
                data_page['_meta'] = {}
                #data_page['_meta']['dates'] = {'dates'}
            rule_id = process_conf.get('rule_id')
            process_id = str(uuid4())
            data_page['_meta'].update({'ids':{'rule_id':rule_id,'process_id':process_id}})
            # update raw info from body_info
            data_page['_meta']['raw'] ={ 'subject':body_info['subject'],
                                         'sent_from':body_info['sent_from'],
                                         'sent_to':body_info['sent_to']}

            yield data_page

        except Exception ,err:
            logger.exception(err)
            print '!!!Script Runing Error:',err
            if test_mode:
                raise err
                #todo:发送给客户端

def ftp_process(process_conf):
    pass

def webpai_process(process_conf):
    pass
