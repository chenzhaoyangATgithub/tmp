#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from mysite.settings import DATA_DUMPED_ROOT
import json
import os
import shutil
import logging
import subprocess
from os.path import join
import datetime

logger = logging.getLogger(__name__)


def dump_one_report(report):
    pass

def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, datetime.datetime):
        serial = obj.isoformat()
        return serial
    raise TypeError ("Type not serializable")

def dump_raw_eml(eml_obj,dir,eml_name):
    ensure_dir(dir)
    f_path = join(dir,eml_name)
    with open(f_path,'w') as f:
        f.write(eml_obj)
    logger.debug('eml:%s write done!'%f_path)

def dump_json(dict_obj,dir,filename):
    """
    会保证文件夹的存在；不存在则建立文件夹
    :param dict_obj:
    :param dir:
    :param filename:
    :return:
    """
    #python3
    ensure_dir(dir)
    path = join(dir,filename)
    str = json.dumps(dict_obj,indent=4,default=json_serial)
    with open(path,'w') as f:
        #print(type(str))
        f.write(str)

def ensure_dir(dir_path):
    subprocess.call(['mkdir','-p',dir_path])


def dump_attatchments_strio(attachments_strio, dirpath, filenames_input=None):
    """

    :param attachments_strio:
    [
        {
            'content': <StringIO.StringIO instance>,
            'filename': "avatar.png",
            'content-type': 'image/png',
            'size': 80264
        }
    ]
    :param dirpath:
    :param filenames_input:
    :return:actual filenames

    """
    actual_fn = []

    def _save_to_disk(stringio_obj,filepath):
        with open(filepath,'wb') as fd:
            stringio_obj.seek(0)
            print(type(stringio_obj))
            shutil.copyfileobj(stringio_obj,fd)

    raw_fn_set = set() #防重名
    for num,attach in enumerate(attachments_strio):
        raw_fn = attach['filename'].strip('""')

        sp = os.path.splitext(raw_fn)
        # make sure file name
        content = attach['content']
        if filenames_input is None: #外部不干预
            if raw_fn in raw_fn_set:
                filename = sp[-2]+str(num)+sp[-1]
            else:
                filename = raw_fn
                raw_fn_set.add(filename)
        else: #使用外部给予名称
            filename = filenames_input[num]

        # dump
        ensure_dir(dirpath)
        f_path = os.path.join(dirpath,filename)
        if os.path.isfile(f_path):
            print('file has existed,leaving..')
            continue
        _save_to_disk(content,f_path)
        # leave
        actual_fn.append(filename)

    return actual_fn