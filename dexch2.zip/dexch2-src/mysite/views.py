#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from django.http.response import HttpResponse,HttpResponseRedirect
from django.shortcuts import render
from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib.auth.decorators import login_required

@ensure_csrf_cookie
def login_page(request):
    if request.user.is_authenticated():
        return HttpResponseRedirect('/')

    return render(request,'login.html')

def hello(request):
    return HttpResponse('hello')

@login_required()
def index(request):
    return render(request,'home.html')

@login_required()
def statistics_query_page(request):
    return render(request,'statistics_query.html')

@ensure_csrf_cookie
@login_required()
def passwd_manage_page(request):
    return render(request,'manage_passwd.html')

@ensure_csrf_cookie
@login_required()
def admin_manage_page(request):
    return render(request,'manage_admin.html')

@ensure_csrf_cookie
@login_required()
def users_manage_page(request):
    return render(request,'manage_users.html')

@ensure_csrf_cookie
@login_required()
def sysinfo_manage_page(request):
    return render(request,'manage_sysinfo.html')

def journal_manage_page(request):
    return render(request,'manage_journal.html')

@ensure_csrf_cookie
@login_required()
def rule_in_page(request):
    return render(request,'rule_in.html')

@login_required()
def rule_out_page(request):
    return render(request,'rule_out.html')

def pyscripts_admin_page(request):
    return render(request,'pyscripts.html')

@login_required()
def statistics_custom_page(request):
    return render(request,'statistics_custom.html')

@login_required()
def statistics_report_page(request):
    return render(request,'statistics_report.html')

# def statistics_day_page(request):
#     return render(request,'statistics_day.html')
#
# def statistics_week_page(request):
#     return render(request,'statistics_week.html')
#
# def statistics_month_page(request):
#     return render(request,'statistics_month.html')
#
# def statistics_quarter_page(request):
#     return render(request,'statistics_quarter.html')
#
# def statistics_halfyear_page(request):
#     return render(request,'statistics_halfyear.html')
#
# def statistics_year_page(request):
#     return render(request,'statistics_year.html')

@login_required()
def intelligence_query_page(request):
    return render(request,'intelligence_query.html')

@login_required()
def nav_page(request):
    return render(request,'nav.html')

