#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

import pymongo
from pprint import pprint

mongo_conn = pymongo.MongoClient()
collection = mongo_conn.origin.report

import pytz
utc=pytz.UTC
# clear
now = utc.localize(datetime.datetime.now())
cursor = collection.find()
for doc in cursor:
    id = doc['_id']
    print id
    dt = id.generation_time
    if dt < (now-datetime.timedelta(days=15)):
        c.origin.report_bk.insert_one(doc)
        c.origin.report.delete_one({'_id':doc['_id']})
        print 'move:',id
