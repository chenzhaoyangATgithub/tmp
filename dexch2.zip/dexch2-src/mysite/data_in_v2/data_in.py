#!/usr/bin/python
# -*- coding: utf-8 -*-
from mysite.data_core import crawl_transported_file

__author__ = 'mk'

from crawler import crawler
from rawfile_proc import proc
from kv_parser import parse_kv
from mapping import field_map


def data_in(main_conf)
    transport_conf = main_conf['transport']
    proc_conf = main_conf['rawfile_proc']
    parser_conf = main_conf['kv_parser']
    map_rule = main_conf['mapping']
    addtion_info = main_conf['enrich']

    #1　具备预制模式ftp,email, 需要自定义模式 http api
    rawfiles,trans_meta = p_transport(transport_conf)

    #2 具备预制模式　email　
    string_list,bin_list,file_explain = proc(rawfiles,proc_conf)

    #3 从各种文本文件中提取　k-v　
    kv_list = parse_kv(string_list, file_explain, parser_conf)

    #4 字段映射,形成新的k-v
    new_kv = field_map(kv_list,map_rule)

    #5 enrich 添加丰富化信息
    final_json = enrich(new_kv,addtion_info)

    return final_json


def test_data_in():

    transport_conf = {'transport_type':'ftp',
                      'transport_detail':{}
                      }

    proc_conf = {'proc_type':'email_type',
                 'script':None,
                 'params':[]}

    parser_conf = {'grok_rules':[],
                   're_rules':[{'name1':''}]}

    map_rule = {
                'mapping_rule':{'k1':'k1',
                                'k2':'k2',
                                'k3':'k4'},

                }

    addtion_info = {
            'origin_type_id':'google_ioc_url',

            'origin_organization':{'name':'google.com',
                                 'brief_name':'google',
                                 'category':'open_feed'},
            'intelligence_type':{'category':'ioc',  #还需要调整
                                 'main_format':'url',
                                 'contained_types':['url','ip'],
                                 'future_fields':{'url':[],# 哪个字段能体现改威胁情报的特征，用于查找
                                                  'ip':[],
                                                  'hash':[]},
                                 },
            'final_total_fields':[],
            'secret_level':'open', #保密等级 open or secret
    }

    sendout_info = {}

    main_conf = {'transport':transport_conf,
                 'rawfile_proc':proc_conf,
                 'kv_parser':parser_conf,
                 'mapping':map_rule,
                 'enrich':addtion_info}

    good_json = data_in(main_conf)
    print good_json


def p_transport(conf):
    """
    内置协议处理
    :param conf:
    :return:
    {
        '_meta':{ ＃跟协议本身有关的信息,待扩充
            'creating_date':< datetime obj>,
        },
        'files':{
            'transport_type':'',
            'names':[],#filenames
            'objs':[<fileobj>],#对应的文件对象，如bytesio等等。
        }
    }
    """
    trans_type = conf['transport_type']
    trans_detail = conf['transport_detail']
    if trans_type == 'email':
        _,_ = crawl_transported_file(trans_type,trans_detail)
    pass