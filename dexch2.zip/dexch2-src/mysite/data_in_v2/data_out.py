#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

# 输入ruleout,输出对应数据

def process_rule_out(outrule,data_collection):
    """
    根据用户定制的数据输出的rule,将对应的数据输出
    :param outrule:
    :return:
    """
    pass
