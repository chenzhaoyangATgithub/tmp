#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'


def email_crawler(conf):
    pass

def ftp_crawlwer(conf):
    pass

def httprest_crawler(conf):
    """
    需要定制的脚本,需要联网权限，单独放在一个可联网的容器中.
    每次进行爬取，每运行一次，则重启一次；限制联网类型脚本必须为我方提供。

    :param conf:
    :return:
    """
    pass



