#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

def parse_kv(text_list,text_explain,parser_conf):
    return {}
