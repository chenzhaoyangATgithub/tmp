#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

container_conf = {'volume_base_dir':''}

def crawl_transported_file(transport_type, transport_detail):
    """
    input:

    {
        'transport_type':'http_api',#传输类型：其他可选类类型包括：email,ftp
        'transport_detail':{　　#这里面的东西根据http api 的具体情况来定,如果是自定义脚本，此处为空
        }，

    }

    output:
    - files:{
        'transport_type':'email',#ftp,web_api ,每种代表一种处理模式
        'names':[],#filenames
        'objs':[<fileobj>],#如bytesio等等。
    }
    - meta: #协议元信息
    {
        'creating_date':< datetime obj>,
    }

    """
    pass

    return {},{}


