#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

"""
input:

output:　text_files,bin_files,

"""

def proc(rawfiles,proc_conf):
    """
    """
    ret = []
    explain = {'string_files':}
    return ['string1','string2'],[],explain
