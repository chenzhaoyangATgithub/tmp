#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

def field_map(kv_list,map_rule):
    pass
