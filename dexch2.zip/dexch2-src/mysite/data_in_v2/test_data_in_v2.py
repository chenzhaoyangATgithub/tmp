#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'
from data_core import crawler

import pymongo

c = pymongo.MongoClient()
rulesin_collection = c.rules.datain

def explore_rules():
    cursor = rulesin_collection.find()
    for doc in cursor:
        common_rule = doc['common_rule']

        trans_rule = doc['trans_conf']
        proc_rule = doc['proc_conf']

        trans_id = use_trans(trans_rule)
        proc_id = use_proc(trans_id,proc_rule)
        report = enrich(proc_id,common_rule)

        data_ret = datain(report)
        log_ret = log(report)



