#!/usr/bin/python
# -*- coding: utf-8 -*-

import datetime
import sys,os

base_dir = os.path.dirname(os.path.abspath('__file__'))
print 'base_dir:',base_dir
sys.path.extend([base_dir])

from models.statistics.exchange import get_counts,get_trends
from models.statistics_recentdays import get_top_n_24h


# from models.statistics.datatypes import rebuild_datatypes_collection,update_reports_collection

def test_get_counts():
    start = datetime.datetime.now() - datetime.timedelta(days=100)
    end = datetime.datetime.now()
    print 'start',start
    print get_counts({'creating_date':{'$gt':start,'$lt':end},
                      'report_type_name':None})
def test_get_trends():
    start = datetime.datetime.now() - datetime.timedelta(days=100)
    end = datetime.datetime.now()
    print get_trends({'creating_date':{'$gt':start,'$lt':end},'report_type_name':None},
                     interval='DAILY'
                     )

def test_get_top_n_24h():
    print get_top_n_24h(5)


#test_get_counts()
#test_get_trends()

#rebuild_datatypes_collection()
#update_reports_collection()


#test_get_top_n_24h()
