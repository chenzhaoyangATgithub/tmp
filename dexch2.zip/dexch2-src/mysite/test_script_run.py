#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from mysite.settings import DOCKER_SHARE_ROOT,PYSCRIPT_PLACED_ROOT
import sys

print 'PYSCRIPT_PLACED_ROOT:',PYSCRIPT_PLACED_ROOT
sys.path.append(PYSCRIPT_PLACED_ROOT)


def get_module(module_name):
    if not module_name:
        return None
    else:
        return __import__(module_name)


module_name = 'my_uploaded_test'
module = get_module(module_name)
data = module.run({}, None)
print data
