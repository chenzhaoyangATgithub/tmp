#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'mk'

from settings import BASE_DIR
print BASE_DIR
import sys
sys.path.extend([BASE_DIR])

from mysite.tests import test_aus, test_googleurl
from mysite.data_in_v1.to_db.es import delete_all_reports
from mysite.data_in_v1.to_db.mongo import  remove_all

def clear_db_and_es():
    ret = delete_all_reports()
    print ret
    ret = remove_all()
    print ret

clear_db_and_es()
test_googleurl.test_finish_task()
test_aus.test_finish_task()

