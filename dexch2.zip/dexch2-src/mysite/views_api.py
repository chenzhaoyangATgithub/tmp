#!/usr/bin/python
# -*- coding: utf-8 -*-
from django.http import HttpResponse

__author__ = 'mk'

import datetime
import json
import logging
import os
import time
import uuid

from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.http.response import HttpResponse,HttpResponseRedirect,HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt

import myviews.pyscripts
from myviews import es_middleware,rule_running_test
from .models import journal
from .models import rules_in,rules_out
from .models import statistics_report, statistics_for_home
from .models import sysinfo,datatypes
from .models.statistics import exchange

logger = logging.getLogger(__name__)
import traceback

def user_login(request):
    error_info='default_info'
    operation_journal_type = 'user_login'

    if request.method == 'POST':

        name = request.POST.get('uname')
        passwd = request.POST.get('upasswd')

        user = authenticate(username=name, password=passwd)
        print 'user login:',user

        if user is not None:
            if user.is_active:
                login(request,user)
                print user,'active'

                journal_str = 'successful'
                journal.new(request,operation_type=operation_journal_type,result=journal_str,user_obj=user)
                return HttpResponse(json.dumps({'result':True,'info':'good'}))
                # return HttpResponse(json.dumps({'result':False}))
            else:
                print 'no active'
                error_info='user is not active!'
        else:
            error_info='user not exists'

        journal_str = 'failed for %s'%error_info
        journal.new(request,operation_journal_type,result=journal_str)
        return HttpResponse(json.dumps({'result':False,'info':error_info}))
    else:
        error_info = 'method not allowed!'

        journal_str = 'failed for %s'%error_info
        journal.new(request,operation_type=operation_journal_type,result=journal_str)
        return HttpResponse(json.dumps({'result':False,'info':error_info}))

def user_logout(request):
    logout(request)
    journal.new(request,operation_type='user_logout',result='successful')
    return HttpResponseRedirect('/login/')

def get_datatypes(request):
    """
    后期加权限的话，对传入的category和organization加限制
    :param request:
    :param category:
    :param organization:
    :return:
    """
    if request.method == 'GET':
        dt = datatypes.get_types_tree_from_reports()
        #import pprint
        #pprint.pprint(dt)
        return HttpResponse(json.dumps(dt))
    else:
        return HttpResponse('method not allowed!')

def get_statistics_reports(request):#todo many
    """
    表单参数无，则表示对应参数选择所有
    :param request:
    :return:
    """
    if request.method == 'GET':
        print 'request.GET:',request.GET
        start_epoch_t = request.GET.get('start_time')
        end_epoch_t = request.GET.get('end_time')
        #category = request.GET.get('category')
        interval_type = request.GET.get('interval_type','daily')
        organization_names = request.GET.getlist('organization_selected[]')
        type_names = request.GET.getlist('datatype_selected[]')
        #type_id_list = request.GET.get('type_id_list') #none or list
        print '\n\norganization names:',organization_names

        if not(start_epoch_t and end_epoch_t):
             start_epoch_t = time.mktime((datetime.datetime.now() - datetime.timedelta(days=30)).timetuple())
             end_epoch_t = time.time()
             #todo:temp op
             #return HttpResponseBadRequest('not include key parameter:start_time,end_time ')

        # pick parameters
        try:
            start_dt = datetime.datetime.fromtimestamp(int(start_epoch_t)) #todo:utcfromtimestamp?
            end_dt = datetime.datetime.fromtimestamp(int(end_epoch_t))    # todo:above
            print 'now:',datetime.datetime.now()
            print 'start epoch:',start_epoch_t,'end epoch:',end_epoch_t
            print 'param:',start_dt,end_dt,type_names


        except ValueError,err:
            print(err)

            return HttpResponseBadRequest('err:%s'%err)

        reports = statistics_report.query_organization_reports(start_dt, end_dt, interval_type,
                                                               organization_names)
        return HttpResponse(json.dumps(reports))
    else:
        return HttpResponse('method not allowed!')

def get_recent_statistics(request):
    """
    dated api,for home
    :param request:
    :return:
    """
    top_n_24h = statistics_recentdays.get_top_n_24h(5)
    shadowserver_last7d = statistics_recentdays.shadowserver_recentdays()
    return HttpResponse(json.dumps({'top_n_types_24h': top_n_24h['top_n_types'],
                                    'top_n_by_24h': top_n_24h['top_n_by'],
                                    'ss_total_trend_7days': shadowserver_last7d['total'],
                                    'ss_botnet_7days': shadowserver_last7d['botnet'],
                                    'ss_sandbox_7days': shadowserver_last7d['sandbox']}))

def get_statistics_query(request):
    """
    相比报表，多一个
    :param request:
    :return:
    """
    if request.method == 'GET':
        # if day report
        start_epoch_t = request.GET.get('start_time')
        end_epoch_t = request.GET.get('end_time')
        #category = request.GET.get('category')
        organization_names = request.GET.getlist('organization_selected[]')
        type_names = request.GET.getlist('datatype_selected[]')
        interval_type = request.GET.get('interval_type','daily')
        #type_id_list = request.GET.get('type_id_list') #none or list

        if start_epoch_t and end_epoch_t:
            try:
                start_dt = datetime.datetime.fromtimestamp(int(start_epoch_t)) #todo:utcfromtimestamp?
                end_dt = datetime.datetime.fromtimestamp(int(end_epoch_t))    # todo:above
                print datetime.datetime.now()
                print 'start epoch:',start_epoch_t,'end epoch:',end_epoch_t
                print 'param:',start_dt,end_dt,type_names

                if interval_type in ('daily','hourly','monthly','yearly'):
                    interval_type = interval_type.upper()
                else:
                    raise ValueError('illegal interval_type!')

            except ValueError,err:
                print(err)
                return HttpResponseBadRequest('err:%s'%err)

            ret_percentage = exchange.get_counts({'creating_date':{'$gt':start_dt, '$lt':end_dt},
                                                'report_type_organization':organization_names},
                                                 group_by='report_type_organization'
                                                 )
            #print 'ret_percentage',ret_percentage
            ret_counts = exchange.get_counts({'creating_date':{'$gt':start_dt, '$lt':end_dt},
                                                'report_type_name':type_names,
                                            # 'report_type_id':type_id_list,
                                            })
            #print 'ret_counts:',ret_counts

            #生成趋势数据

            # during_days = (end_dt-start_dt).days#todo:直接根据年报月报日报来
            # if during_days > 3650:
            #     interval_type = 'YEARLY'
            # elif during_days > 366:
            #     interval_type = 'MONTHLY'
            # else:
            #     interval_type = 'DAILY'
            ret_trend = exchange.get_trends({'creating_date':{'$gt':start_dt, '$lt':end_dt},
                                                'report_type_organization':organization_names},
                                            group_by='report_type_organization',
                                            interval=interval_type)
            #生成datestring
            dtstring_list = exchange.gen_datestring(start_dt,end_dt,interval=interval_type)
            #print 'dtstring:',dtstring_list

            #装载datestring
            for type,counts_kv in ret_trend.items():
                counts_list = [counts_kv[dt_str] if dt_str in counts_kv else 0 for dt_str in dtstring_list ]

                ret_trend[type]={'name':dtstring_list,'value':counts_list}

            return HttpResponse(json.dumps({'percentage':ret_percentage,
                                            'counts':ret_counts,
                                            'trend':ret_trend}))

        else:
            return HttpResponseBadRequest('not include key parameter:start_time,end_time ')
    else:
        return HttpResponse('method not allowed!')


def home_info(request):
    ret = {}
    ret['time'] = sysinfo.get_timeinfo()
    ret['disk'] = sysinfo.get_diskinfo()
    ret['info_counts'] = {'organizations_counts_in': statistics_for_home.get_organizations_counts_in(),
                           'organizations_counts_out': statistics_for_home.get_organizations_counts_out(),
                           }

    ret['topn_organizations_in'] = statistics_for_home.get_top_n_organizations_in(5)
    ret['topn_organizations_out'] = statistics_for_home.get_top_n_organizations_out(5)

    ret['categories_statistics'] = statistics_for_home.get_exchange_counts() #get all category

    ret['topn_intelligence_types_in'] = statistics_for_home.get_top_n_intelligence_type_in(5)
    ret['topn_intelligence_types_out'] = statistics_for_home.get_top_n_intelligence_type_out(5)

    ret['intelligence_types_in'] = statistics_for_home.get_top_n_intelligence_type_in()

    ret['category_and_organization_in'] = datatypes.get_counts_tree_in()
    ret['category_and_organization_out'] = datatypes.get_counts_tree_out()#todo:fill
    #print ret
    return HttpResponse(json.dumps(ret))

# def querydict_convert(q_dict):
#     ret = {}
#     print q_dict
#
#     for k,v in q_dict.lists():
#         if isinstance(v,list):
#             if len(v)==1:
#                 ret.update({k:v[0]})
#             else:
#                 ret.update({k:''})
#         elif:
#             ret.update({k:v})
#     print 'ret:',ret
#     return ret

def rules_datain(request):

    if request.method == 'GET':
        id = request.GET.get('_id')
        ret = rules_in.find(id)
        # print ret
        return HttpResponse(json.dumps({'result':True,'info':ret}))

    elif request.method == 'POST':
        result = False
        info='something wrong'
        #print request.POST

        print 'ajax:',request.is_ajax()
        # print request.body
        try:
            data_input = json.loads(request.body)
        except Exception,err:
            print err
            return HttpResponse(json.dumps({'result':False,'info':str(err)}))

        print 'input:',data_input

        if 'rule_action' in data_input:
            action = data_input.pop('rule_action')

            if action == 'delete':
                operation_journal_type = 'delete_datain_rule'
                result,info = rules_in.delete_one(data_input.get('_id'))
            elif action == 'update':
                operation_journal_type = 'update_datain_rule'
                print operation_journal_type,data_input

                if '_id' in data_input:
                    id = data_input.pop('_id')
                    # enable = input.get('enable',False)
                    result,info = rules_in.update_one(id,data_input)
                else:
                    result = False
                    info = '"_id" required!'

            elif action == 'create':
                operation_journal_type = 'create_datain_rule'
                result,info = rules_in.insert_one(data_input)

            else:
                operation_journal_type = 'other_datain_rule_action'
                result = False
                print 'rule_action:',action
                info = 'bad parameter for rule_action:%s'%action

        else:
            operation_journal_type = 'create_datain_rule'
            result,info = rules_in.insert_one(data_input)

        journal_str = 'successful for %s'%info if result else 'failed for %s'%info
        journal.new(request,operation_type=operation_journal_type,result=journal_str)
        return HttpResponse(json.dumps({'result':result,'info':info}))

    else:
        return HttpResponse(json.dumps({'result':False,'info':'method not supported!'}))

def rules_datain_bulkinvalid(request):
    """
    批量删除
    :param request:
    :return:
    """
    operation_journal_type = 'bulk_delete_datain_rule'
    if request.method == 'POST': #更新
        idlist = request.POST.getlist('_idlist[]')
        if idlist:
            result,info = rules_in.delete_many(idlist)
        else:
            result = False
            info = 'empty content list,expect a list input'

        journal_str = 'successful for %s'%info if result else 'failed for %s'%info
        journal.new(request,operation_type=operation_journal_type,result=journal_str)
        return HttpResponse(json.dumps({'result':result,
                                        'info':info}))
    else:
        result = False
        info = 'method not supported!'

        journal_str = 'successful for %s'%info if result else 'failed for %s'%info
        journal.new(request,operation_type=operation_journal_type,result=journal_str)

        return HttpResponse(json.dumps({'result':result,
                                        'info':info}))

def rules_dataout(request):

    if request.method == 'GET':
        id = request.GET.get('_id')
        ret = rules_out.find(id)
        # print ret
        return HttpResponse(json.dumps({'result':True,'info':ret}))

    elif request.method == 'POST':
        result = False
        info='something wrong'
        #print request.POST

        print 'ajax:',request.is_ajax()
        # print request.body
        try:
            data_input = json.loads(request.body)
        except Exception,err:
            print err
            return HttpResponse(json.dumps({'result':False,'info':str(err)}))

        print 'input:',data_input

        if 'rule_action' in data_input:
            action = data_input.pop('rule_action')

            if action == 'delete':
                operation_journal_type = 'delete_dataout_rule'
                result,info = rules_out.delete_one(data_input.get('_id'))
            elif action == 'update':
                operation_journal_type = 'update_dataout_rule'
                print operation_journal_type,data_input

                if '_id' in data_input:
                    id = data_input.pop('_id')
                    # enable = input.get('enable',False)
                    result,info = rules_out.update_one(id,data_input)
                else:
                    result = False
                    info = '"_id" required!'

            elif action == 'create':
                operation_journal_type = 'create_dataout_rule'
                result,info = rules_out.insert_one(data_input)

            else:
                operation_journal_type = 'other_dataout_rule_action'
                result = False
                print 'rule_action:',action
                info = 'bad parameter for rule_action:%s'%action

        else:
            operation_journal_type = 'create_dataout_rule'
            result,info = rules_out.insert_one(data_input)

        journal_str = 'successful for %s'%info if result else 'failed for %s'%info
        journal.new(request,operation_type=operation_journal_type,result=journal_str)
        return HttpResponse(json.dumps({'result':result,'info':info}))

    else:
        return HttpResponse(json.dumps({'result':False,'info':'method not supported!'}))

def rules_dataout_bulkinvalid(request):
    """
    批量删除
    :param request:
    :return:
    """
    operation_journal_type = 'bulk_delete_dataout_rule'
    if request.method == 'POST': #更新
        idlist = request.POST.getlist('_idlist[]')
        if idlist:
            result,info = rules_out.delete_many(idlist)
        else:
            result = False
            info = 'empty content list,expect a list input'

        journal_str = 'successful for %s'%info if result else 'failed for %s'%info
        journal.new(request,operation_type=operation_journal_type,result=journal_str)
        return HttpResponse(json.dumps({'result':result,
                                        'info':info}))
    else:
        result = False
        info = 'method not supported!'

        journal_str = 'successful for %s'%info if result else 'failed for %s'%info
        journal.new(request,operation_type=operation_journal_type,result=journal_str)

        return HttpResponse(json.dumps({'result':result,
                                        'info':info}))

@csrf_exempt
def manage_pyscripts(request):
    """
    'name':'XXX',#
    'description':'XXX',
    'file':'/XX/XX/XX.py',#上传的文件,上传框
    'content':'XXX',#给使用者看的，
    'ID':'qazilm......',#用来做脚本索引的,invisible
    :param request:
    :return:
    """
    result = False
    info = 'default'

    operation_journal_type = 'manage_pyscripts'

    if request.method == 'GET':
        result,info = myviews.pyscripts.get_all(request)

    elif request.method == 'POST':
        print request.POST
        # create
        action = request.POST.get('action')
        print 'action:',action

        if action is None:
            result = False
            info = 'KEY "action" is required!please submit in form'
        elif action == 'create':
            result,info = myviews.pyscripts.create_one(request)
        elif action == 'update':
            result,info = myviews.pyscripts.update_one(request)
        elif action == 'delete':
            result,info = myviews.pyscripts.delete_one(request)
            print result,info
        else:
            result = False
            info = 'bad action param'
    else:
        result = False
        info = 'bad request method'

    ret = {'result':result,'info':info}
    print 'ret:',ret
    return HttpResponse(json.dumps(ret))

def list_pyscripts_simple(request):
    result = False
    info = 'default'

    if request.method == 'GET':
        result,info = myviews.pyscripts.get_all(request,ret_full=False)
    else:
        result = False
        info = 'bad request method'
    ret = {'result':result,'info':info}
    return HttpResponse(json.dumps(ret))

def manage_passwd(request):
    result = False
    info = 'default'

    operation_journal_type = 'change_password'

    if request.method == 'POST':
        oldpass = request.POST.get('oldpass')
        newpass = request.POST.get('newpass')

        uname = request.user.username
        user = authenticate(username=uname,password=oldpass)
        if user is not None and user.is_active:
            user.set_password(newpass)
            user.save()
            result = True
            info = 'successful'
        else:
            result = False
            info = 'wrong pass'
    else:
        result = False
        info = request.user.username

    journal_str = 'successful for %s'%info if result else 'failed for %s'%info
    journal.new(request,operation_type=operation_journal_type,result=journal_str)

    return HttpResponse(json.dumps({'result':result,'info':info}))

def sysstate(request):
    uname = request.user.username

    u = User.objects.get(username=uname)
    if u:
        is_superuser = u.is_superuser
    else:
        is_superuser = False

    ret = {'logged_uname':uname,
           'is_superuser':is_superuser}

    return HttpResponse(json.dumps(ret))

def manage_users(request):
    result = False
    info = 'default'
    operation_journal_type = 'default_user_action'

    if request.method == 'GET':
        users = User.objects.all()
        print users

        result = True
        # info = [{'uname':user.username,
        #          'email':user.email,
        #          'is_active':user.is_active,
        #          'last_login':user.last_login.isoformat(),
        #          'date_joined':user.date_joined.isoformat() ,
        #          'is_superuser':user.is_superuser,
        #          } for user in users]
        info = []
        for user in users:
            tmp = {}
            tmp['uanme'] = user.username
            tmp['email'] = user.email
            tmp['is_active'] = user.is_active
            tmp['last_login'] = user.last_login.strftime('%Y-%m-%d %H:%M:%S') if user.last_login else ''
            tmp['date_joined'] = user.date_joined.strftime('%Y-%m-%d %H:%M:%S') if user.date_joined else ''
            tmp['is_superuser'] = user.is_superuser
            info.append(tmp)
        print info

    elif request.method == 'POST':
        try:
            datainput = json.loads(request.body)
        except Exception,error:
            print error
            return HttpResponse(json.dumps({'result':False,'info':str(error)}))

        action = datainput.get('user_action')
        if action == 'create':

            uname = datainput.get('uname')
            email = datainput.get('email')
            passwd = datainput.get('passwd')
            try:
                user = User.objects.create_user(uname,email,passwd)
                user.save()
            except Exception,error:
                print error
                return HttpResponse(json.dumps({'result':False,'info':str(error)}))

            result = True
            info = 'successful'
            operation_journal_type = 'create_user'

        elif action == 'resetpass':        #重置密码
            uname = datainput.get('uname')
            if uname == request.user.username:
                info = "can't reset your own password"
                return HttpResponse(json.dumps({'result':False,'info':str(info)}))
            new_passwd = str(uuid.uuid4())
            try:
                user = User.objects.get(username=uname)
                user.set_password(new_passwd)
                user.save()
            except Exception,error:
                print error
                return HttpResponse(json.dumps({'result':False,'info':str(error)}))

            result = True
            info = new_passwd
            operation_journal_type = 'reset_password'

        elif action =='enableuser':
            uname = datainput.get('uname')
            enable = datainput.get('enable')
            if not isinstance(enable,bool):
                result = False
                info = 'enable must be Bool Type'
            try:
                user = User.objects.get(username=uname)
                user.is_active = enable
                user.save()
            except Exception,error:
                print error
                return HttpResponse(json.dumps({'result':False,'info':str(error)}))

            result = True
            info = 'successful'
            operation_journal_type = 'enable_user'
        else:
            result = False
            info = 'bad action'
            operation_journal_type = 'other_user_action'
    else:
        result = False
        info = 'wrong reqeust method'


    journal_str = 'successful' if result else 'failed for %s'%info
    journal.new(request,operation_type=operation_journal_type,result=journal_str)
    return HttpResponse(json.dumps({'result':result,'info':info}))


def proc_logo(f,file_name):
    if not file_name:
        raise ValueError('bad filename for logo: %s'%filename)

    BaseDir = os.path.dirname(os.path.abspath(__name__))
    print BaseDir
    logodir = os.path.join(BaseDir,'media','logo')

    filename = os.path.join(logodir,file_name)

    with open(filename,'wb') as fobj:
        for chrunk in f.chunks():
            fobj.write(chrunk)


@csrf_exempt
def manage_sysinfo(request): #处理表单数据 #todo:csrf
    result = False
    info = 'default'
    operation_journal_type = 'change sysinfo'

    if request.method == 'GET':
        ret = sysinfo.get_sysinfo()
        result = True
        info = ret

    elif request.method == 'POST':
        # try:
        #     datainput = json.loads(request.body)
        #
        # except Exception,err:
        #     print err
        #     result = False
        #     info = 'err:'+str(err)
        #     return HttpResponse(json.dumps({'result':result,'info':info}))
        datainput = request.POST
        apikey = datainput.get('apikey')
        country = datainput.get('country')
        organization_name = datainput.get('organization_name')
        organization_email = datainput.get('organization_email')

        f = request.FILES.get('logo')
        if f:
            proc_logo(f,'logo.png') #todo: csrf
        result,info = sysinfo.set_sysinfo({'apikey':apikey,
                             'country':country,
                             'organization_name':organization_name,
                             'organization_email':organization_email})

        journal_str = 'successful' if result else 'failed for %s'%info
        journal.new(request,operation_type=operation_journal_type,result=journal_str)
        return HttpResponseRedirect('/manage/sysinfo/')
    else:
        result = False
        info = 'bad request method'

    journal_str = 'successful' if result else 'failed for %s'%info
    journal.new(request,operation_type=operation_journal_type,result=journal_str)
    return HttpResponse(json.dumps({'result':result,'info':info}))

def _rename_logo(old, new):
    baseDir = os.path.dirname(os.path.abspath(__name__))
    print baseDir
    logodir = os.path.join(baseDir,'media','logo')
    src= os.path.join(logodir,old)
    dst = os.path.join(logodir,new)
    os.rename(src,dst)

def reset_logo(request):
    result = False
    info = 'default'
    operation_journal_type = 'reset logo'

    if request.method == 'POST':
        enable = request.POST.get('reset_logo')
        if enable:
            _rename_logo('logo.png', 'logo.bk.png')
            result = True
            info = 'successful'
    else:
        result = False
        info = 'bad request method'

    journal_str = 'successful' if result else 'failed for %s'%info
    journal.new(request,operation_type=operation_journal_type,result=journal_str)
    return HttpResponse(json.dumps({'result':result,'info':info}))

def get_journals(request):
    ret = journal.get_all()
    return HttpResponse(json.dumps(ret))

def es_operation(request):
    result = False
    info = 'default'

    if request.method == 'POST':
        rest_method = request.POST.get('rest_method')
        rest_url = request.POST.get('rest_url')
        rest_json_str = request.POST.get('rest_json')
        if rest_method and rest_url:
            if rest_json_str:
                rest_json = json.loads(rest_json_str)
            else:
                rest_json = None
            try:
                result,info = es_middleware.transport(rest_method,rest_url,rest_json)
                print result,type(info)

            except Exception,err:
                result = False
                info = str(err)
        else:
            result = False
            info = 'bad rest param'
    ret = {'result':result,'info':info}

    if result:
        return HttpResponse(str(info))
    else:
        return HttpResponse(str(info))

def test_email_folders(request):
    ret = {'result':False,'info':'default'}
    if request.method == 'POST':
        try:
            server = request.POST['server']
            port = request.POST['port']
            mail_account = request.POST['mail_account']
            password = request.POST['password']
            use_ssl = request.POST['use_ssl']
        except KeyError,err:
            logger.exception(err)
            print err
            traceback.print_exc()

            ret['result'] = False
            ret['info'] = 'KeyError:'+str(err)
            return HttpResponse(json.dumps(ret))

        # dir_from = request.POST.get('dir_from')
        # dir_done = request.POST.get('dir_done')
        email_conf = {'server':server,
                      'port':port,
                      'use_ssl':use_ssl,
                      'mail_account':mail_account,
                      'password':password,
                      }
        try:
            dir_list = rule_running_test.test_getting_email_dirs(email_conf)
            ret['result'] = True
            ret['info'] = dir_list
        except Exception,err:
            logger.exception(err)
            print err

            ret['result'] = False
            ret['info'] = str(err)

    else:
        ret['result'] = False
        ret['info'] = 'bad request method!'

    return HttpResponse(json.dumps(ret))

def test_report_fields(request):
    result = True
    info = 'default'

    if request.method == 'POST':
        try:
            process_conf = json.loads(request.body)
        except Exception,err:
            logger.exception(err)
            print err
            return HttpResponse(json.dumps({'result':False,'info':str(err)}))

        result,info = rule_running_test.test_getting_fields(process_conf)

    else:
        result = False
        info = 'bad request method'

    return HttpResponse(json.dumps({'result':result,'info':info}))