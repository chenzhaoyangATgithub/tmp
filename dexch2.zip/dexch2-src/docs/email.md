
# email协议脚本得到的处理能力

```
{
    'headers': 
        [{
            'Name': 'Received-SPF',
            'Value': 'pass (google.com: domain of ......;'
        }, 
        {
            'Name': 'MIME-Version',
            'Value': '1.0'
        }],
    'bcc':[],
    'body': {
        'plain: ['ASCII'],
        'html': ['HTML BODY']
    },
    'cc':[],
    'attachments':  [{
        'content': <StringIO.StringIO instance at 0x7f8e8445fa70>, 
        'filename': "avatar.png",
        'content-type': 'image/png',
        'size': 80264
    }],
    'date': u 'Fri, 26 Jul 2013 10:56:26 +0300',
    'parsed_date':<datetime.datetime instance at ...>
    'message_id': u '51F22BAA.1040606',
    'sent_from': [{
        'name': u 'Martin Rusev',
        'email': 'martin@amon.cx'
    }],
    'sent_to': [{
        'name': u 'John Doe',
        'email': 'john@gmail.com'
    }],
    'subject': u 'Hello John, How are you today'
    }
````
