# params

```
process:

# 前端传输的数据格式,用于测试的数据格式
# 处理脚本化：传输协议可走各种协议；但是信息处理过程本期只能脚本化，不支持细分
{
    'transport_type':'email', #传输协议类型 email,ftp,web api
    'transport_detail':{
        "server":'imap.mxhichina.com',
        "port":'993',
        "use_ssl":True,
        "mail_account":"xxxxx@antiy.cn",
        "password":'******',
        "dir_from":'Intelligence',
        "done_dir":'googleurl_dumped',
        "mail_title_regex":'\s*Compromised URLs on .cn',
    }, #传输协议细节,具体见其他的细节,输出为文件，文本文件或者其他文件，可预览。
    'script_id':'xxxxx',#前端传过来的用户所选的id
}

```

# return
{
    '_meta':{
        'dates':{},
        'ids':{},
    },
    'records':[{},{}],
    'files':[{
            'content': <StringIO.StringIO instance>,
            'filename': "avatar.png",
            'content-type': 'image/png',
            'size': 80264
            },
            ...

    ]
}