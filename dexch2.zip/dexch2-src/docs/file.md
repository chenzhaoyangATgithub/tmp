# file 的常规结构
```
'content': <StringIO.StringIO instance>,
'filename': "avatar.png",
'content-type': 'image/png',
'size': 80264
```
