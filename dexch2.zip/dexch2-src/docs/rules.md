#rules in (给前端看)
```


```

#rules out (给前端看)

```
'rule_id': 'xxx',
'src_type_id':'google_ioc_url',# 来源
'out_field':'',

```

# out_record
此信息用来被相应模块进行加密，以及发送

```
'format':'csv',　　　　　# 将来可能支持json
'selected_fields':[],　#从众多的字段里输出,具备顺序
'selected_country':[], #只会给这些组织里挑选，进行发送。
'records':['']

```